<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Tree.ps1
# Build: 20251126-142332

$script:uniqueAclIndex = $null  # Will hold ArrayList of folder info
$script:indexCacheFile = Join-Path (Get-FsLogPath) "FSManager_Index_Cache.json"
$script:indexMetaFile = Join-Path (Get-FsLogPath) "FSManager_Index_Meta.json"
function Get-IndexCacheMetadata {
    try {
        $shares = Get-ShareData | Sort-Object Name
        $metadata = @{
            ShareCount = $shares.Count
            ShareNames = ($shares | % { $_.Name }) -join ","
            SharePaths = ($shares | % { $_.Path }) -join ","
            Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
            ComputerName = $env:COMPUTERNAME
        }
        return $metadata
    } catch {
        return $null
    }
}
function Test-IndexCacheValid {
    try {
        if (-not (Test-Path $script:indexMetaFile) -or -not (Test-Path $script:indexCacheFile)) {
            return $false
        }
        $cachedMeta = gc $script:indexMetaFile -Raw | ConvertFrom-Json
        $currentMeta = Get-IndexCacheMetadata
        if (-not $currentMeta) { return $false }
        $sharesChanged = ($cachedMeta.ShareCount -ne $currentMeta.ShareCount) -or
                        ($cachedMeta.ShareNames -ne $currentMeta.ShareNames) -or
                        ($cachedMeta.SharePaths -ne $currentMeta.SharePaths) -or
                        ($cachedMeta.ComputerName -ne $currentMeta.ComputerName)
        if ($sharesChanged) {
            Write-FsInfo -Category "Cache" -Message "Index cache invalid" -Details "Shares configuration changed"
            return $false
        }
        $cacheAge = (Get-Date) - [DateTime]::Parse($cachedMeta.Timestamp)
        if ($cacheAge.TotalHours -gt 24) {
            Write-FsWarning -Category "Cache" -Message "Index cache expired" -Details "Cache older than 24 hours (Age=$($cacheAge.TotalHours.ToString('F1'))h)"
            return $false
        }
        Write-FsInfo -Category "Cache" -Message "Index cache valid" -Details "Age=$($cacheAge.TotalHours.ToString('F1'))h"
        return $true
    } catch {
        Write-FsWarning -Category "Cache" -Message "Cache validation failed" -Details $_.Exception.Message
        return $false
    }
}
function Load-IndexFromCache {
    try {
        if (-not (Test-IndexCacheValid)) {
            return $false
        }
        $cacheData = gc $script:indexCacheFile -Raw | ConvertFrom-Json
        $script:uniqueAclIndex = [System.Collections.ArrayList]::new()
        foreach ($item in $cacheData) {
            [void]$script:uniqueAclIndex.Add([PSCustomObject]@{
                Path      = $item.Path
                ShareName = $item.ShareName
                FolderName = $item.FolderName
            })
        }
        Write-FsInfo -Category "Cache" -Message "Index loaded from cache" -Details "Folders=$($script:uniqueAclIndex.Count)"
        return $true
    } catch {
        Write-FsWarning -Category "Cache" -Message "Failed to load cache" -Details $_.Exception.Message
        $script:uniqueAclIndex = $null
        return $false
    }
}
function Save-IndexToCache {
    try {
        if (-not $script:uniqueAclIndex -or $script:uniqueAclIndex.Count -eq 0) {
            return
        }
        $cacheDir = Split-Path $script:indexCacheFile -Parent
        if (-not (Test-Path $cacheDir)) {
            New-Item -Path $cacheDir -ItemType Directory -Force | Out-Null
        }
        $script:uniqueAclIndex | ConvertTo-Json -Depth 3 | Set-Content $script:indexCacheFile -Encoding UTF8
        $metadata = Get-IndexCacheMetadata
        if ($metadata) {
            $metadata | ConvertTo-Json -Depth 2 | Set-Content $script:indexMetaFile -Encoding UTF8
        }
        Write-FsInfo -Category "Cache" -Message "Index saved to cache" -Details "Folders=$($script:uniqueAclIndex.Count)"
    } catch {
        Write-FsWarning -Category "Cache" -Message "Failed to save cache" -Details $_.Exception.Message
    }
}
function Build-UniqueAclIndex {
    param([switch]$Force)
    if ($script:isIndexBuilding) {
        Write-FsDebug -Category "Index" -Message "Index build already in progress - skipping"
        return
    }
    if ($script:uniqueAclIndex -and -not $Force) { return }
    if (-not $Force -and (Load-IndexFromCache)) {
        if ($script:lblTreeHint) {
            $script:lblTreeHint.Text = "Index ready: $($script:uniqueAclIndex.Count) folders with unique ACL (loaded from cache)"
            if ($script:form) {
                $script:form.Refresh()
                [System.Windows.Forms.Application]::DoEvents()
            }
        }
        return
    }
    $script:isIndexBuilding = $true
    if ($script:lblTreeHint) {
        $script:lblTreeHint.Text = "Building index in background..."
        if ($script:form) {
            $script:form.Refresh()
            [System.Windows.Forms.Application]::DoEvents()
        }
    }
    $script:uniqueAclIndex = [System.Collections.ArrayList]::new()
    $script:indexingCancelled = $false
    $script:totalFoldersProcessed = 0
    $script:indexingStartTime = Get-Date
    $shares = Get-ShareData | Sort-Object Name
    $shareCount = $shares.Count
    Write-FsInfo -Category "Index" -Message "Building unique ACL index" -Details "Shares=$shareCount"
    $progressForm = New-Object System.Windows.Forms.Form
    $progressForm.Text = "Building Index - FS-Manager Viewer"
    $progressForm.Size = New-Object System.Drawing.Size(500, 200)
    $progressForm.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $progressForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $progressForm.MaximizeBox = $false
    $progressForm.MinimizeBox = $false
    $progressForm.TopMost = $true
    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Location = New-Object System.Drawing.Point(20, 20)
    $lblStatus.Size = New-Object System.Drawing.Size(450, 20)
    $lblStatus.Text = "Initializing index build..."
    $progressForm.Controls.Add($lblStatus)
    $lblProgress = New-Object System.Windows.Forms.Label
    $lblProgress.Location = New-Object System.Drawing.Point(20, 50)
    $lblProgress.Size = New-Object System.Drawing.Size(450, 20)
    $lblProgress.Text = "0 folders processed"
    $progressForm.Controls.Add($lblProgress)
    $lblETA = New-Object System.Windows.Forms.Label
    $lblETA.Location = New-Object System.Drawing.Point(20, 80)
    $lblETA.Size = New-Object System.Drawing.Size(450, 20)
    $lblETA.Text = "Calculating time remaining..."
    $progressForm.Controls.Add($lblETA)
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Location = New-Object System.Drawing.Point(200, 120)
    $btnCancel.Size = New-Object System.Drawing.Size(100, 30)
    $btnCancel.Text = "Cancel"
    $btnCancel.Add_Click({
        $script:indexingCancelled = $true
        $btnCancel.Enabled = $false
        $btnCancel.Text = "Cancelling..."
    })
    $progressForm.Controls.Add($btnCancel)
    $progressForm.Show()
    $progressForm.BringToFront()
    try {
        $currentShare = 0
        foreach ($sh in $shares) {
            if ($script:indexingCancelled) {
                Write-FsInfo -Category "Index" -Message "Index build cancelled by user"
                break
            }
            $currentShare++
            $lblStatus.Text = "Scanning share ($currentShare/$shareCount): $($sh.Name)"
            $progressForm.Refresh()
            [System.Windows.Forms.Application]::DoEvents()
            $scanFolder = {
                param([string]$Path, [string]$ShareName, [int]$Depth)
                if ($script:indexingCancelled -or $Depth -gt 30) { return }
                try {
                    $script:totalFoldersProcessed++
                    if ($script:totalFoldersProcessed % 5 -eq 0) {
                        $elapsed = (Get-Date) - $script:indexingStartTime
                        $rate = if ($elapsed.TotalSeconds -gt 0) { $script:totalFoldersProcessed / $elapsed.TotalSeconds } else { 0 }
                        $lblProgress.Text = "$($script:totalFoldersProcessed) folders processed ($([math]::Round($rate, 1))/sec)"
                        if ($rate -gt 0 -and $currentShare -lt $shareCount) {
                            $remainingShares = $shareCount - $currentShare
                            $avgFoldersPerShare = if ($currentShare -gt 0) { $script:totalFoldersProcessed / $currentShare } else { 50 }
                            $estimatedRemaining = $remainingShares * $avgFoldersPerShare
                            $etaSeconds = $estimatedRemaining / $rate
                            $lblETA.Text = "Estimated time remaining: $([math]::Round($etaSeconds / 60, 1)) minutes"
                        } else {
                            $lblETA.Text = "Calculating time remaining..."
                        }
                        $progressForm.Refresh()
                        [System.Windows.Forms.Application]::DoEvents()
                    }
                    $hasUniqueAcl = Get-UniqueAclFlag -Path $Path
                    if ($hasUniqueAcl) {
                        [void]$script:uniqueAclIndex.Add([PSCustomObject]@{
                            Path      = $Path
                            ShareName = $ShareName
                            FolderName = Split-Path $Path -Leaf
                        })
                    }
                    if (-not $script:indexingCancelled) {
                        try {
                            $subfolders = Get-ChildItem -Path $Path -Directory -ErrorAction Stop
                            foreach ($sub in $subfolders) {
                                if ($script:indexingCancelled) { break }
                                & $scanFolder $sub.FullName $ShareName ($Depth + 1)
                            }
                        } catch [System.UnauthorizedAccessException] {
                            Write-FsDebug -Category "Index" -Message "Access denied to subfolders" -Details "Path=$Path"
                        } catch [System.IO.DirectoryNotFoundException] {
                            Write-FsDebug -Category "Index" -Message "Directory not found" -Details "Path=$Path"
                        } catch {
                            Write-FsWarning -Category "Index" -Message "Cannot access subfolders" -Details "Path=$Path; Error=$($_.Exception.Message)"
                        }
                    }
                } catch [System.UnauthorizedAccessException] {
                    Write-FsDebug -Category "Index" -Message "Access denied to folder" -Details "Path=$Path"
                } catch [System.IO.DirectoryNotFoundException] {
                    Write-FsDebug -Category "Index" -Message "Directory not found" -Details "Path=$Path"
                } catch {
                    Write-FsWarning -Category "Index" -Message "Folder scan failed" -Details "Path=$Path; Error=$($_.Exception.Message)"
                }
            }
            try {
                Write-FsInfo -Category "Index" -Message "Scanning share" -Details "Share=$($sh.Name); Path=$($sh.Path)"
                & $scanFolder $sh.Path $sh.Name 0
            } catch {
                Write-FsWarning -Category "Index" -Message "Share scan failed" -Details "Share=$($sh.Name); Path=$($sh.Path); Error=$($_.Exception.Message)"
                continue
            }
        }
        $elapsed = (Get-Date) - $script:indexingStartTime
        if ($script:indexingCancelled) {
            $script:lblTreeHint.Text = "Index build cancelled - $($script:uniqueAclIndex.Count) folders indexed before cancellation"
            Write-FsInfo -Category "Index" -Message "Index build cancelled" -Details "PartialFolders=$($script:uniqueAclIndex.Count); ProcessedFolders=$($script:totalFoldersProcessed)"
        } else {
            $script:lblTreeHint.Text = "Index ready: $($script:uniqueAclIndex.Count) folders with unique ACL (processed $($script:totalFoldersProcessed) folders in $([math]::Round($elapsed.TotalSeconds, 1))s)"
            Write-FsInfo -Category "Index" -Message "Index complete" -Details "UniqueFolders=$($script:uniqueAclIndex.Count); TotalProcessed=$($script:totalFoldersProcessed); Duration=$($elapsed.TotalSeconds)s"
            Save-IndexToCache
        }
    } catch {
        Write-FsError -Category "Index" -Message "Index build failed" -Details $_.Exception.Message
        $script:lblTreeHint.Text = "Index build failed - please check logs"
    } finally {
        if ($progressForm) {
            $progressForm.Close()
            $progressForm.Dispose()
        }
        $script:indexingCancelled = $false
        $script:isIndexBuilding = $false
    }
}
function Clear-IndexCache {
    try {
        if (Test-Path $script:indexCacheFile) {
            Remove-Item $script:indexCacheFile -Force
        }
        if (Test-Path $script:indexMetaFile) {
            Remove-Item $script:indexMetaFile -Force
        }
        Write-FsInfo -Category "Cache" -Message "Index cache cleared"
        return $true
    } catch {
        Write-FsWarning -Category "Cache" -Message "Failed to clear cache" -Details $_.Exception.Message
        return $false
    }
}
function Get-IndexCacheInfo {
    try {
        $info = @{
            CacheExists = (Test-Path $script:indexCacheFile) -and (Test-Path $script:indexMetaFile)
            CacheValid = $false
            CacheAge = $null
            CacheSize = $null
            FolderCount = $null
        }
        if ($info.CacheExists) {
            $info.CacheValid = Test-IndexCacheValid
            $cacheFile = Get-Item $script:indexCacheFile
            $info.CacheSize = [math]::Round($cacheFile.Length / 1KB, 1)
            if (Test-Path $script:indexMetaFile) {
                $meta = gc $script:indexMetaFile -Raw | ConvertFrom-Json
                $cacheAge = (Get-Date) - [DateTime]::Parse($meta.Timestamp)
                $info.CacheAge = [math]::Round($cacheAge.TotalHours, 1)
            }
            if ($info.CacheValid) {
                $cacheData = gc $script:indexCacheFile -Raw | ConvertFrom-Json
                $info.FolderCount = $cacheData.Count
            }
        }
        return $info
    } catch {
        Write-FsWarning -Category "Cache" -Message "Failed to get cache info" -Details $_.Exception.Message
        return $null
    }
}
function Show-IndexCacheDialog {
    try {
        $dlg = New-Object System.Windows.Forms.Form
        $dlg.Text = "Cache Manager - FSManager Index System"
        $dlg.Size = New-Object System.Drawing.Size(650, 550)
        $dlg.StartPosition = "CenterParent"
        $dlg.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
        $dlg.MaximizeBox = $false
        $dlg.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
        $lblTitle = New-Object System.Windows.Forms.Label
        $lblTitle.Location = New-Object System.Drawing.Point(15, 15)
        $lblTitle.Size = New-Object System.Drawing.Size(600, 25)
        $lblTitle.Text = "Cache Manager - How FSManager Indexing Works"
        $lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
        $dlg.Controls.Add($lblTitle)
        $txtInfo = New-Object System.Windows.Forms.TextBox
        $txtInfo.Location = New-Object System.Drawing.Point(15, 50)
        $txtInfo.Size = New-Object System.Drawing.Size(610, 420)
        $txtInfo.Multiline = $true
        $txtInfo.ReadOnly = $true
        $txtInfo.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
        $txtInfo.Font = New-Object System.Drawing.Font("Consolas", 9)
        $txtInfo.BackColor = [System.Drawing.Color]::White
        $cacheInfo = Get-IndexCacheInfo
        $infoText = @"
HOW FSMANAGER INDEXING AND CACHE WORKS:
========================================
1. TREE POPULATION (FAST - no ACL reading):
   * Tree is populated only with share names and basic folders
   * Does NOT read ACLs during tree population
   * That's why tree population is fast - just directory listing
2. UNIQUE ACL INDEX (background - with ACL reading):
   * Scans ALL folders in all shares
   * Checks which folders have UNIQUE (non-inherited) ACLs
   * Stores list of those folders in memory and on disk (cache)
   * This takes time, but runs in background after startup
3. USER SEARCH (uses index - faster):
   * Searches ONLY folders that have unique ACLs
   * Doesn't waste time on folders that inherit permissions from parent
   * That's why search is fast - looks only at relevant folders
CACHE SYSTEM (persistent storage):
==================================
* Index is saved to JSON files on disk
* On next startup loads from cache (much faster)
* Cache automatically refreshes if changes are detected
* Check every 30 minutes in background
* Cache expires after 24 hours (automatic rebuild)
* Cache also invalidated if share configuration changes
"@
        if ($cacheInfo) {
            $infoText += @"
CURRENT STATUS:
===============
Cache File Exists: $($cacheInfo.CacheExists)
Cache Valid: $($cacheInfo.CacheValid)
"@
            if ($cacheInfo.CacheAge) {
                $infoText += "Cache Age: $($cacheInfo.CacheAge) hours`r`n"
            }
            if ($cacheInfo.CacheSize) {
                $infoText += "Cache Size: $($cacheInfo.CacheSize) KB`r`n"
            }
            if ($cacheInfo.FolderCount) {
                $infoText += "Indexed Folders: $($cacheInfo.FolderCount)`r`n"
            }
            $infoText += "`r`nCurrent Index in Memory:`r`n"
            if ($script:uniqueAclIndex) {
                $infoText += "Loaded: Yes ($($script:uniqueAclIndex.Count) folders)`r`n"
            } else {
                $infoText += "Loaded: No`r`n"
            }
            if ($cacheInfo.FolderCount -gt 0) {
                $infoText += @"
PERFORMANCE BENEFIT:
====================
* Without index: Search would have to check ALL folders (slow)
* With index: Search checks only $($cacheInfo.FolderCount) folders with unique ACLs
* This significantly speeds up search operations!
"@
            }
        } else {
            $infoText += "`r`nUnable to get cache information"
        }
        $infoText += @"
CACHE FILES:
============
Cache Path: $($script:indexCachePath)
Meta Path: $($script:indexMetaFile)
NOTES:
======
- Tree populates fast because it doesn't read ACLs
- Index builds in background with ACL reading
- Search uses index for faster results
- Cache is automatically maintained
"@
        $txtInfo.Text = $infoText
        $dlg.Controls.Add($txtInfo)
        $btnClearCache = New-Object System.Windows.Forms.Button
        $btnClearCache.Location = New-Object System.Drawing.Point(15, 480)
        $btnClearCache.Size = New-Object System.Drawing.Size(120, 30)
        $btnClearCache.Text = "Clear Cache"
        $btnClearCache.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnClearCache.BackColor = [System.Drawing.Color]::FromArgb(220, 60, 60)
        $btnClearCache.ForeColor = [System.Drawing.Color]::White
        $btnClearCache.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $dlg.Controls.Add($btnClearCache)
        $btnRebuildIndex = New-Object System.Windows.Forms.Button
        $btnRebuildIndex.Location = New-Object System.Drawing.Point(145, 480)
        $btnRebuildIndex.Size = New-Object System.Drawing.Size(100, 30)
        $btnRebuildIndex.Text = "Rebuild Now"
        $btnRebuildIndex.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnRebuildIndex.BackColor = [System.Drawing.Color]::FromArgb(60, 120, 180)
        $btnRebuildIndex.ForeColor = [System.Drawing.Color]::White
        $btnRebuildIndex.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $dlg.Controls.Add($btnRebuildIndex)
        $btnCheckNow = New-Object System.Windows.Forms.Button
        $btnCheckNow.Location = New-Object System.Drawing.Point(255, 480)
        $btnCheckNow.Size = New-Object System.Drawing.Size(100, 30)
        $btnCheckNow.Text = "Check Now"
        $btnCheckNow.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnCheckNow.BackColor = [System.Drawing.Color]::FromArgb(60, 180, 120)
        $btnCheckNow.ForeColor = [System.Drawing.Color]::White
        $btnCheckNow.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $dlg.Controls.Add($btnCheckNow)
        $btnClose = New-Object System.Windows.Forms.Button
        $btnClose.Location = New-Object System.Drawing.Point(530, 480)
        $btnClose.Size = New-Object System.Drawing.Size(80, 30)
        $btnClose.Text = "Close"
        $btnClose.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnClose.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dlg.Controls.Add($btnClose)
        $btnClearCache.Add_Click({
            $confirm = [System.Windows.Forms.MessageBox]::Show(
                "Clear index cache?`r`n`r`nThis will force a full rebuild on next search or startup.",
                "Confirm Clear Cache",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )
            if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
                if (Clear-IndexCache) {
                    [System.Windows.Forms.MessageBox]::Show("Cache cleared successfully.", "Success",
                        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                    $dlg.Close()
                }
            }
        })
        $btnRebuildIndex.Add_Click({
            $confirm = [System.Windows.Forms.MessageBox]::Show(
                "Rebuild index now?`r`n`r`nThis will scan all shares and may take several minutes.",
                "Confirm Rebuild",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )
            if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
                $dlg.Close()
                $script:uniqueAclIndex = $null
                Build-UniqueAclIndex -Force
            }
        })
        $btnCheckNow.Add_Click({
            if (Test-IndexCacheValid) {
                [System.Windows.Forms.MessageBox]::Show("Cache is up to date - no rebuild needed.", "Cache Valid",
                    [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
            } else {
                $confirm = [System.Windows.Forms.MessageBox]::Show(
                    "Cache is outdated or invalid.`r`n`r`nRebuild index now?",
                    "Cache Invalid - Rebuild?",
                    [System.Windows.Forms.MessageBoxButtons]::YesNo,
                    [System.Windows.Forms.MessageBoxIcon]::Question
                )
                if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
                    $dlg.Close()
                    $script:uniqueAclIndex = $null
                    Build-UniqueAclIndex -Force
                }
            }
        })
        [void]$dlg.ShowDialog()
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Error showing cache dialog: $($_.Exception.Message)",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}
function Get-UniqueAclIndexForShare {
    param([string]$ShareName)
    if (-not $script:uniqueAclIndex) { return @() }
    return $script:uniqueAclIndex | ? { $_.ShareName -eq $ShareName }
}
function Search-UniqueAclIndex {
    param([string]$Pattern)
    if (-not $script:uniqueAclIndex) { 
        Write-FsWarning -Category "Search" -Message "Index not built" -Details "Call Build-UniqueAclIndex first"
        return @()
    }
    $results = [System.Collections.ArrayList]::new()
    $totalFolders = $script:uniqueAclIndex.Count
    $current = 0
    if ($totalFolders -gt 200) {
        $msg = "Large search operation detected!`r`n`r`n"
        $msg += "Folders to scan: $totalFolders`r`n"
        $msg += "Estimated time: $([math]::Ceiling($totalFolders / 100)) minutes`r`n`r`n"
        $msg += "This operation cannot be cancelled once started.`r`n"
        $msg += "Continue with search?"
        $confirm = [System.Windows.Forms.MessageBox]::Show(
            $msg,
            "Large Search Operation",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) {
            return @()
        }
    }
    foreach ($folder in $script:uniqueAclIndex) {
        $current++
        if ($current % 25 -eq 0 -or $current -eq $totalFolders) {
            $percent = [math]::Round(($current / $totalFolders) * 100, 1)
            $script:form.Text = "FS-Manager Viewer - Searching ($current/$totalFolders - $percent%)..."
            [System.Windows.Forms.Application]::DoEvents()
        }
        try {
            $entries = Get-NtfsAclEntries -Path $folder.Path
            if ($entries) {
                foreach ($ace in $entries) {
                    if ($ace.IdentityReference.ToString() -like "*$Pattern*") {
                        [void]$results.Add([PSCustomObject]@{
                            PermType  = "NTFS"
                            Path      = $folder.Path
                            ShareName = $folder.ShareName
                            Principal = $ace.IdentityReference.ToString()
                            Rights    = $ace.FileSystemRights.ToString()
                            AclType   = $ace.AccessControlType.ToString()
                        })
                    }
                }
            }
        } catch [System.UnauthorizedAccessException] {
            Write-FsDebug -Category "Search" -Message "Access denied during search" -Details "Path=$($folder.Path)"
        } catch [System.IO.DirectoryNotFoundException] {
            Write-FsDebug -Category "Search" -Message "Directory not found during search" -Details "Path=$($folder.Path)"
        } catch [System.Management.Automation.CmdletProviderInvocationException] {
            Write-FsDebug -Category "Search" -Message "Provider exception during search" -Details "Path=$($folder.Path)"
        } catch {
            Write-FsDebug -Category "Search" -Message "Search error" -Details "Path=$($folder.Path); Error=$($_.Exception.Message)"
        }
    }
    $script:form.Text = "FS-Manager Viewer v1.0"
    if ($totalFolders -gt 50) {
        Write-FsInfo -Category "Search" -Message "Search completed" -Details "Scanned=$totalFolders; Results=$($results.Count); Pattern=$Pattern"
    }
    return $results
}
function Build-FilteredSubtree {
    param(
        [string]$Path,
        [string]$ShareName,
        [int]$MaxDepth = 50
    )
    if ($MaxDepth -le 0) { return $null }
    $hasUniqueAcl = $false
    $childNodes = [System.Collections.ArrayList]::new()
    try {
        $hasUniqueAcl = Get-UniqueAclFlag -Path $Path
    } catch {
        return $null  # Can't access - skip
    }
    try {
        $subfolders = Get-ChildItem -Path $Path -Directory -ErrorAction SilentlyContinue
        foreach ($subfolder in $subfolders) {
            $childNode = Build-FilteredSubtree -Path $subfolder.FullName -ShareName $ShareName -MaxDepth ($MaxDepth - 1)
            if ($childNode) {
                [void]$childNodes.Add($childNode)
            }
        }
    } catch {
    }
    if ($hasUniqueAcl -or $childNodes.Count -gt 0) {
        $node = New-Object System.Windows.Forms.TreeNode
        $node.Text = Split-Path $Path -Leaf
        $node.Tag = [PSCustomObject]@{
            Path      = $Path
            ShareName = $ShareName
        }
        if ($hasUniqueAcl) {
            $node.ForeColor = [System.Drawing.Color]::DarkRed
        }
        foreach ($childNode in $childNodes) {
            [void]$node.Nodes.Add($childNode)
        }
        return $node
    }
    return $null
}
function Add-ChildNodes {
    param(
        [System.Windows.Forms.TreeNode]$ParentNode,
        [string]$Path
    )
    $shares = Get-ShareData
    $sharePaths = @{}
    foreach ($sh in $shares) {
        $sharePaths[$sh.Path.TrimEnd('\')] = $sh.Name
    }
    $children = Get-FolderChildren -Path $Path
    foreach ($ch in $children) {
        $childPath = $ch.FullName.TrimEnd('\')
        $n = New-Object System.Windows.Forms.TreeNode
        $n.Text = $ch.Name
        $isShare = $sharePaths[$childPath]
        $shareName = if ($isShare) { $isShare } else { $ParentNode.Tag.ShareName }
        $n.Tag = [PSCustomObject]@{
            Path      = $ch.FullName
            ShareName = $shareName
        }
        if (Get-UniqueAclFlag -Path $ch.FullName) {
            $n.ForeColor = [System.Drawing.Color]::DarkRed
        } elseif ($isShare) {
            $n.ForeColor = [System.Drawing.Color]::FromArgb(0, 100, 180)
        }
        if ($isShare) {
            $n.Text = "$($ch.Name) [Share: $isShare]"
            $n.NodeFont = $script:fontBold
        }
        $dummy = New-Object System.Windows.Forms.TreeNode
        $dummy.Text = "..."
        $n.Nodes.Add($dummy) | Out-Null
        $ParentNode.Nodes.Add($n) | Out-Null
    }
}
function Populate-Tree {
    if (-not $script:tree) { return }
    $script:tree.Nodes.Clear()
    $showSharesOnly = $script:chkShowSharesOnly -and $script:chkShowSharesOnly.Checked
    $shares = Get-ShareData | Sort-Object Name
    $sharePaths = @{}
    foreach ($sh in $shares) {
        $sharePaths[$sh.Path.TrimEnd('\')] = $sh.Name
    }
    if ($showSharesOnly) {
        if (-not $script:uniqueAclIndex -and -not $script:isIndexBuilding) {
            Build-UniqueAclIndex
        }
        $foldersByShare = @{}
        foreach ($folder in $script:uniqueAclIndex) {
            if (-not $foldersByShare[$folder.ShareName]) {
                $foldersByShare[$folder.ShareName] = [System.Collections.ArrayList]::new()
            }
            [void]$foldersByShare[$folder.ShareName].Add($folder)
        }
        foreach ($sh in $shares) {
            $shareFolders = $foldersByShare[$sh.Name]
            $nShare = New-Object System.Windows.Forms.TreeNode
            $nShare.Text = "$($sh.Name)  ($($sh.Path))"
            $nShare.Tag = [PSCustomObject]@{
                Path      = $sh.Path
                ShareName = $sh.Name
            }
            $nShare.ForeColor = [System.Drawing.Color]::FromArgb(0, 100, 180)
            $nShare.NodeFont = $script:fontBold
            $shareRootInIndex = $shareFolders | ? { $_.Path -eq $sh.Path }
            if ($shareRootInIndex) {
                $nShare.ForeColor = [System.Drawing.Color]::DarkRed
            }
            if ($shareFolders) {
                foreach ($folder in $shareFolders) {
                    if ($folder.Path -eq $sh.Path) { continue }
                    $relativePath = $folder.Path.Substring($sh.Path.Length).TrimStart('\')
                    $nFolder = New-Object System.Windows.Forms.TreeNode
                    $nFolder.Text = $relativePath
                    $nFolder.Tag = [PSCustomObject]@{
                        Path      = $folder.Path
                        ShareName = $sh.Name
                    }
                    $nFolder.ForeColor = [System.Drawing.Color]::DarkRed
                    $nShare.Nodes.Add($nFolder) | Out-Null
                }
            }
            if ($shareFolders -and $shareFolders.Count -gt 0) {
                $script:tree.Nodes.Add($nShare) | Out-Null
            }
        }
        $uniqueCount = if ($script:uniqueAclIndex) { $script:uniqueAclIndex.Count } else { 0 }
        $script:lblTreeHint.Text = "Index: $uniqueCount folders | Red = unique ACL | Search is instant!"
    } else {
        try {
            $drives = [System.IO.DriveInfo]::GetDrives() | ? { $_.DriveType -eq 'Fixed' }
            foreach ($d in $drives) {
                $drivePath = $d.RootDirectory.FullName.TrimEnd('\')
                $nDrive = New-Object System.Windows.Forms.TreeNode
                $nDrive.Text = "$($d.Name)  $($d.VolumeLabel)"
                $nDrive.Tag = [PSCustomObject]@{ 
                    Path = $d.RootDirectory.FullName
                    ShareName = $sharePaths[$drivePath]
                }
                if (Get-UniqueAclFlag -Path $d.RootDirectory.FullName) {
                    $nDrive.ForeColor = [System.Drawing.Color]::DarkRed
                }
                if ($sharePaths[$drivePath]) {
                    $nDrive.Text = "$($d.Name)  $($d.VolumeLabel) [Share: $($sharePaths[$drivePath])]"
                    if ($nDrive.ForeColor.Name -ne "DarkRed") {
                        $nDrive.ForeColor = [System.Drawing.Color]::FromArgb(0, 100, 180)
                    }
                }
                $dummy = New-Object System.Windows.Forms.TreeNode
                $dummy.Text = "..."
                $nDrive.Nodes.Add($dummy) | Out-Null
                $script:tree.Nodes.Add($nDrive) | Out-Null
            }
        } catch {}
    }
}
function Highlight-SearchResults {
    param(
        [string]$Principal,
        [array]$SearchResults
    )
    $script:treeMode = "Search"
    $script:searchPrincipal = $Principal
    $script:searchPaths = @($SearchResults | % { $_.Path } | Select-Object -Unique)
    $script:lblTreeInfo.Text = "Search: $Principal ($($script:searchPaths.Count) locations)"
    $script:lblTreeInfo.ForeColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
    $script:lblTreeHint.Text = "Search results highlighted in yellow | Use checkbox to toggle view"
    $script:btnExitSearch.Visible = $true
    $script:chkShowSharesOnly.Enabled = $true  # Keep checkbox enabled
    $script:pnlLegend.Visible = $true
    Populate-Tree
    function Clear-Highlighting {
        param([System.Windows.Forms.TreeNode]$Node)
        $Node.BackColor = [System.Drawing.Color]::Empty
        if ($Node.Tag -and -not $Node.Tag.IsUniqueAcl) {
            $Node.NodeFont = $script:tree.Font  # Reset to normal font
        }
        foreach ($child in $Node.Nodes) {
            Clear-Highlighting -Node $child
        }
    }
    function Mark-SearchResults {
        param([System.Windows.Forms.TreeNode]$Node)
        if ($Node.Tag -and $Node.Tag.Path) {
            $nodePath = $Node.Tag.Path.TrimEnd('\')
            if ($script:searchPaths -contains $nodePath) {
                $Node.BackColor = [System.Drawing.Color]::LightYellow
                $Node.NodeFont = New-Object System.Drawing.Font($script:tree.Font, [System.Drawing.FontStyle]::Bold)
            }
        }
        foreach ($child in $Node.Nodes) {
            Mark-SearchResults -Node $child
        }
    }
    foreach ($rootNode in $script:tree.Nodes) {
        Clear-Highlighting -Node $rootNode
        Mark-SearchResults -Node $rootNode
    }
}
function Navigate-ToTreePath {
    param([string]$TargetPath)
    if (-not $TargetPath -or -not (Test-Path $TargetPath)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Path does not exist:`r`n$TargetPath",
            "Path Not Found",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return $false
    }
    $filterWasActive = $false
    $oldFilterText = ""
    if ($script:txtTreeFilter -and $script:txtTreeFilter.Text -ne "Filter shares/folders..." -and 
        -not [string]::IsNullOrWhiteSpace($script:txtTreeFilter.Text)) {
        $filterWasActive = $true
        $oldFilterText = $script:txtTreeFilter.Text
        $script:txtTreeFilter.Text = "Filter shares/folders..."
        $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Gray
        $script:btnTreeFilterClear.Visible = $false
        Populate-Tree
        $script:lblTreeInfo.Text = "Shares and Folders"
        echo "Navigation: Temporarily cleared tree filter '$oldFilterText' to enable navigation" -ForegroundColor Yellow
    }
    $targetPath = $TargetPath.TrimEnd('\')
    function Find-ExistingNode {
        param([System.Windows.Forms.TreeNode]$Node, [string]$SearchPath)
        if ($Node.Tag -and $Node.Tag.Path) {
            $nodePath = $Node.Tag.Path.TrimEnd('\')
            if ($nodePath -eq $SearchPath) { return $Node }
        }
        foreach ($child in $Node.Nodes) {
            if ($child.Text -eq "...") { continue }
            $found = Find-ExistingNode -Node $child -SearchPath $SearchPath
            if ($found) { return $found }
        }
        return $null
    }
    foreach ($rootNode in $script:tree.Nodes) {
        $existingNode = Find-ExistingNode -Node $rootNode -SearchPath $targetPath
        if ($existingNode) {
            $existingNode.EnsureVisible()
            $script:tree.SelectedNode = $existingNode
            if ($filterWasActive) {
                if ($script:treeMode -eq "Search") {
                    $script:txtTreeFilter.Text = $oldFilterText
                    $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Black
                    $script:btnTreeFilterClear.Visible = $true
                } else {
                    $result = [System.Windows.Forms.MessageBox]::Show(
                        "Navigation successful!`r`n`r`nTree filter '$oldFilterText' was cleared to enable navigation.`r`n`r`nDo you want to restore the filter?",
                        "Restore Filter?",
                        [System.Windows.Forms.MessageBoxButtons]::YesNo,
                        [System.Windows.Forms.MessageBoxIcon]::Question
                    )
                    if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
                        $script:txtTreeFilter.Text = $oldFilterText
                        $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Black
                        $script:btnTreeFilterClear.Visible = $true
                        Filter-Tree -FilterText $oldFilterText
                    }
                }
            }
            return $true
        }
    }
    $rootNode = $null
    $rootPath = $null
    foreach ($node in $script:tree.Nodes) {
        if ($node.Tag -and $node.Tag.Path) {
            $nodePath = $node.Tag.Path.TrimEnd('\')
            if ($targetPath.StartsWith($nodePath, [System.StringComparison]::OrdinalIgnoreCase)) {
                $rootNode = $node
                $rootPath = $nodePath
                break
            }
        }
    }
    if (-not $rootNode) {
        $driveLetter = $targetPath.Substring(0, 2)  # e.g., "E:"
        foreach ($node in $script:tree.Nodes) {
            if ($node.Text.StartsWith($driveLetter, [System.StringComparison]::OrdinalIgnoreCase)) {
                $rootNode = $node
                $rootPath = $driveLetter + "\"
                break
            }
        }
    }
    if (-not $rootNode) {
        [System.Windows.Forms.MessageBox]::Show(
            "Cannot find root node for path:`r`n$TargetPath`r`n`r`nThe path may be on a drive not shown in the tree.",
            "Path Not Found",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return $false
    }
    $relativePath = $targetPath.Substring($rootPath.Length).TrimStart('\')
    $pathParts = if ($relativePath) { $relativePath -split '\\' } else { @() }
    $currentNode = $rootNode
    foreach ($part in $pathParts) {
        if (-not $part) { continue }
        if ($currentNode.Nodes.Count -eq 1 -and $currentNode.Nodes[0].Text -eq "...") {
            $currentNode.Nodes.Clear()
            Add-ChildNodes -ParentNode $currentNode -Path $currentNode.Tag.Path
        }
        $foundChild = $null
        foreach ($child in $currentNode.Nodes) {
            $childName = $child.Text -replace '\s*\[Share:.*\]$', ''
            if ($childName -eq $part) {
                $foundChild = $child
                break
            }
            if ($child.Tag -and $child.Tag.Path) {
                $childPath = $child.Tag.Path.TrimEnd('\')
                $expectedPath = Join-Path $currentNode.Tag.Path $part
                if ($childPath -eq $expectedPath.TrimEnd('\')) {
                    $foundChild = $child
                    break
                }
            }
        }
        if ($foundChild) {
            $currentNode = $foundChild
        } else {
            [System.Windows.Forms.MessageBox]::Show(
                "Cannot navigate to:`r`n$TargetPath`r`n`r`nStopped at: $($currentNode.Tag.Path)`r`nFolder '$part' not found or not accessible.",
                "Navigation Stopped",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            $currentNode.EnsureVisible()
            $script:tree.SelectedNode = $currentNode
            return $false
        }
    }
    $currentNode.EnsureVisible()
    $script:tree.SelectedNode = $currentNode
    if ($filterWasActive) {
        if ($script:treeMode -eq "Search") {
            $script:txtTreeFilter.Text = $oldFilterText
            $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Black
            $script:btnTreeFilterClear.Visible = $true
        } else {
            $result = [System.Windows.Forms.MessageBox]::Show(
                "Navigation successful!`r`n`r`nTree filter '$oldFilterText' was cleared to enable navigation.`r`n`r`nDo you want to restore the filter?",
                "Restore Filter?",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )
            if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
                $script:txtTreeFilter.Text = $oldFilterText
                $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Black
                $script:btnTreeFilterClear.Visible = $true
                Filter-Tree -FilterText $oldFilterText
            }
        }
    }
    return $true
}
function Switch-ToBrowseMode {
    $script:treeMode = "Browse"
    $script:searchPrincipal = $null
    $script:searchPaths = @()
    $script:lblTreeInfo.Text = "Shares and Folders"
    $script:lblTreeInfo.ForeColor = $script:clrAccent
    $script:lblTreeHint.Text = "Red = unique ACL | Blue = shared folder"
    $script:btnExitSearch.Visible = $false
    $script:chkShowSharesOnly.Enabled = $true
    $script:pnlLegend.Visible = $false
    $script:txtTreeFilter.Visible = $true
    $script:btnTreeFilter.Visible = $true
    $script:tree.Location = New-Object System.Drawing.Point(10, 80)
    $script:tree.Size = New-Object System.Drawing.Size(428, 435)
    Populate-Tree
}
function Filter-Tree {
    param([string]$FilterText)
    if (-not $FilterText -or $FilterText -eq "Filter shares/folders...") {
        Populate-Tree
        return
    }
    $script:tree.Nodes.Clear()
    $filterLower = $FilterText.ToLower()
    $rootShares = New-Object System.Windows.Forms.TreeNode
    $rootShares.Text = "Shares (searching...)"
    $script:tree.Nodes.Add($rootShares) | Out-Null
    $shares = Get-ShareData | Sort-Object Name
    $matchCount = 0
    $searchSubfolders = {
        param($ParentPath, $ShareName, $ParentNode, $Depth)
        if ($Depth -gt 3) { return }
        try {
            $subfolders = Get-ChildItem -Path $ParentPath -Directory -ErrorAction SilentlyContinue
            foreach ($sub in $subfolders) {
                $nameMatches = $sub.Name.ToLower().Contains($filterLower)
                if ($nameMatches) {
                    $nSub = New-Object System.Windows.Forms.TreeNode
                    $nSub.Text = $sub.Name
                    $nSub.Tag = [PSCustomObject]@{
                        Path      = $sub.FullName
                        ShareName = $ShareName
                    }
                    $nSub.BackColor = [System.Drawing.Color]::FromArgb(255, 255, 200)
                    if (Get-UniqueAclFlag -Path $sub.FullName) {
                        $nSub.ForeColor = [System.Drawing.Color]::DarkRed
                    }
                    $ParentNode.Nodes.Add($nSub) | Out-Null
                    $script:folderMatches++
                }
                & $searchSubfolders $sub.FullName $ShareName $ParentNode ($Depth + 1)
            }
        } catch { }
    }
    $script:folderMatches = 0
    foreach ($sh in $shares) {
        $shareNameMatches = $sh.Name.ToLower().Contains($filterLower)
        $sharePathMatches = $sh.Path.ToLower().Contains($filterLower)
        $nShare = New-Object System.Windows.Forms.TreeNode
        $nShare.Text = "$($sh.Name)  ($($sh.Path))"
        $nShare.Tag = [PSCustomObject]@{
            Path      = $sh.Path
            ShareName = $sh.Name
        }
        if ($shareNameMatches -or $sharePathMatches) {
            $nShare.BackColor = [System.Drawing.Color]::FromArgb(255, 255, 200)
            $matchCount++
        }
        if (Get-UniqueAclFlag -Path $sh.Path) {
            $nShare.ForeColor = [System.Drawing.Color]::DarkRed
        }
        $beforeCount = $script:folderMatches
        & $searchSubfolders $sh.Path $sh.Name $nShare 0
        $hasSubfolderMatches = ($script:folderMatches -gt $beforeCount)
        if ($shareNameMatches -or $sharePathMatches -or $hasSubfolderMatches) {
            if (-not $hasSubfolderMatches) {
                $dummy = New-Object System.Windows.Forms.TreeNode
                $dummy.Text = "..."
                $nShare.Nodes.Add($dummy) | Out-Null
            }
            $rootShares.Nodes.Add($nShare) | Out-Null
        }
    }
    $folderMatchCount = $script:folderMatches
    $totalMatches = $matchCount + $folderMatchCount
    $rootShares.Text = "Shares ($totalMatches matches for '$FilterText')"
    $rootShares.Expand()
    foreach ($node in $rootShares.Nodes) {
        if ($node.Nodes.Count -gt 0 -and $node.Nodes[0].Text -ne "...") {
            $node.Expand()
        }
    }
    $script:lblTreeInfo.Text = "Filter: $matchCount shares, $folderMatchCount folders match '$FilterText'"
}
function Switch-ToSearchMode {
    param(
        [string]$Principal,
        [array]$SearchResults
    )
    $script:treeMode = "Search"
    $script:searchPrincipal = $Principal
    $script:searchPaths = @($SearchResults | % { $_.Path } | Select-Object -Unique)
    $script:lblTreeInfo.Text = "Search: $Principal ($($script:searchPaths.Count) locations)"
    $script:lblTreeInfo.ForeColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
    $script:lblTreeHint.Text = "Search results highlighted | Use checkbox to toggle view mode"
    $script:btnExitSearch.Visible = $true
    $script:chkShowSharesOnly.Enabled = $true  # Keep checkbox enabled
    $script:pnlLegend.Visible = $true
    $script:txtTreeFilter.Visible = $false
    $script:btnTreeFilter.Visible = $false
    $script:btnTreeFilterClear.Visible = $false
    $script:tree.Location = New-Object System.Drawing.Point(10, 100)
    $script:tree.Size = New-Object System.Drawing.Size(428, 415)
    Populate-Tree
    $shareGroups = $SearchResults | ? { $_.ShareName } | Group-Object ShareName
    $driveResults = $SearchResults | ? { -not $_.ShareName }
    $rootSearch = New-Object System.Windows.Forms.TreeNode
    $rootSearch.Text = "Search Results for: $Principal"
    $rootSearch.ForeColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
    $rootSearch.NodeFont = New-Object System.Drawing.Font($script:tree.Font, [System.Drawing.FontStyle]::Bold)
    $script:tree.Nodes.Add($rootSearch) | Out-Null
    if ($shareGroups.Count -gt 0) {
        $sharesNode = New-Object System.Windows.Forms.TreeNode
        $sharesNode.Text = "Shares ($($shareGroups.Count))"
        $rootSearch.Nodes.Add($sharesNode) | Out-Null
        foreach ($sg in $shareGroups) {
            $shareName = $sg.Name
            $shareResults = $sg.Group
            $sharePath = ($shareResults | Select-Object -First 1).Path
            $shareInfo = Get-ShareData | ? { $_.Name -eq $shareName } | Select-Object -First 1
            $shareRootPath = if ($shareInfo) { $shareInfo.Path } else { $sharePath }
            $shareNode = New-Object System.Windows.Forms.TreeNode
            $shareNode.Text = "$shareName  ($shareRootPath)"
            $shareNode.Tag = [PSCustomObject]@{
                Path      = $shareRootPath
                ShareName = $shareName
                Type      = "ShareRoot"
                IsSearchResult = $true
            }
            $hasSharePerm = $shareResults | ? { $_.PermType -eq "Share" }
            $hasNtfsPerm = $shareResults | ? { $_.PermType -eq "NTFS" }
            if ($hasSharePerm -and $hasNtfsPerm) {
                $shareNode.ForeColor = [System.Drawing.Color]::Purple
            } elseif ($hasSharePerm) {
                $shareNode.ForeColor = [System.Drawing.Color]::DarkBlue
            } else {
                $shareNode.ForeColor = [System.Drawing.Color]::DarkRed
            }
            $sharesNode.Nodes.Add($shareNode) | Out-Null
            $ntfsResults = $shareResults | ? { $_.PermType -eq "NTFS" -and $_.Path -ne $shareRootPath }
            $uniquePaths = $ntfsResults | % { $_.Path } | Select-Object -Unique
            foreach ($folderPath in $uniquePaths) {
                $relativePath = $folderPath
                if ($folderPath.StartsWith($shareRootPath)) {
                    $relativePath = $folderPath.Substring($shareRootPath.Length).TrimStart('\')
                }
                $folderNode = New-Object System.Windows.Forms.TreeNode
                $folderNode.Text = if ($relativePath) { $relativePath } else { "(root)" }
                $folderNode.Tag = [PSCustomObject]@{
                    Path      = $folderPath
                    ShareName = $shareName
                    Type      = "Folder"
                    IsSearchResult = $true
                }
                $folderNode.ForeColor = [System.Drawing.Color]::DarkRed
                $shareNode.Nodes.Add($folderNode) | Out-Null
            }
            $shareNode.Expand()
        }
        $sharesNode.Expand()
    }
    if ($driveResults.Count -gt 0) {
        $drivesNode = New-Object System.Windows.Forms.TreeNode
        $drivesNode.Text = "Local Paths"
        $rootSearch.Nodes.Add($drivesNode) | Out-Null
        foreach ($dr in $driveResults) {
            $driveNode = New-Object System.Windows.Forms.TreeNode
            $driveNode.Text = $dr.Path
            $driveNode.Tag = [PSCustomObject]@{
                Path      = $dr.Path
                ShareName = $null
                Type      = "Folder"
                IsSearchResult = $true
            }
            $driveNode.ForeColor = [System.Drawing.Color]::DarkRed
            $drivesNode.Nodes.Add($driveNode) | Out-Null
        }
        $drivesNode.Expand()
    }
    $rootSearch.Expand()
    if ($rootSearch.Nodes.Count -gt 0) {
        $firstChild = $rootSearch.Nodes[0]
        if ($firstChild.Nodes.Count -gt 0) {
            $script:tree.SelectedNode = $firstChild.Nodes[0]
        }
    }
}

