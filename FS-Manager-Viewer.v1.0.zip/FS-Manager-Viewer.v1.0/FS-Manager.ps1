﻿<#
.SYNOPSIS
    FS-Manager Viewer v1.0 - Read-Only File System Permissions Viewer
.DESCRIPTION
    Free read-only version for viewing NTFS permissions, Share permissions, and FSRM quotas.
    For full modification capabilities, upgrade to FS-Manager Pro.
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
    
    Build: 20251127
#>

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $scriptPath = $MyInvocation.MyCommand.Definition
    $elevated = $false
    try {
        $proc = Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`"" -Verb RunAs -PassThru -ErrorAction Stop
        if ($proc) { $elevated = $true }
    } catch {
        $elevated = $false
    }
    if (-not $elevated) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "FS-Manager Viewer requires Administrator privileges.`r`n`r`nPlease right-click and select 'Run as Administrator'.",
            "Elevation Required",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
    }
    exit
}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Set Viewer mode flag - this enables read-only mode throughout the application
$script:isViewerVersion = $true
$moduleDir = Join-Path $PSScriptRoot 'Modules'
$helperModules = @(
    'FSManager.Logging.ps1',
    'FSManager.Ad.ps1',
    'FSManager.Acl.ps1',
    'FSManager.Share.ps1',
    'FSManager.Fsrm.ps1'
)
foreach ($m in $helperModules) {
    $p = Join-Path $moduleDir $m
    if (Test-Path $p) {
        try { . $p } catch {
            [System.Windows.Forms.MessageBox]::Show("Error loading module: $m`r`n$($_.Exception.Message)", "Error",
                [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
            exit 1
        }
    }
}
$uiCoreModules = @(
    'FSManager.UI.Core.ps1',
    'FSManager.UI.Tabs.ps1',
    'FSManager.UI.Tree.ps1'
)
foreach ($m in $uiCoreModules) {
    $p = Join-Path $moduleDir $m
    if (Test-Path $p) {
        try { . $p } catch {
            [System.Windows.Forms.MessageBox]::Show("Error loading module: $m`r`n$($_.Exception.Message)", "Error",
                [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
            exit 1
        }
    }
}
$script:isIndexBuilding = $false
if (Get-Command Start-FSManagerUI_Core -ErrorAction SilentlyContinue) {
    try { Start-FSManagerUI_Core } catch {
        [System.Windows.Forms.MessageBox]::Show("Error creating UI controls: $($_.Exception.Message)", "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        exit 1
    }
}
$handlerModules = @(
    'FSManager.UI.Handlers.Quota.ps1',
    'FSManager.UI.Handlers.Share.ps1',
    'FSManager.UI.Handlers.Ntfs.ps1',
    'FSManager.UI.Handlers.ps1',
    'FSManager.UI.Handlers.Core.ps1',
    'FSManager.UI.ps1'
)
foreach ($m in $handlerModules) {
    $p = Join-Path $moduleDir $m
    if (Test-Path $p) {
        try { . $p } catch {
            [System.Windows.Forms.MessageBox]::Show("Error loading module: $m`r`n$($_.Exception.Message)", "Error",
                [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
            exit 1
        }
    }
}
if (-not (Get-Command Start-FSManagerUI -ErrorAction SilentlyContinue)) {
    [System.Windows.Forms.MessageBox]::Show(
        'UI module failed to load. Check Modules\ folder.', 
        'Error', 
        [System.Windows.Forms.MessageBoxButtons]::OK, 
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}
if (Get-Command Write-FsAppStart -ErrorAction SilentlyContinue) {
    Write-FsAppStart
}
Start-FSManagerUI
[void]$script:form.ShowDialog()
if (Get-Command Write-FsAppStop -ErrorAction SilentlyContinue) {
    Write-FsAppStop
}

