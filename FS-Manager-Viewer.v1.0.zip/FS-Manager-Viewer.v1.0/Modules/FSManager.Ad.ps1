<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.Ad.ps1
# Build: 20251126-142332

function Search-AdPrincipals {
    param(
        [string]$Filter = "",
        [int]$MaxResults = 50
    )
    if ($Filter.Length -lt 2) { return @() }
    $results = [System.Collections.ArrayList]::new()
    try {
        $root = New-Object System.DirectoryServices.DirectoryEntry
        $searcher = New-Object System.DirectoryServices.DirectorySearcher $root
        $escapedFilter = $Filter -replace '([\\*\(\)])', '\$1'
        $searcher.Filter = "(&(|(objectClass=user)(objectClass=group))(|(sAMAccountName=*$escapedFilter*)(displayName=*$escapedFilter*)(cn=*$escapedFilter*)))"
        $searcher.PageSize = 100
        $searcher.SizeLimit = $MaxResults
        $null = $searcher.PropertiesToLoad.Add("sAMAccountName")
        $null = $searcher.PropertiesToLoad.Add("displayName")
        $null = $searcher.PropertiesToLoad.Add("cn")
        $null = $searcher.PropertiesToLoad.Add("objectClass")
        $null = $searcher.PropertiesToLoad.Add("mail")
        $searchResults = $searcher.FindAll()
        foreach ($r in $searchResults) {
            $sam = $r.Properties["samaccountname"][0]
            if (-not $sam) { continue }
            $disp = $r.Properties["displayname"][0]
            $cn = $r.Properties["cn"][0]
            $mail = $r.Properties["mail"][0]
            $oc = @()
            if ($r.Properties["objectclass"]) { 
                $oc = $r.Properties["objectclass"] | % { $_.ToString().ToLower() } 
            }
            $isGroup = $oc -contains 'group'
            $isUser = $oc -contains 'user' -or $oc -contains 'person'
            $typeLabel = if ($isGroup) { 'Group' } elseif ($isUser) { 'User' } else { 'Other' }
            [void]$results.Add([pscustomobject]@{
                SamAccountName = $sam
                DisplayName    = if ($disp) { $disp } elseif ($cn) { $cn } else { $sam }
                Entity         = $typeLabel
                Email          = $mail
            })
        }
        $searchResults.Dispose()
    } catch {
    }
    return $results
}
function Resolve-PrincipalName {
    param([string]$InputName,[switch]$AllowPartial)
    $raw = $InputName.Trim()
    if (-not $raw) { return $null }
    try {
        $nt  = New-Object System.Security.Principal.NTAccount($raw)
        $sid = $nt.Translate([System.Security.Principal.SecurityIdentifier])
        return $nt.Value
    } catch {}
    if ($raw -notmatch '[\\@]') {
        $dom = $env:USERDOMAIN
        if ($dom) {
            $candidate = "$dom\$raw"
            try {
                $nt  = New-Object System.Security.Principal.NTAccount($candidate)
                $sid = $nt.Translate([System.Security.Principal.SecurityIdentifier])
                return $nt.Value
            } catch {}
        }
    }
    if (-not $AllowPartial) { return $null }
    $items = Search-AdPrincipals -Filter "*$raw*"
    if ($items.Count -eq 1) {
        $sam = $items[0].SamAccountName
        $dom = $env:USERDOMAIN
        return "$dom\$sam"
    } elseif ($items.Count -gt 1) {
        [System.Windows.Forms.MessageBox]::Show("Multiple results found for '$raw'. Narrow the search.","Multiple results",
            [System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        return $null
    } else { return $null }
}
function Show-AdUserPicker {
    param([switch]$MultiSelect)
    try {
        $dlg = New-Object System.Windows.Forms.Form
        $dlg.Text = if ($MultiSelect) { "AD Search - Multi-select" } else { "AD Search" }
        $dlg.Size = New-Object System.Drawing.Size(650, 520)
        $dlg.StartPosition = "CenterParent"
        $dlg.KeyPreview = $true
        $dlg.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
        $dlg.MaximizeBox = $false
        $dlg.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
        $pnlHeader = New-Object System.Windows.Forms.Panel
        $pnlHeader.Location = New-Object System.Drawing.Point(0, 0)
        $pnlHeader.Size = New-Object System.Drawing.Size(650, 70)
        $pnlHeader.BackColor = [System.Drawing.Color]::FromArgb(45, 65, 95)
        $lblTitle = New-Object System.Windows.Forms.Label
        $lblTitle.Location = New-Object System.Drawing.Point(15, 10)
        $lblTitle.Size = New-Object System.Drawing.Size(400, 25)
        $lblTitle.Text = "Active Directory Search"
        $lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
        $lblTitle.ForeColor = [System.Drawing.Color]::White
        $pnlHeader.Controls.Add($lblTitle)
        $lblSubtitle = New-Object System.Windows.Forms.Label
        $lblSubtitle.Location = New-Object System.Drawing.Point(15, 38)
        $lblSubtitle.Size = New-Object System.Drawing.Size(600, 20)
        $lblSubtitle.Text = "Type 2+ characters to search by username or display name"
        $lblSubtitle.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $lblSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(180, 200, 220)
        $pnlHeader.Controls.Add($lblSubtitle)
        $dlg.Controls.Add($pnlHeader)
        $lblSearch = New-Object System.Windows.Forms.Label
        $lblSearch.Location = New-Object System.Drawing.Point(15, 82)
        $lblSearch.Size = New-Object System.Drawing.Size(200, 20)
        $lblSearch.Text = "Search (username or display name):"
        $lblSearch.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $txtFilter = New-Object System.Windows.Forms.TextBox
        $txtFilter.Location = New-Object System.Drawing.Point(15, 102)
        $txtFilter.Size = New-Object System.Drawing.Size(610, 25)
        $txtFilter.Font = New-Object System.Drawing.Font("Segoe UI", 10)
        $dlg.Controls.Add($lblSearch)
        $dlg.Controls.Add($txtFilter)
        $lvAd = New-Object System.Windows.Forms.ListView
        $lvAd.Location = New-Object System.Drawing.Point(15, 140)
        $lvAd.Size = New-Object System.Drawing.Size(610, 280)
        $lvAd.View = [System.Windows.Forms.View]::Details
        $lvAd.FullRowSelect = $true
        $lvAd.GridLines = $true
        $lvAd.MultiSelect = $MultiSelect
        $lvAd.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $lvAd.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $null = $lvAd.Columns.Add("SAM Account", 160)
        $null = $lvAd.Columns.Add("Display Name", 300)
        $null = $lvAd.Columns.Add("Type", 100)
        $dlg.Controls.Add($lvAd)
        $lblStatus = New-Object System.Windows.Forms.Label
        $lblStatus.Location = New-Object System.Drawing.Point(15, 428)
        $lblStatus.Size = New-Object System.Drawing.Size(400, 20)
        $lblStatus.Text = "Type at least 2 characters to search..."
        $lblStatus.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
        $dlg.Controls.Add($lblStatus)
        $btnOk = New-Object System.Windows.Forms.Button
        $btnOk.Location = New-Object System.Drawing.Point(430, 450)
        $btnOk.Size = New-Object System.Drawing.Size(90, 30)
        $btnOk.Text = "Select"
        $btnOk.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnOk.BackColor = [System.Drawing.Color]::FromArgb(40, 120, 80)
        $btnOk.ForeColor = [System.Drawing.Color]::White
        $btnOk.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnOk.Cursor = [System.Windows.Forms.Cursors]::Hand
        $btnCancel = New-Object System.Windows.Forms.Button
        $btnCancel.Location = New-Object System.Drawing.Point(530, 450)
        $btnCancel.Size = New-Object System.Drawing.Size(90, 30)
        $btnCancel.Text = "Cancel"
        $btnCancel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnCancel.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnCancel.Cursor = [System.Windows.Forms.Cursors]::Hand
        $dlg.CancelButton = $btnCancel
        $dlg.Controls.Add($btnOk)
        $dlg.Controls.Add($btnCancel)
        $script:__adPickerResult = $null
        $selectAndClose = {
            $dom = $env:USERDOMAIN
            if ($MultiSelect) {
                $script:__adPickerResult = @()
                foreach ($sel in $lvAd.SelectedItems) {
                    $script:__adPickerResult += "$dom\$($sel.Tag.SamAccountName)"
                }
            } else {
                $script:__adPickerResult = "$dom\$($lvAd.SelectedItems[0].Tag.SamAccountName)"
            }
            $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $dlg.Close()
        }
        $populateList = {
            param($filter)
            $lvAd.Items.Clear()
            if ($filter.Length -lt 2) {
                $lblStatus.Text = "Type at least 2 characters to search..."
                $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
                return
            }
            $lblStatus.Text = "Searching '$filter'..."
            $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
            $dlg.Refresh()
            [System.Windows.Forms.Application]::DoEvents()
            try {
                $items = Search-AdPrincipals -Filter $filter -MaxResults 50
                $filterLower = $filter.ToLower()
                $sorted = $items | % {
                    $priority = 3  # Default: other match
                    $samLower = $_.SamAccountName.ToLower()
                    $dispLower = $_.DisplayName.ToLower()
                    if ($samLower.StartsWith($filterLower)) { $priority = 0 }
                    elseif ($samLower.Contains($filterLower)) { $priority = 1 }
                    elseif ($dispLower.Contains($filterLower)) { $priority = 2 }
                    $_ | Add-Member -NotePropertyName "_Priority" -NotePropertyValue $priority -PassThru
                } | Sort-Object _Priority, SamAccountName
                foreach ($item in $sorted) {
                    $lvi = New-Object System.Windows.Forms.ListViewItem
                    $lvi.Tag = $item
                    if ($item.Entity -eq "Group") {
                        $lvi.ForeColor = [System.Drawing.Color]::FromArgb(30, 80, 150)
                        $lvi.Text = "[G] " + $item.SamAccountName
                    } else {
                        $lvi.ForeColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
                        $lvi.Text = "[U] " + $item.SamAccountName
                    }
                    $null = $lvi.SubItems.Add($item.DisplayName)
                    $null = $lvi.SubItems.Add($item.Entity)
                    $lvAd.Items.Add($lvi) | Out-Null
                }
                $count = $lvAd.Items.Count
                if ($count -eq 0) {
                    $lblStatus.Text = "No results for '$filter' - try different keywords"
                    $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(180, 80, 80)
                } else {
                    $lblStatus.Text = "Found $count result(s) - double-click or Enter to select"
                    $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 80)
                    $lvAd.Items[0].Selected = $true
                    $lvAd.Items[0].Focused = $true
                }
            } catch {
                $lblStatus.Text = "Search error: $($_.Exception.Message)"
                $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(180, 80, 80)
            }
        }
        $script:__adSearchTimer = New-Object System.Windows.Forms.Timer
        $script:__adSearchTimer.Interval = 400  # 400ms debounce
        $script:__adSearchText = ""
        $script:__adSearchListView = $lvAd
        $script:__adSearchStatus = $lblStatus
        $script:__adSearchDlg = $dlg
        $script:__adPopulateList = $populateList
        $script:__adSearchTimer.Add_Tick({
            $script:__adSearchTimer.Stop()
            & $script:__adPopulateList $script:__adSearchText
        })
        $txtFilter.Add_TextChanged({
            $script:__adSearchText = $txtFilter.Text
            $script:__adSearchTimer.Stop()
            $script:__adSearchTimer.Start()  # Restart debounce timer
        })
        $txtFilter.Add_KeyDown({
            param($sender, $e)
            if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
                if ($lvAd.Items.Count -gt 0 -and $lvAd.SelectedItems.Count -gt 0) {
                    & $selectAndClose
                }
                $e.Handled = $true
                $e.SuppressKeyPress = $true
            }
        })
        $lvAd.Add_DoubleClick({
            if ($lvAd.SelectedItems.Count -gt 0) {
                & $selectAndClose
            }
        })
        $lvAd.Add_KeyDown({
            param($sender, $e)
            if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter -and $lvAd.SelectedItems.Count -gt 0) {
                & $selectAndClose
                $e.Handled = $true
                $e.SuppressKeyPress = $true
            }
        })
        $btnOk.Add_Click({
            if ($lvAd.SelectedItems.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show(
                    "Please select at least one item from the list.",
                    "No Selection",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information
                ) | Out-Null
                return
            }
            & $selectAndClose
        })
        $btnCancel.Add_Click({
            $dlg.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
            $dlg.Close()
        })
        $dlg.Add_Shown({ 
            $txtFilter.Focus()
            $txtFilter.SelectAll()
        })
        [void]$dlg.ShowDialog()
        $result = $script:__adPickerResult
        $script:__adPickerResult = $null
        return $result
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Cannot open AD search:`r`nDetails: $($_.Exception.Message)","AD search error",
            [System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        return $null
    }
}
$script:DisplayNameCache = @{}
function Get-DisplayNameForIdentity {
    param([string]$Identity)
    if ([string]::IsNullOrWhiteSpace($Identity)) { return $null }
    if ($script:DisplayNameCache.ContainsKey($Identity)) {
        return $script:DisplayNameCache[$Identity]
    }
    $sam = $Identity
    if ($Identity -match "^[^\\]+\\(.+)$") {
        $sam = $Matches[1]
    }
    try {
        $searcher = New-Object System.DirectoryServices.DirectorySearcher
        $searcher.Filter = "(|(samAccountName=$sam)(name=$sam))"
        $searcher.PropertiesToLoad.Add("displayName") | Out-Null
        $searcher.PropertiesToLoad.Add("objectClass") | Out-Null
        $res = $searcher.FindOne()
        if ($res) {
            $dn   = $null
            if ($res.Properties["displayname"].Count -gt 0) {
                $dn = $res.Properties["displayname"][0]
            }
            $oc = @()
            if ($res.Properties["objectclass"]) { $oc = $res.Properties["objectclass"] | % { $_.ToString().ToLower() } }
            $isGroup = $oc -contains 'group'
            $isUser  = $oc -contains 'user' -or $oc -contains 'person'
            $typeLabel  = if ($isGroup) { 'Group' } elseif ($isUser) { 'User' } else { ($oc | Select-Object -Last 1) }
            $val  = if ($dn) { $dn } else { $sam }
            $script:DisplayNameCache[$Identity] = $val
            return $val
        }
    } catch {
    }
    $script:DisplayNameCache[$Identity] = $Identity
    return $Identity
}
function Get-PrincipalInfo {
    param([string]$Identity)
    if ([string]::IsNullOrWhiteSpace($Identity)) {
        return [pscustomobject]@{ DisplayName = $null; Entity = 'Unknown' }
    }
    try {
        $sam = $Identity
        if ($Identity -match "^[^\\]+\\(.+)$") { $sam = $Matches[1] }
        $searcher = New-Object System.DirectoryServices.DirectorySearcher
        $searcher.Filter = "(|(samAccountName=$sam)(name=$sam))"
        $searcher.PropertiesToLoad.Add("displayName") | Out-Null
        $searcher.PropertiesToLoad.Add("objectClass") | Out-Null
        $res = $searcher.FindOne()
        if ($res) {
            $dn = $null
            if ($res.Properties["displayname"].Count -gt 0) { $dn = $res.Properties["displayname"][0] }
            $oc = @()
            if ($res.Properties["objectclass"]) { $oc = $res.Properties["objectclass"] | % { $_.ToString().ToLower() } }
            $isGroup = $oc -contains 'group'
            $isUser  = $oc -contains 'user' -or $oc -contains 'person'
            $type  = if ($isGroup) { 'Group' } elseif ($isUser) { 'User' } else { ($oc | Select-Object -Last 1) }
            $display = if ($dn) { $dn } else { $sam }
            return [pscustomobject]@{ DisplayName = $display; Entity = $type }
        }
    } catch {
    }
    return [pscustomobject]@{ DisplayName = $Identity; Entity = 'Unknown' }
}

