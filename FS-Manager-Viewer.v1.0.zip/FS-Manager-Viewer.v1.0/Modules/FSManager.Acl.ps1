<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.Acl.ps1
# Build: 20251126-142332

function Invoke-AclOperation {
    param(
        [scriptblock]$Operation,
        [string]$OperationName = "ACL Operation",
        [string]$Path = "",
        [int]$TimeoutSeconds = 10
    )
    try {
        Write-FsDebug -Category "ACL" -Message "Starting: $OperationName" -Details "Path=$Path; Timeout=${TimeoutSeconds}s"
        if ($Path -and -not (Test-Path -Path $Path -ErrorAction SilentlyContinue)) {
            $errMsg = "Path does not exist or is not accessible: $Path"
            Write-FsError -Category "ACL" -Message $OperationName -Details $errMsg
            throw $errMsg
        }
        $runspace = [runspacefactory]::CreateRunspace()
        $runspace.Open()
        $ps = [powershell]::Create()
        $ps.Runspace = $runspace
        $ps.AddScript($Operation) | Out-Null
        $handle = $ps.BeginInvoke()
        $completed = $handle.AsyncWaitHandle.WaitOne($TimeoutSeconds * 1000)
        if (-not $completed) {
            $ps.Stop()
            $runspace.Close()
            $errMsg = "Operation timed out after ${TimeoutSeconds}s - path may be inaccessible or have permission issues"
            Write-FsError -Category "ACL" -Message "$OperationName TIMEOUT" -Details "Path=$Path"
            throw $errMsg
        }
        $result = $ps.EndInvoke($handle)
        if ($ps.HadErrors) {
            $errMsg = $ps.Streams.Error | % { $_.Exception.Message } | Join-String -Separator "; "
            $runspace.Close()
            Write-FsError -Category "ACL" -Message "$OperationName FAILED" -Details "Path=$Path; Error=$errMsg"
            throw $errMsg
        }
        $runspace.Close()
        Write-FsDebug -Category "ACL" -Message "Completed: $OperationName" -Details "Path=$Path"
        return $result
    } catch {
        Write-FsError -Category "ACL" -Message "$OperationName ERROR" -Details "Path=$Path" -Exception $_.Exception
        throw
    }
}
function Get-AclSafe {
    param(
        [string]$Path,
        [int]$TimeoutSeconds = 5
    )
    try {
        if ([string]::IsNullOrWhiteSpace($Path)) {
            return $null
        }
        $testAccess = [System.IO.Directory]::GetAccessControl($Path, [System.Security.AccessControl.AccessControlSections]::Access)
        return Get-Acl -Path $Path -ErrorAction Stop
    } catch [System.UnauthorizedAccessException] {
        Write-FsDebug -Category "ACL" -Message "Access denied" -Details "Path=$Path"
        return $null
    } catch [System.IO.DirectoryNotFoundException] {
        Write-FsDebug -Category "ACL" -Message "Directory not found" -Details "Path=$Path"
        return $null
    } catch [System.Management.Automation.CmdletProviderInvocationException] {
        Write-FsDebug -Category "ACL" -Message "Provider exception" -Details "Path=$Path"
        return $null
    } catch {
        Write-FsDebug -Category "ACL" -Message "Get-Acl failed" -Details "Path=$Path; Error=$($_.Exception.Message)"
        return $null
    }
}
function Set-AclSafe {
    param(
        [string]$Path,
        [System.Security.AccessControl.DirectorySecurity]$AclObject,
        [int]$TimeoutSeconds = 10
    )
    try {
        Write-FsDebug -Category "ACL" -Message "Set-AclSafe starting" -Details "Path=$Path"
        if (-not (Test-Path $Path)) {
            throw "Path does not exist: $Path"
        }
        Set-Acl -Path $Path -AclObject $AclObject -ErrorAction Stop
        Write-FsDebug -Category "ACL" -Message "Set-AclSafe completed" -Details "Path=$Path"
    } catch [System.UnauthorizedAccessException] {
        Write-FsError -Category "ACL" -Message "Access Denied on Set-Acl" -Details "Path=$Path"
        throw "Access Denied: You don't have permission to modify ACL on '$Path'"
    } catch {
        Write-FsError -Category "ACL" -Message "Set-Acl Failed" -Details "Path=$Path" -Exception $_.Exception
        throw
    }
}
function Get-NtfsAclEntries {
    param(
        [string]$Path,
        [switch]$IncludeInherited
    )
    try {
        $acl = Get-AclSafe -Path $Path
        if (-not $acl) { return $null }
        $entries = $acl.Access
        if ($IncludeInherited) { return $entries }
        return $entries | ? { -not $_.IsInherited }
    } catch [System.UnauthorizedAccessException] {
        return $null
    } catch [System.IO.DirectoryNotFoundException] {
        return $null
    } catch [System.Management.Automation.CmdletProviderInvocationException] {
        return $null
    } catch {
        Write-FsDebug -Category "ACL" -Message "Get-NtfsAclEntries failed" -Details "Path=$Path; Error=$($_.Exception.Message)"
        return $null
    }
}
function Get-UniqueAclFlag {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $false
    }
    try {
        $dirInfo = New-Object System.IO.DirectoryInfo($Path)
        $security = $dirInfo.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
        return $security.AreAccessRulesProtected
    } catch [System.UnauthorizedAccessException] {
        return $false
    } catch [System.IO.DirectoryNotFoundException] {
        return $false
    } catch [System.IO.IOException] {
        return $false
    } catch [System.ArgumentException] {
        return $false
    } catch {
        try {
            if ($Path.StartsWith("\\")) {
                return $false
            }
            $acl = Get-Acl -Path $Path -ErrorAction Stop
            return $acl.AreAccessRulesProtected
        } catch {
            Write-FsDebug -Category "ACL" -Message "ACL check failed - assuming inherited" -Details "Path=$Path; Error=$($_.Exception.Message)"
            return $false
        }
    }
}
function Test-AclWriteAccess {
    param([string]$Path)
    try {
        $acl = [System.IO.Directory]::GetAccessControl($Path, [System.Security.AccessControl.AccessControlSections]::Access)
        $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object System.Security.Principal.WindowsPrincipal($currentUser)
        if ($principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
            return $true
        }
        $testAcl = Get-Acl -Path $Path -ErrorAction Stop
        return $true
    } catch [System.UnauthorizedAccessException] {
        return $false
    } catch {
        return $false
    }
}
function Set-AclFromTemplate {
    param(
        [string]$Path,
        [System.Security.AccessControl.DirectorySecurity]$TemplateAcl
    )
    try {
        Write-FsDebug -Category "ACL" -Message "Applying ACL template" -Details "Path=$Path"
        $targetAcl = Get-AclSafe -Path $Path
        $targetAcl.SetAccessRuleProtection($TemplateAcl.AreAccessRulesProtected, $false)
        foreach ($rule in @($targetAcl.Access | ? { -not $_.IsInherited })) {
            $targetAcl.RemoveAccessRule($rule) | Out-Null
        }
        foreach ($rule in @($TemplateAcl.Access | ? { -not $_.IsInherited })) {
            $targetAcl.AddAccessRule($rule)
        }
        Set-AclSafe -Path $Path -AclObject $targetAcl
        Write-FsInfo -Category "ACL" -Message "ACL template applied successfully" -Details "Path=$Path"
    } catch {
        Write-FsError -Category "ACL" -Message "Set-AclFromTemplate failed" -Details "Path=$Path" -Exception $_.Exception
        throw
    }
}

