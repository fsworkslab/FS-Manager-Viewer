<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Handlers.Quota.ps1
# Build: 20251126-142332

function btnCalcSize_Click {
    if (-not $script:currentPath) {
        [System.Windows.Forms.MessageBox]::Show("Please select a folder/share in the tree first.", "Info",
            [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        return
    }
    $res = [System.Windows.Forms.MessageBox]::Show("Calculating size may take time depending on number of files.`r`nContinue for:`r`n$script:currentPath ?",
        "Confirm", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($res -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    try {
        $script:lblFolderSize.Text = "Current size: calculating..."
        $script:form.Refresh()
        $bytes = Get-FolderSizeBytes -Path $script:currentPath
        if ($bytes -eq $null) {
            $script:lblFolderSize.Text = "Current size: error reading."
        } else {
            $gb = [math]::Round(($bytes / 1GB), 2)
            $script:lblFolderSize.Text = "Current size: $gb GB"
        }
    } catch {
        $script:lblFolderSize.Text = "Current size: error."
    }
}

