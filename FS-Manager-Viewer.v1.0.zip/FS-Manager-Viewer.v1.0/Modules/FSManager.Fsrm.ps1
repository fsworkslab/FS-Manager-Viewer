<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.Fsrm.ps1
# Build: 20251126-142332

$fsrmAvailable = $false
if (Get-Module -ListAvailable -Name FileServerResourceManager) {
    try {
        Import-Module FileServerResourceManager -ErrorAction Stop
        $fsrmAvailable = $true
    } catch {
        $fsrmAvailable = $false
    }
}
function Get-QuotaInfo {
    param([string]$Path)
    if (-not $fsrmAvailable) { return $null }
    try {
        Get-FsrmQuota -Path $Path -ErrorAction Stop
    } catch {
        $null
    }
}
function Set-QuotaForPath {
    param(
        [string]$Path,
        [double]$SizeGB,
        [bool]$SoftLimit
    )
    if (-not $fsrmAvailable) {
        throw "FSRM modul nije dostupan."
    }
    $sizeBytes = [int64]($SizeGB * 1GB)
    $existing = Get-QuotaInfo -Path $Path
    if ($existing) {
        Set-FsrmQuota -Path $Path -Size $sizeBytes -SoftLimit:$SoftLimit
    } else {
        New-FsrmQuota -Path $Path -Size $sizeBytes -SoftLimit:$SoftLimit
    }
}
function Remove-QuotaForPath {
    param([string]$Path)
    if (-not $fsrmAvailable) {
        throw "FSRM modul nije dostupan."
    }
    $existing = Get-QuotaInfo -Path $Path
    if ($existing) {
        Remove-FsrmQuota -Path $Path -Confirm:$false
    }
}
function Get-FolderSizeBytes {
    param([string]$Path)
    try {
        $total = 0L
        Get-ChildItem -Path $Path -Recurse -File -Force -ErrorAction SilentlyContinue |
            % { $total += $_.Length }
        return $total
    } catch {
        return $null
    }
}

