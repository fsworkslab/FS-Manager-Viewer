<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Handlers.ps1
# Build: 20251126-142332

function Show-UserPermissionsSearch {
    param([string]$SearchUser = $null)
    try {
        if ($script:isIndexBuilding) {
            [System.Windows.Forms.MessageBox]::Show(
                "Index is currently being built in the background.`r`nPlease wait for it to complete before searching.`r`n`r`nYou can see the progress in the indexing dialog.",
                "Index Building in Progress",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }
        $searchText = $null
        if ($SearchUser) {
            $resolved = Resolve-PrincipalName -InputName $SearchUser -AllowPartial
            $searchText = if ($resolved) { $resolved } else { $SearchUser }
    } else {
            $dlg = New-Object System.Windows.Forms.Form
            $dlg.Text = "Search Permissions"
            $dlg.Size = New-Object System.Drawing.Size(480, 230)
            $dlg.StartPosition = "CenterParent"
            $dlg.KeyPreview = $true
            $dlg.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
            $dlg.MaximizeBox = $false
            $dlg.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
            $pnlHeader = New-Object System.Windows.Forms.Panel
            $pnlHeader.Location = New-Object System.Drawing.Point(0, 0)
            $pnlHeader.Size = New-Object System.Drawing.Size(480, 60)
            $pnlHeader.BackColor = [System.Drawing.Color]::FromArgb(45, 65, 95)
            $lblTitle = New-Object System.Windows.Forms.Label
            $lblTitle.Location = New-Object System.Drawing.Point(15, 8)
            $lblTitle.Size = New-Object System.Drawing.Size(400, 25)
            $lblTitle.Text = "Search User/Group Permissions"
            $lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
            $lblTitle.ForeColor = [System.Drawing.Color]::White
            $pnlHeader.Controls.Add($lblTitle)
            $lblHeaderInfo = New-Object System.Windows.Forms.Label
            $lblHeaderInfo.Location = New-Object System.Drawing.Point(15, 35)
            $lblHeaderInfo.Size = New-Object System.Drawing.Size(450, 18)
            $lblHeaderInfo.Text = "Searches Share + NTFS permissions (unique ACL folders)"
            $lblHeaderInfo.Font = New-Object System.Drawing.Font("Segoe UI", 8)
            $lblHeaderInfo.ForeColor = [System.Drawing.Color]::FromArgb(180, 200, 220)
            $pnlHeader.Controls.Add($lblHeaderInfo)
            $dlg.Controls.Add($pnlHeader)
            $lbl = New-Object System.Windows.Forms.Label
            $lbl.Location = New-Object System.Drawing.Point(15, 72)
            $lbl.Size     = New-Object System.Drawing.Size(440, 20)
            $lbl.Text     = "Enter user/group name or part of it:"
            $lbl.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            $txt = New-Object System.Windows.Forms.TextBox
            $txt.Location = New-Object System.Drawing.Point(15, 95)
            $txt.Size     = New-Object System.Drawing.Size(440, 25)
            $txt.Font = New-Object System.Drawing.Font("Segoe UI", 10)
            $btnBrowse = New-Object System.Windows.Forms.Button
            $btnBrowse.Location = New-Object System.Drawing.Point(15, 135)
            $btnBrowse.Size     = New-Object System.Drawing.Size(120, 32)
            $btnBrowse.Text     = "AD Search..."
            $btnBrowse.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            $btnBrowse.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnBrowse.Cursor = [System.Windows.Forms.Cursors]::Hand
            $btnBrowse.Add_Click({
                $picked = Show-AdUserPicker
                if ($picked) { $txt.Text = $picked }
            })
            $btnOk = New-Object System.Windows.Forms.Button
            $btnOk.Location = New-Object System.Drawing.Point(260, 135)
            $btnOk.Size     = New-Object System.Drawing.Size(90, 32)
            $btnOk.Text     = "Search"
            $btnOk.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            $btnOk.BackColor = [System.Drawing.Color]::FromArgb(45, 65, 95)
            $btnOk.ForeColor = [System.Drawing.Color]::White
            $btnOk.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnOk.Cursor = [System.Windows.Forms.Cursors]::Hand
            $btnCancel = New-Object System.Windows.Forms.Button
            $btnCancel.Location = New-Object System.Drawing.Point(360, 135)
            $btnCancel.Size     = New-Object System.Drawing.Size(90, 32)
            $btnCancel.Text     = "Cancel"
            $btnCancel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            $btnCancel.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnCancel.Cursor = [System.Windows.Forms.Cursors]::Hand
            $dlg.AcceptButton = $btnOk
            $dlg.CancelButton = $btnCancel
            $dlg.Controls.Add($lbl)
            $dlg.Controls.Add($txt)
            $dlg.Controls.Add($btnBrowse)
            $dlg.Controls.Add($btnOk)
            $dlg.Controls.Add($btnCancel)
            $script:__fsSearchText = $null
            $autoSearch = $false
            if ($script:__prefilledSearchUser) {
                $txt.Text = $script:__prefilledSearchUser
                $resolved = Resolve-PrincipalName -InputName $script:__prefilledSearchUser -AllowPartial
                $script:__fsSearchText = if ($resolved) { $resolved } else { $script:__prefilledSearchUser }
                Write-FsDebug -Category "UI" -Message "Auto-search triggered" -Details "User=$($script:__prefilledSearchUser); Resolved=$($script:__fsSearchText)"
                $script:__prefilledSearchUser = $null
                $autoSearch = $true
            }
            $btnOk.Add_Click({
                $st = $txt.Text.Trim()
                if (-not $st) {
                    [System.Windows.Forms.MessageBox]::Show("Enter something to search.", "Info",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                    return
                }
                $resolved = Resolve-PrincipalName -InputName $st -AllowPartial
                if ($resolved) { $script:__fsSearchText = $resolved } else { $script:__fsSearchText = $st }
                $dlg.Close()
            })
            $btnCancel.Add_Click({ $dlg.Close() })
            if ($autoSearch) {
                $dlg.Dispose()
            } else {
            [void]$dlg.ShowDialog()
            }
            $searchText = $script:__fsSearchText
            $script:__fsSearchText = $null
        }
            if (-not $searchText) { return }
            $results = New-Object System.Collections.Generic.List[object]
            $script:nodesChecked = 0
            function Search-LoadedNodes {
                param(
                    [System.Windows.Forms.TreeNode]$Node,
                    [string]$SearchPattern
                )
                $script:nodesChecked++
                if ($Node.Text -eq "...") { return }
                if ($Node.Tag -and $Node.Tag.Path) {
                    $folderPath = $Node.Tag.Path
                    $shareName = $Node.Tag.ShareName
                    $isRedNode = ($Node.ForeColor.Name -eq "DarkRed")
                    if ($isRedNode) {
                        try {
                            $acl = Get-Acl -Path $folderPath -ErrorAction Stop
                            foreach ($ace in $acl.Access) {
                                if ($ace.IdentityReference.ToString() -like "*$SearchPattern*") {
                                $results.Add([PSCustomObject]@{
                                        PermType  = "NTFS"
                                        Path      = $folderPath
                                        ShareName = $shareName
                                    Principal = $ace.IdentityReference.ToString()
                                    Rights    = $ace.FileSystemRights.ToString()
                                    AclType   = $ace.AccessControlType.ToString()
                                })
                            }
                        }
                        } catch {
                        }
                    }
                }
                foreach ($child in $Node.Nodes) {
                    Search-LoadedNodes -Node $child -SearchPattern $SearchPattern
                }
            }
            $shares = Get-ShareData
            $shareCount = $shares.Count
            $currentIdx = 0
            foreach ($sh in $shares) {
                $currentIdx++
                try {
                    $shareAcl = Get-ShareAcl -ShareName $sh.Name
                    if ($shareAcl) {
                        foreach ($ace in $shareAcl) {
                            if ($ace.AccountName -like "*$searchText*") {
                                $results.Add([PSCustomObject]@{
                                    PermType  = "Share"
                                    Path      = $sh.Path
                                    ShareName = $sh.Name
                                    Principal = $ace.AccountName
                                    Rights    = $ace.AccessRight.ToString()
                                    AclType   = $ace.AccessControlType.ToString()
                                })
                            }
                        }
                    }
                } catch {
                }
            }
            if (-not $script:uniqueAclIndex -or $script:uniqueAclIndex.Count -eq 0) {
                if (-not $script:isIndexBuilding) {
                    Build-UniqueAclIndex
                } else {
                    [System.Windows.Forms.MessageBox]::Show(
                        "Index is currently being built in the background.`r`nPlease wait for it to complete before searching.",
                        "Index Building",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information
                    ) | Out-Null
                    return
                }
            }
            $ntfsResults = Search-UniqueAclIndex -Pattern $searchText
            foreach ($r in $ntfsResults) {
                $results.Add($r)
            }
            $dlgRes = New-Object System.Windows.Forms.Form
            $dlgRes.Text = "Search results: $searchText"
            $dlgRes.Size = New-Object System.Drawing.Size(950, 490)
            $dlgRes.StartPosition = "CenterParent"
            $lvRes = New-Object System.Windows.Forms.ListView
            $lvRes.Location = New-Object System.Drawing.Point(10, 10)
            $lvRes.Size     = New-Object System.Drawing.Size(910, 300)
            $lvRes.View     = [System.Windows.Forms.View]::Details
            $lvRes.FullRowSelect = $true
            $lvRes.GridLines = $true
            $lvRes.CheckBoxes = $true  # Enable checkboxes for folder selection
            $null = $lvRes.Columns.Add("Type", 50)
            $null = $lvRes.Columns.Add("Share", 80)
            $null = $lvRes.Columns.Add("Path", 220)
            $null = $lvRes.Columns.Add("Principal", 130)
            $null = $lvRes.Columns.Add("Display Name", 130)
            $null = $lvRes.Columns.Add("Entity", 50)
            $null = $lvRes.Columns.Add("Rights", 150)
            $null = $lvRes.Columns.Add("ACL", 50)
            foreach ($r in $results) {
                $item = New-Object System.Windows.Forms.ListViewItem
                $item.Text = $r.PermType
                $null = $item.SubItems.Add($r.ShareName)
                $null = $item.SubItems.Add($r.Path)
                $null = $item.SubItems.Add($r.Principal)
                $pi = Get-PrincipalInfo -Identity $r.Principal
                $null = $item.SubItems.Add($pi.DisplayName)
                $null = $item.SubItems.Add($pi.Entity)
                $null = $item.SubItems.Add($r.Rights)
                $null = $item.SubItems.Add($r.AclType)
                $item.Tag = $r  # Store full result object for clone
                $item.Checked = $false  # Not checked by default - user selects what to clone
                $item.UseItemStyleForSubItems = $true
                if ($r.PermType -eq "Share") {
                    $item.ForeColor = [System.Drawing.Color]::DarkBlue
                }
                $item.BackColor = [System.Drawing.Color]::White
                $lvRes.Items.Add($item) | Out-Null
            }
            $shareCount = ($results | ? { $_.PermType -eq "Share" }).Count
            $ntfsCount = ($results | ? { $_.PermType -eq "NTFS" }).Count
            $pnlSelection = New-Object System.Windows.Forms.Panel
            $pnlSelection.Location = New-Object System.Drawing.Point(10, 310)
            $pnlSelection.Size = New-Object System.Drawing.Size(910, 35)
            $pnlSelection.BackColor = [System.Drawing.Color]::FromArgb(248, 250, 252)
            $pnlSelection.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
            $btnSelectAll = New-Object System.Windows.Forms.Button
            $btnSelectAll.Location = New-Object System.Drawing.Point(10, 5)
            $btnSelectAll.Size = New-Object System.Drawing.Size(90, 24)
            $btnSelectAll.Text = "Select All"
            $btnSelectAll.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnSelectAll.Font = New-Object System.Drawing.Font("Segoe UI", 8)
            $btnDeselectAll = New-Object System.Windows.Forms.Button
            $btnDeselectAll.Location = New-Object System.Drawing.Point(105, 5)
            $btnDeselectAll.Size = New-Object System.Drawing.Size(90, 24)
            $btnDeselectAll.Text = "Deselect All"
            $btnDeselectAll.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnDeselectAll.Font = New-Object System.Drawing.Font("Segoe UI", 8)
            $lblCheckedCount = New-Object System.Windows.Forms.Label
            $lblCheckedCount.Location = New-Object System.Drawing.Point(210, 8)
            $lblCheckedCount.Size = New-Object System.Drawing.Size(300, 18)
            $lblCheckedCount.Text = "Selected: 0 of $($results.Count) - check items to clone"
            $lblCheckedCount.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            $lblCheckedCount.ForeColor = [System.Drawing.Color]::FromArgb(180, 60, 60)
            $pnlSelection.Controls.Add($btnSelectAll)
            $pnlSelection.Controls.Add($btnDeselectAll)
            $pnlSelection.Controls.Add($lblCheckedCount)
            $updateCheckedCount = {
                $checked = @($lvRes.CheckedItems).Count
                $total = $lvRes.Items.Count
                if ($checked -eq 0) {
                    $lblCheckedCount.Text = "Selected: 0 of $total - check items to clone"
                    $lblCheckedCount.ForeColor = [System.Drawing.Color]::FromArgb(180, 60, 60)
                } else {
                    $lblCheckedCount.Text = "Selected: $checked of $total for cloning"
                    $lblCheckedCount.ForeColor = [System.Drawing.Color]::FromArgb(40, 100, 60)
                }
            }
            $btnSelectAll.Add_Click({
                foreach ($item in $lvRes.Items) { 
                    $item.Checked = $true 
                    $item.BackColor = [System.Drawing.Color]::FromArgb(235, 255, 235)
                }
                & $updateCheckedCount
            })
            $btnDeselectAll.Add_Click({
                foreach ($item in $lvRes.Items) { 
                    $item.Checked = $false 
                    $item.BackColor = [System.Drawing.Color]::White
                }
                & $updateCheckedCount
            })
            $lvRes.Add_ItemChecked({
                param($sender, $e)
                if ($e.Item.Checked) {
                    $e.Item.BackColor = [System.Drawing.Color]::FromArgb(235, 255, 235)  # Light green
                    $e.Item.Selected = $true
                } else {
                    $e.Item.BackColor = [System.Drawing.Color]::White  # White = unchecked
                }
                & $updateCheckedCount
            })
            $lblCount = New-Object System.Windows.Forms.Label
            $lblCount.Location = New-Object System.Drawing.Point(10, 360)
            $lblCount.Size     = New-Object System.Drawing.Size(500, 20)
            $lblCount.Text     = "Found: $($results.Count) (Share: $shareCount, NTFS: $ntfsCount)"
            $btnClonePerm = New-Object System.Windows.Forms.Button
            $btnClonePerm.Location = New-Object System.Drawing.Point(10, 385)
            $btnClonePerm.Size     = New-Object System.Drawing.Size(140, 28)
            $btnClonePerm.Text = "Clone SELECTED"
            $btnClonePerm.BackColor = [System.Drawing.Color]::FromArgb(40, 100, 60)
            $btnClonePerm.ForeColor = [System.Drawing.Color]::White
            $btnClonePerm.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            # Viewer version - style as disabled but keep enabled for tooltips
            $btnClonePerm.Enabled = $true
            if ($script:isViewerVersion) {
                $btnClonePerm.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
                $btnClonePerm.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
                $script:toolTip.SetToolTip($btnClonePerm, "Available in FS-Manager Pro - Clone permissions to multiple locations")
            }
            $btnRemovePerm = New-Object System.Windows.Forms.Button
            $btnRemovePerm.Location = New-Object System.Drawing.Point(160, 385)
            $btnRemovePerm.Size     = New-Object System.Drawing.Size(140, 28)
            $btnRemovePerm.Text = "Remove SELECTED"
            $btnRemovePerm.BackColor = [System.Drawing.Color]::FromArgb(180, 50, 50)
            $btnRemovePerm.ForeColor = [System.Drawing.Color]::White
            $btnRemovePerm.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            # Viewer version - style as disabled but keep enabled for tooltips
            $btnRemovePerm.Enabled = $true
            if ($script:isViewerVersion) {
                $btnRemovePerm.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
                $btnRemovePerm.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
                $script:toolTip.SetToolTip($btnRemovePerm, "Available in FS-Manager Pro - Remove selected permissions")
            }
            $btnExportSearch = New-Object System.Windows.Forms.Button
            $btnExportSearch.Location = New-Object System.Drawing.Point(310, 385)
            $btnExportSearch.Size     = New-Object System.Drawing.Size(120, 28)
            $btnExportSearch.Text     = "Export CSV"
            $btnExportSearch.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnShowInTree = New-Object System.Windows.Forms.Button
            $btnShowInTree.Location = New-Object System.Drawing.Point(450, 385)
            $btnShowInTree.Size     = New-Object System.Drawing.Size(150, 28)
            $btnShowInTree.Text = "Show ALL in Tree"
            $btnShowInTree.BackColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
            $btnShowInTree.ForeColor = [System.Drawing.Color]::White
            $btnShowInTree.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnGoto = New-Object System.Windows.Forms.Button
            $btnGoto.Location = New-Object System.Drawing.Point(620, 385)
            $btnGoto.Size     = New-Object System.Drawing.Size(160, 28)
            $btnGoto.Text     = "Go to Selected"
            $btnGoto.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $dlgRes.Controls.Add($lvRes)
            $dlgRes.Controls.Add($pnlSelection)
            $dlgRes.Controls.Add($lblCount)
            $dlgRes.Controls.Add($btnClonePerm)
            $dlgRes.Controls.Add($btnRemovePerm)
            $dlgRes.Controls.Add($btnExportSearch)
            $dlgRes.Controls.Add($btnShowInTree)
            $dlgRes.Controls.Add($btnGoto)
            $btnShowInTree.Add_Click({
                if ($results.Count -eq 0) {
                    [System.Windows.Forms.MessageBox]::Show("No results to show in tree.", "Info",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                    return
                }
                Highlight-SearchResults -Principal $searchText -SearchResults $results
                [System.Windows.Forms.MessageBox]::Show(
                    "Tree view switched to Search Mode.`r`n`r`nShowing $($results.Count) permission entries for:`r`n$searchText`r`n`r`nClick 'Exit Search Mode' to return to normal view.",
                    "Search Mode Active",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information
                ) | Out-Null
                $script:form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
                $script:form.Activate()
            })
            $btnGoto.Add_Click({
                if (-not $lvRes.SelectedItems.Count) {
                    [System.Windows.Forms.MessageBox]::Show("Select a row in the list.", "Info",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                    return
                }
                $targetPath = $lvRes.SelectedItems[0].SubItems[2].Text
                try {
                    $foundNode = $null
                    foreach ($rootNode in $script:tree.Nodes) {
                        if ($rootNode.Tag -and $rootNode.Tag.Path -eq $targetPath) {
                            $foundNode = $rootNode
                            break
                        }
                        try { $rootNode.Expand() } catch { }
                        foreach ($childNode in $rootNode.Nodes) {
                            if ($childNode.Tag -and $childNode.Tag.Path -eq $targetPath) {
                                $foundNode = $childNode
                                break
                            }
                            try { $childNode.Expand() } catch { }
                            foreach ($grandChild in $childNode.Nodes) {
                                if ($grandChild.Tag -and $grandChild.Tag.Path -eq $targetPath) {
                                    $foundNode = $grandChild
                                    break
                                }
                            }
                            if ($foundNode) { break }
                        }
                        if ($foundNode) { break }
                    }
                    if ($foundNode) {
                        $foundNode.EnsureVisible()
                        $script:tree.SelectedNode = $foundNode
                        $script:tree.Focus()
                        $script:currentPath = $targetPath
                        if (Get-Command Update-NtfsTab -ErrorAction SilentlyContinue) {
                            Update-NtfsTab -Path $targetPath
                        }
                        if (Get-Command Update-ShareTab -ErrorAction SilentlyContinue) {
                            Update-ShareTab -ShareName $foundNode.Tag.ShareName
                        }
                        $script:form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
                        $script:form.Activate()
                    } else {
                        [System.Windows.Forms.MessageBox]::Show("Failed to navigate to:`r`n$targetPath", "Navigation Failed",
                            [System.Windows.Forms.MessageBoxButtons]::OK,
                            [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
                    }
                } catch {
                    [System.Windows.Forms.MessageBox]::Show(
                        "Error navigating to folder:`r`n$targetPath`r`n`r`nError: $($_.Exception.Message)",
                        "Navigation Error",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Error
                    ) | Out-Null
                }
            })
            $btnExportSearch.Add_Click({
                if ($results.Count -eq 0) {
                    [System.Windows.Forms.MessageBox]::Show("No results to export.", "Info",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                    return
                }
                $sfd = New-Object System.Windows.Forms.SaveFileDialog
                $sfd.Title    = "Save search results to CSV"
                $sfd.Filter   = "CSV Files|*.csv"
                $sfd.FileName = "Search_Permissions_" + ($searchText.Replace("\\","_").Replace(":","_")) + ".csv"
                if ($sfd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
                try {
                    $exportData = $results | % {
                        $pi = Get-PrincipalInfo -Identity $_.Principal
                        [PSCustomObject]@{
                            Type        = $_.PermType
                            ShareName   = $_.ShareName
                            Path        = $_.Path
                            Principal   = $_.Principal
                            DisplayName = $pi.DisplayName
                            Entity      = $pi.Entity
                            Rights      = $_.Rights
                            AclType     = $_.AclType
                        }
                    }
                    $exportData | Export-Csv -Path $sfd.FileName -NoTypeInformation -Encoding UTF8
                    [System.Windows.Forms.MessageBox]::Show(
                        "Results were exported to:`r`n$($sfd.FileName)",
                        "Done",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information
                    ) | Out-Null
                } catch {
                    [System.Windows.Forms.MessageBox]::Show(
                        "Export error:`r`n$($_.Exception.Message)",
                        "Error",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Error
                    ) | Out-Null
                }
            })
            $btnClonePerm.Add_Click({
                if ($script:isViewerVersion) {
                    Show-ViewerProMessage "Clone Permissions"
                    return
                }
                if ($script:readOnlyMode) {
                    [System.Windows.Forms.MessageBox]::Show(
                        "Read-only mode is enabled. Uncheck to clone permissions.",
                        "Read-only",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information
                    ) | Out-Null
                    return
                }
                if ($results.Count -eq 0) {
                    [System.Windows.Forms.MessageBox]::Show(
                        "No results for cloning permissions.",
                        "Info",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information
                    ) | Out-Null
                    return
                }
                if ($lvRes.CheckedItems.Count -eq 0) {
                    [System.Windows.Forms.MessageBox]::Show(
                        "No entries checked for cloning.`r`nUse checkboxes to select which entries to clone.",
                        "No Selection",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Warning
                    ) | Out-Null
                    return
                }
                $selItem = $lvRes.CheckedItems[0]
                $selItem.Selected = $true  # Also highlight it visually
                $sourcePrincipal = $selItem.SubItems[3].Text  # Principal is at index 3
                $entriesForPrincipal = $results | ? { $_.Principal -eq $sourcePrincipal }
                if (-not $entriesForPrincipal -or $entriesForPrincipal.Count -eq 0) {
                    [System.Windows.Forms.MessageBox]::Show(
                        "No records to copy for $sourcePrincipal.",
                        "Info",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information
                    ) | Out-Null
                    return
                }
                $allShareEntries = $entriesForPrincipal | ? { $_.PermType -eq "Share" }
                $allNtfsEntries = $entriesForPrincipal | ? { $_.PermType -eq "NTFS" }
                $dlgClone = New-Object System.Windows.Forms.Form
                $dlgClone.Text = "Clone Permissions"
                $dlgClone.Size = New-Object System.Drawing.Size(580, 560)
                $dlgClone.StartPosition = "CenterParent"
                $dlgClone.KeyPreview = $true
                $dlgClone.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
                $dlgClone.MaximizeBox = $false
                $dlgClone.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
                $pnlHeader = New-Object System.Windows.Forms.Panel
                $pnlHeader.Location = New-Object System.Drawing.Point(0, 0)
                $pnlHeader.Size = New-Object System.Drawing.Size(580, 70)
                $pnlHeader.BackColor = [System.Drawing.Color]::FromArgb(45, 65, 95)
                $lblTitle = New-Object System.Windows.Forms.Label
                $lblTitle.Location = New-Object System.Drawing.Point(15, 10)
                $lblTitle.Size = New-Object System.Drawing.Size(400, 28)
                $lblTitle.Text = "Clone Permissions"
                $lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
                $lblTitle.ForeColor = [System.Drawing.Color]::White
                $pnlHeader.Controls.Add($lblTitle)
                $lblSubtitle = New-Object System.Windows.Forms.Label
                $lblSubtitle.Location = New-Object System.Drawing.Point(15, 40)
                $lblSubtitle.Size = New-Object System.Drawing.Size(550, 20)
                $lblSubtitle.Text = "Copy permissions from one user/group to others"
                $lblSubtitle.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $lblSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(180, 200, 220)
                $pnlHeader.Controls.Add($lblSubtitle)
                $dlgClone.Controls.Add($pnlHeader)
                $pnlSource = New-Object System.Windows.Forms.Panel
                $pnlSource.Location = New-Object System.Drawing.Point(15, 80)
                $pnlSource.Size = New-Object System.Drawing.Size(540, 45)
                $pnlSource.BackColor = [System.Drawing.Color]::FromArgb(230, 240, 250)
                $pnlSource.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                $lblSourceIcon = New-Object System.Windows.Forms.Label
                $lblSourceIcon.Location = New-Object System.Drawing.Point(10, 10)
                $lblSourceIcon.Size = New-Object System.Drawing.Size(30, 25)
                $lblSourceIcon.Text = "[S]"
                $lblSourceIcon.Font = New-Object System.Drawing.Font("Segoe UI", 14)
                $pnlSource.Controls.Add($lblSourceIcon)
                $lblSource = New-Object System.Windows.Forms.Label
                $lblSource.Location = New-Object System.Drawing.Point(45, 8)
                $lblSource.Size = New-Object System.Drawing.Size(80, 18)
                $lblSource.Text = "Source:"
                $lblSource.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $lblSource.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
                $pnlSource.Controls.Add($lblSource)
                $lblSourceName = New-Object System.Windows.Forms.Label
                $lblSourceName.Location = New-Object System.Drawing.Point(45, 24)
                $lblSourceName.Size = New-Object System.Drawing.Size(480, 18)
                $lblSourceName.Text = $sourcePrincipal
                $lblSourceName.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
                $lblSourceName.ForeColor = [System.Drawing.Color]::FromArgb(30, 60, 100)
                $pnlSource.Controls.Add($lblSourceName)
                $dlgClone.Controls.Add($pnlSource)
                $lblTypeHeader = New-Object System.Windows.Forms.Label
                $lblTypeHeader.Location = New-Object System.Drawing.Point(15, 135)
                $lblTypeHeader.Size = New-Object System.Drawing.Size(200, 20)
                $lblTypeHeader.Text = "What to clone:"
                $lblTypeHeader.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
                $dlgClone.Controls.Add($lblTypeHeader)
                $pnlType = New-Object System.Windows.Forms.Panel
                $pnlType.Location = New-Object System.Drawing.Point(15, 158)
                $pnlType.Size = New-Object System.Drawing.Size(540, 55)
                $pnlType.BackColor = [System.Drawing.Color]::White
                $pnlType.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                $rbAll = New-Object System.Windows.Forms.RadioButton
                $rbAll.Location = New-Object System.Drawing.Point(15, 8)
                $rbAll.Size = New-Object System.Drawing.Size(160, 22)
                $rbAll.Text = "All permissions"
                $rbAll.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $rbAll.Checked = $true
                $rbAll.BackColor = [System.Drawing.Color]::White
                $rbNtfs = New-Object System.Windows.Forms.RadioButton
                $rbNtfs.Location = New-Object System.Drawing.Point(185, 8)
                $rbNtfs.Size = New-Object System.Drawing.Size(160, 22)
                $rbNtfs.Text = "NTFS only"
                $rbNtfs.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $rbNtfs.BackColor = [System.Drawing.Color]::White
                $rbShare = New-Object System.Windows.Forms.RadioButton
                $rbShare.Location = New-Object System.Drawing.Point(355, 8)
                $rbShare.Size = New-Object System.Drawing.Size(160, 22)
                $rbShare.Text = "Share only"
                $rbShare.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $rbShare.BackColor = [System.Drawing.Color]::White
                $lblCloneCount = New-Object System.Windows.Forms.Label
                $lblCloneCount.Location = New-Object System.Drawing.Point(15, 32)
                $lblCloneCount.Size = New-Object System.Drawing.Size(510, 18)
                $lblCloneCount.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $lblCloneCount.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 80)
                $pnlType.Controls.Add($rbAll)
                $pnlType.Controls.Add($rbNtfs)
                $pnlType.Controls.Add($rbShare)
                $pnlType.Controls.Add($lblCloneCount)
                $dlgClone.Controls.Add($pnlType)
                $updateCounter = {
                    $shareCount = $allShareEntries.Count
                    $ntfsCount = $allNtfsEntries.Count
                    if ($rbAll.Checked) {
                        $lblCloneCount.Text = "Will clone: $shareCount Share + $ntfsCount NTFS = $($shareCount + $ntfsCount) total"
                    } elseif ($rbNtfs.Checked) {
                        $lblCloneCount.Text = "Will clone: $ntfsCount NTFS permission(s)"
                    } else {
                        $lblCloneCount.Text = "Will clone: $shareCount Share permission(s)"
                    }
                }
                & $updateCounter
                $rbAll.Add_CheckedChanged({ & $updateCounter })
                $rbNtfs.Add_CheckedChanged({ & $updateCounter })
                $rbShare.Add_CheckedChanged({ & $updateCounter })
                $lblTargetHeader = New-Object System.Windows.Forms.Label
                $lblTargetHeader.Location = New-Object System.Drawing.Point(15, 223)
                $lblTargetHeader.Size = New-Object System.Drawing.Size(300, 20)
                $lblTargetHeader.Text = "Target users/groups:"
                $lblTargetHeader.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
                $dlgClone.Controls.Add($lblTargetHeader)
                $pnlTargets = New-Object System.Windows.Forms.Panel
                $pnlTargets.Location = New-Object System.Drawing.Point(15, 246)
                $pnlTargets.Size = New-Object System.Drawing.Size(540, 210)
                $pnlTargets.BackColor = [System.Drawing.Color]::White
                $pnlTargets.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                $txtTarget = New-Object System.Windows.Forms.TextBox
                $txtTarget.Location = New-Object System.Drawing.Point(10, 10)
                $txtTarget.Size = New-Object System.Drawing.Size(410, 25)
                $txtTarget.Font = New-Object System.Drawing.Font("Segoe UI", 10)
                $pnlTargetPreview = New-Object System.Windows.Forms.Panel
                $pnlTargetPreview.Location = New-Object System.Drawing.Point(10, 38)
                $pnlTargetPreview.Size = New-Object System.Drawing.Size(410, 30)
                $pnlTargetPreview.BackColor = [System.Drawing.Color]::FromArgb(248, 250, 252)
                $pnlTargetPreview.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                $pnlTargetPreview.Visible = $false
                $lblTargetPreviewIcon = New-Object System.Windows.Forms.Label
                $lblTargetPreviewIcon.Location = New-Object System.Drawing.Point(5, 5)
                $lblTargetPreviewIcon.Size = New-Object System.Drawing.Size(25, 20)
                $lblTargetPreviewIcon.Text = ""
                $lblTargetPreviewIcon.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $pnlTargetPreview.Controls.Add($lblTargetPreviewIcon)
                $lblTargetPreviewText = New-Object System.Windows.Forms.Label
                $lblTargetPreviewText.Location = New-Object System.Drawing.Point(30, 6)
                $lblTargetPreviewText.Size = New-Object System.Drawing.Size(370, 18)
                $lblTargetPreviewText.Text = ""
                $lblTargetPreviewText.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $pnlTargetPreview.Controls.Add($lblTargetPreviewText)
                $updateTargetPreview = {
                    $username = $txtTarget.Text.Trim()
                    if ([string]::IsNullOrWhiteSpace($username)) {
                        $pnlTargetPreview.Visible = $false
                        return
                    }
                    try {
                        $pi = Get-PrincipalInfo -Identity $username
                        if ($pi -and $pi.Entity -ne 'Unknown') {
                            $pnlTargetPreview.Visible = $true
                            if ($pi.Entity -eq 'Group') {
                                $lblTargetPreviewIcon.Text = "[G]"
                                $lblTargetPreviewIcon.ForeColor = [System.Drawing.Color]::FromArgb(30, 80, 150)
                                $lblTargetPreviewText.Text = $pi.DisplayName
                                $pnlTargetPreview.BackColor = [System.Drawing.Color]::FromArgb(235, 245, 255)
                            } else {
                                $lblTargetPreviewIcon.Text = "[U]"
                                $lblTargetPreviewIcon.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 80)
                                $lblTargetPreviewText.Text = $pi.DisplayName
                                $pnlTargetPreview.BackColor = [System.Drawing.Color]::FromArgb(235, 255, 245)
                            }
                        } else {
                            $pnlTargetPreview.Visible = $true
                            $pnlTargetPreview.BackColor = [System.Drawing.Color]::FromArgb(255, 245, 240)
                            $lblTargetPreviewIcon.Text = "[?]"
                            $lblTargetPreviewIcon.ForeColor = [System.Drawing.Color]::FromArgb(180, 100, 50)
                            $lblTargetPreviewText.Text = "Not found in AD"
                        }
                    } catch {
                        $pnlTargetPreview.Visible = $false
                    }
                }
                $txtTarget.Add_Leave({ & $updateTargetPreview })
                $txtTarget.Add_KeyDown({
                    param($sender, $e)
                    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Tab) {
                        & $updateTargetPreview
                    }
                })
                $btnAddTarget = New-Object System.Windows.Forms.Button
                $btnAddTarget.Location = New-Object System.Drawing.Point(430, 8)
                $btnAddTarget.Size = New-Object System.Drawing.Size(100, 28)
                $btnAddTarget.Text = "+ Add"
                $btnAddTarget.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $btnAddTarget.BackColor = [System.Drawing.Color]::FromArgb(45, 65, 95)
                $btnAddTarget.ForeColor = [System.Drawing.Color]::White
                $btnAddTarget.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $btnAddTarget.Cursor = [System.Windows.Forms.Cursors]::Hand
                $lvTargets = New-Object System.Windows.Forms.ListView
                $lvTargets.Location = New-Object System.Drawing.Point(10, 72)
                $lvTargets.Size = New-Object System.Drawing.Size(410, 95)
                $lvTargets.View = [System.Windows.Forms.View]::Details
                $lvTargets.FullRowSelect = $true
                $lvTargets.MultiSelect = $true
                $lvTargets.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $lvTargets.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                $lvTargets.GridLines = $true
                $null = $lvTargets.Columns.Add("Principal", 160)
                $null = $lvTargets.Columns.Add("Display Name", 150)
                $null = $lvTargets.Columns.Add("Type", 80)
                $btnBrowseTarget = New-Object System.Windows.Forms.Button
                $btnBrowseTarget.Location = New-Object System.Drawing.Point(430, 45)
                $btnBrowseTarget.Size = New-Object System.Drawing.Size(100, 28)
                $btnBrowseTarget.Text = "AD Search"
                $btnBrowseTarget.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $btnBrowseTarget.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $btnBrowseTarget.Cursor = [System.Windows.Forms.Cursors]::Hand
                $btnRemoveTarget = New-Object System.Windows.Forms.Button
                $btnRemoveTarget.Location = New-Object System.Drawing.Point(430, 80)
                $btnRemoveTarget.Size = New-Object System.Drawing.Size(100, 28)
                $btnRemoveTarget.Text = "Remove"
                $btnRemoveTarget.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $btnRemoveTarget.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $btnRemoveTarget.ForeColor = [System.Drawing.Color]::FromArgb(180, 60, 60)
                $btnRemoveTarget.Cursor = [System.Windows.Forms.Cursors]::Hand
                $lblTargetCount = New-Object System.Windows.Forms.Label
                $lblTargetCount.Location = New-Object System.Drawing.Point(10, 175)
                $lblTargetCount.Size = New-Object System.Drawing.Size(410, 25)
                $lblTargetCount.Text = "No targets added yet"
                $lblTargetCount.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $lblTargetCount.ForeColor = [System.Drawing.Color]::FromArgb(150, 150, 150)
                $pnlTargets.Controls.Add($txtTarget)
                $pnlTargets.Controls.Add($pnlTargetPreview)
                $pnlTargets.Controls.Add($btnAddTarget)
                $pnlTargets.Controls.Add($lvTargets)
                $pnlTargets.Controls.Add($btnBrowseTarget)
                $pnlTargets.Controls.Add($btnRemoveTarget)
                $pnlTargets.Controls.Add($lblTargetCount)
                $dlgClone.Controls.Add($pnlTargets)
                $updateTargetCount = {
                    $count = $lvTargets.Items.Count
                    if ($count -eq 0) {
                        $lblTargetCount.Text = "No targets added yet"
                        $lblTargetCount.ForeColor = [System.Drawing.Color]::FromArgb(150, 150, 150)
                    } else {
                        $lblTargetCount.Text = "$count target(s) ready to receive permissions"
                        $lblTargetCount.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 80)
                    }
                }
                $isPrincipalInList = {
                    param($principal)
                    foreach ($item in $lvTargets.Items) {
                        if ($item.Tag -eq $principal) { return $true }
                    }
                    return $false
                }
                $addTargetToList = {
                    param($principal)
                    if (& $isPrincipalInList $principal) {
                        [System.Windows.Forms.MessageBox]::Show("'$principal' is already in the list.", "Duplicate",
                            [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                        return $false
                    }
                    if ($principal -eq $sourcePrincipal) {
                        [System.Windows.Forms.MessageBox]::Show("Cannot clone to the same user/group as source.", "Invalid",
                            [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
                        return $false
                    }
                    $pi = $null
                    try { $pi = Get-PrincipalInfo -Identity $principal } catch {}
                    $lvItem = New-Object System.Windows.Forms.ListViewItem
                    $lvItem.Tag = $principal  # Store original principal for operations
                    if ($pi -and $pi.Entity -ne 'Unknown') {
                        $lvItem.Text = $principal
                        $null = $lvItem.SubItems.Add($pi.DisplayName)
                        $typeText = "AD $($pi.Entity)"
                        $null = $lvItem.SubItems.Add($typeText)
                        if ($pi.Entity -eq 'Group') {
                            $lvItem.ForeColor = [System.Drawing.Color]::FromArgb(30, 80, 150)
                        } else {
                            $lvItem.ForeColor = [System.Drawing.Color]::FromArgb(40, 100, 60)
                        }
                    } else {
                        $isLocal = $false
                        try {
                            $localUsers = Get-LocalUser -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
                            $localGroups = Get-LocalGroup -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
                            $shortName = $principal -replace "^.*\\", ""
                            if ($localUsers -contains $shortName) {
                                $isLocal = $true
                                $lvItem.Text = $principal
                                $null = $lvItem.SubItems.Add($shortName)
                                $null = $lvItem.SubItems.Add("Local User")
                                $lvItem.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
                            } elseif ($localGroups -contains $shortName) {
                                $isLocal = $true
                                $lvItem.Text = $principal
                                $null = $lvItem.SubItems.Add($shortName)
                                $null = $lvItem.SubItems.Add("Local Group")
                                $lvItem.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
                            }
                        } catch {}
                        if (-not $isLocal) {
                            $lvItem.Text = $principal
                            $null = $lvItem.SubItems.Add("(Unknown)")
                            $null = $lvItem.SubItems.Add("NON-DOMAIN")
                            $lvItem.ForeColor = [System.Drawing.Color]::FromArgb(180, 100, 50)
                        }
                    }
                    $lvTargets.Items.Add($lvItem) | Out-Null
                    return $true
                }
                $addTargetFromText = {
                    $val = $txtTarget.Text.Trim()
                    if (-not $val) { return }
                    $resolved = $null
                    try { $resolved = Resolve-PrincipalName -InputName $val -AllowPartial } catch {}
                    if (-not $resolved) {
                        $isLocal = $false
                        try {
                            $localUsers = Get-LocalUser -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
                            $localGroups = Get-LocalGroup -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
                            $shortName = $val -replace "^.*\\", ""
                            if ($localUsers -contains $shortName -or $localGroups -contains $shortName) {
                                $isLocal = $true
                                $resolved = $val
                            }
                        } catch {}
                        if (-not $isLocal) {
                        [System.Windows.Forms.MessageBox]::Show(
                                "User/group '$val' was not found in Active Directory or local accounts.`r`n`r`nPlease use AD Search to find valid users/groups.",
                                "User not found",
                                [System.Windows.Forms.MessageBoxButtons]::OK,
                                [System.Windows.Forms.MessageBoxIcon]::Warning
                            ) | Out-Null
                        return
                        }
                    }
                    $added = & $addTargetToList $resolved
                    if ($added) {
                        $txtTarget.Clear()
                        $pnlTargetPreview.Visible = $false
                        & $updateTargetCount
                    }
                }
                $btnAddTarget.Add_Click({ & $addTargetFromText })
                $txtTarget.Add_KeyDown({
                    param($sender, $e)
                    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
                        & $addTargetFromText
                        $e.Handled = $true
                        $e.SuppressKeyPress = $true
                    }
                })
                $btnBrowseTarget.Add_Click({
                    $picked = Show-AdUserPicker
                    if ($picked) {
                        $added = & $addTargetToList $picked
                        if ($added) {
                            & $updateTargetCount
                        }
                    }
                })
                $btnRemoveTarget.Add_Click({
                    $toRemove = @($lvTargets.SelectedItems)
                    foreach ($item in $toRemove) {
                        $lvTargets.Items.Remove($item)
                    }
                    & $updateTargetCount
                })
                $lvTargets.Add_KeyDown({
                    param($sender, $e)
                    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Delete) {
                        $toRemove = @($lvTargets.SelectedItems)
                        foreach ($item in $toRemove) {
                            $lvTargets.Items.Remove($item)
                        }
                        & $updateTargetCount
                        $e.Handled = $true
                    }
                })
                $btnOkClone = New-Object System.Windows.Forms.Button
                $btnOkClone.Location = New-Object System.Drawing.Point(350, 470)
                $btnOkClone.Size = New-Object System.Drawing.Size(100, 35)
                $btnOkClone.Text = "Clone"
                $btnOkClone.Font = New-Object System.Drawing.Font("Segoe UI", 10)
                $btnOkClone.BackColor = [System.Drawing.Color]::FromArgb(40, 120, 80)
                $btnOkClone.ForeColor = [System.Drawing.Color]::White
                $btnOkClone.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $btnOkClone.Cursor = [System.Windows.Forms.Cursors]::Hand
                $btnCancelClone = New-Object System.Windows.Forms.Button
                $btnCancelClone.Location = New-Object System.Drawing.Point(460, 470)
                $btnCancelClone.Size = New-Object System.Drawing.Size(100, 35)
                $btnCancelClone.Text = "Cancel"
                $btnCancelClone.Font = New-Object System.Drawing.Font("Segoe UI", 10)
                $btnCancelClone.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $btnCancelClone.Cursor = [System.Windows.Forms.Cursors]::Hand
                $dlgClone.Controls.Add($btnOkClone)
                $dlgClone.Controls.Add($btnCancelClone)
                $dlgClone.CancelButton = $btnCancelClone
                $script:__fsCloneTargets = $null
                $script:__fsCloneType = $null
                $btnOkClone.Add_Click({
                    if ($lvTargets.Items.Count -eq 0) {
                        [System.Windows.Forms.MessageBox]::Show(
                            "Add at least one target user/group.",
                            "No Targets",
                            [System.Windows.Forms.MessageBoxButtons]::OK,
                            [System.Windows.Forms.MessageBoxIcon]::Warning
                        ) | Out-Null
                        return
                    }
                    $script:__fsCloneTargets = @($lvTargets.Items | % { $_.Tag })
                    $script:__fsCloneType = if ($rbAll.Checked) { "ALL" } elseif ($rbNtfs.Checked) { "NTFS" } else { "SHARE" }
                    $dlgClone.DialogResult = [System.Windows.Forms.DialogResult]::OK
                    $dlgClone.Close()
                })
                $btnCancelClone.Add_Click({
                    $dlgClone.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
                    $dlgClone.Close()
                })
                $dlgClone.Add_Shown({ $txtTarget.Focus() })
                [void]$dlgClone.ShowDialog()
                $targetPrincipals = $script:__fsCloneTargets
                $cloneType = $script:__fsCloneType
                $script:__fsCloneTargets = $null
                $script:__fsCloneType = $null
                if (-not $targetPrincipals -or $targetPrincipals.Count -eq 0) { return }
                $checkedItems = @($lvRes.CheckedItems | % { $_.Tag })
                if ($checkedItems.Count -eq 0) {
                    [System.Windows.Forms.MessageBox]::Show(
                        "No entries selected for cloning.`r`nPlease check at least one item in the list.",
                        "No Selection",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Warning
                    ) | Out-Null
                    return
                }
                $shareEntries = @()
                $ntfsEntries = @()
                if ($cloneType -eq "ALL" -or $cloneType -eq "SHARE") {
                    $shareEntries = $checkedItems | ? { $_.PermType -eq "Share" }
                }
                if ($cloneType -eq "ALL" -or $cloneType -eq "NTFS") {
                    $ntfsEntries = $checkedItems | ? { 
                        $_.PermType -eq "NTFS" -and $_.AclType -ne "Inherited"
                    }
                }
                $totalOps = ($shareEntries.Count + $ntfsEntries.Count) * $targetPrincipals.Count
                $msg = "Clone permissions from:`r`n  $sourcePrincipal`r`n`r`nTo $($targetPrincipals.Count) target(s):`r`n"
                foreach ($t in $targetPrincipals | Select-Object -First 5) {
                    $msg += "  - $t`r`n"
                }
                if ($targetPrincipals.Count -gt 5) { $msg += "  ... and $($targetPrincipals.Count - 5) more`r`n" }
                $msg += "`r`nPermissions to clone:`r`n"
                $msg += "  - Share: $($shareEntries.Count)`r`n"
                $msg += "  - NTFS: $($ntfsEntries.Count)`r`n"
                $msg += "  - Total operations: $totalOps`r`n"
                if ($totalOps -gt 10) {
                    $estimatedTime = [math]::Ceiling($totalOps / 3)  # More conservative: ~3 ops per second
                    $msg += "`r`n?? LARGE OPERATION WARNING ??`r`n"
                    $msg += "This operation involves $totalOps permission changes`r`n"
                    $msg += "Estimated time: $estimatedTime-$($estimatedTime * 2) seconds`r`n"
                    $msg += "Target principals: $($targetPrincipals.Count)`r`n`r`n"
                    $msg += "?? IMPORTANT NOTES:`r`n"
                    $msg += "� Operation CANNOT be cancelled once started`r`n"
                    $msg += "� Progress window will show detailed status`r`n"
                    $msg += "� All changes will be logged for audit`r`n"
                    $msg += "� Ensure sufficient time is available`r`n`r`n"
                    $msg += "Continue with this operation?"
                $confirm = [System.Windows.Forms.MessageBox]::Show(
                    $msg,
                        "Large Operation - Confirm Clone",
                    [System.Windows.Forms.MessageBoxButtons]::YesNo,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                )
                } else {
                    $msg += "`r`nContinue?"
                    $confirm = [System.Windows.Forms.MessageBox]::Show(
                        $msg,
                        "Confirm Permission Clone",
                        [System.Windows.Forms.MessageBoxButtons]::YesNo,
                        [System.Windows.Forms.MessageBoxIcon]::Question
                    )
                }
                if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                $operationId = [guid]::NewGuid().ToString()
                $dlgProgress = New-Object System.Windows.Forms.Form
                $dlgProgress.Text = "Cloning Permissions..."
                $dlgProgress.Size = New-Object System.Drawing.Size(450, 180)
                $dlgProgress.StartPosition = "CenterScreen"
                $dlgProgress.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
                $dlgProgress.ControlBox = $false
                $dlgProgress.MaximizeBox = $false
                $dlgProgress.MinimizeBox = $false
                $dlgProgress.TopMost = $true
                $dlgProgress.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
                $lblProgressTitle = New-Object System.Windows.Forms.Label
                $lblProgressTitle.Location = New-Object System.Drawing.Point(15, 15)
                $lblProgressTitle.Size = New-Object System.Drawing.Size(400, 25)
                $lblProgressTitle.Text = "Cloning permissions - please wait..."
                $lblProgressTitle.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
                $dlgProgress.Controls.Add($lblProgressTitle)
                $lblProgressStatus = New-Object System.Windows.Forms.Label
                $lblProgressStatus.Location = New-Object System.Drawing.Point(15, 45)
                $lblProgressStatus.Size = New-Object System.Drawing.Size(400, 40)
                $lblProgressStatus.Text = "Initializing clone operation..."
                $lblProgressStatus.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $dlgProgress.Controls.Add($lblProgressStatus)
                $progressBar = New-Object System.Windows.Forms.ProgressBar
                $progressBar.Location = New-Object System.Drawing.Point(15, 95)
                $progressBar.Size = New-Object System.Drawing.Size(400, 25)
                $progressBar.Minimum = 0
                $progressBar.Maximum = $totalOps
                $progressBar.Value = 0
                $dlgProgress.Controls.Add($progressBar)
                $lblProgressCount = New-Object System.Windows.Forms.Label
                $lblProgressCount.Location = New-Object System.Drawing.Point(15, 125)
                $lblProgressCount.Size = New-Object System.Drawing.Size(250, 20)
                $lblProgressCount.Text = "0 / $totalOps operations"
                $lblProgressCount.Font = New-Object System.Drawing.Font("Segoe UI", 8)
                $lblProgressCount.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
                $dlgProgress.Controls.Add($lblProgressCount)
                $lblETA = New-Object System.Windows.Forms.Label
                $lblETA.Location = New-Object System.Drawing.Point(270, 125)
                $lblETA.Size = New-Object System.Drawing.Size(145, 20)
                $lblETA.Text = "ETA: Calculating..."
                $lblETA.Font = New-Object System.Drawing.Font("Segoe UI", 8)
                $lblETA.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
                $lblETA.TextAlign = [System.Drawing.ContentAlignment]::TopRight
                $dlgProgress.Controls.Add($lblETA)
                $dlgProgress.Add_FormClosing({
                    param($sender, $e)
                    $e.Cancel = $true
                })
                $dlgProgress.Show()
                $dlgProgress.Refresh()
                $currentOp = 0
                $startTime = Get-Date
                $totalShareCloned = 0
                $totalNtfsCloned = 0
                $cloneErrors = @()
                foreach ($targetPrincipal in $targetPrincipals) {
                    foreach ($r in $shareEntries) {
                        $currentOp++
                        $lblProgressStatus.Text = "Share: $($r.ShareName)`r`nTarget: $targetPrincipal"
                        $progressBar.Value = [Math]::Min($currentOp, $totalOps)
                        $lblProgressCount.Text = "$currentOp / $totalOps operations"
                        if ($currentOp -gt 5) {
                            $elapsed = (Get-Date) - $startTime
                            $avgTimePerOp = $elapsed.TotalSeconds / $currentOp
                            $remainingOps = $totalOps - $currentOp
                            $etaSeconds = $remainingOps * $avgTimePerOp
                            $eta = (Get-Date).AddSeconds($etaSeconds)
                            $lblETA.Text = "ETA: $($eta.ToString('HH:mm:ss'))"
                        }
                        $dlgProgress.Refresh()
                        [System.Windows.Forms.Application]::DoEvents()
                        try {
                            Grant-SmbShareAccess -Name $r.ShareName -AccountName $targetPrincipal -AccessRight $r.Rights -Force -ErrorAction Stop
                            Write-FsLog -Action "SHARE_CloneAce" -Path $r.ShareName `
                                -Details "From=$sourcePrincipal; To=$targetPrincipal; Access=$($r.Rights)" `
                                -GroupId $operationId
                            $totalShareCloned++
                        } catch {
                            $cloneErrors += "Share '$($r.ShareName)' -> $targetPrincipal : $($_.Exception.Message)"
                        }
                    }
                    foreach ($r in $ntfsEntries) {
                        $currentOp++
                        $lblProgressStatus.Text = "NTFS: $($r.Path)`r`nTarget: $targetPrincipal"
                        $progressBar.Value = [Math]::Min($currentOp, $totalOps)
                        $lblProgressCount.Text = "$currentOp / $totalOps operations"
                        if ($currentOp -gt 5) {
                            $elapsed = (Get-Date) - $startTime
                            $avgTimePerOp = $elapsed.TotalSeconds / $currentOp
                            $remainingOps = $totalOps - $currentOp
                            $etaSeconds = $remainingOps * $avgTimePerOp
                            $eta = (Get-Date).AddSeconds($etaSeconds)
                            $lblETA.Text = "ETA: $($eta.ToString('HH:mm:ss'))"
                        }
                        $dlgProgress.Refresh()
                        [System.Windows.Forms.Application]::DoEvents()
                    $p = $r.Path
                    try {
                        $allAces = Get-NtfsAclEntries -Path $p -IncludeInherited
                        if (-not $allAces) { continue }
                        $matchingAces = $allAces | ? {
                            $_.IdentityReference.ToString() -eq $sourcePrincipal -and
                            $_.FileSystemRights.ToString()   -eq $r.Rights          -and
                            $_.AccessControlType.ToString()  -eq $r.AclType
                        }
                        if (-not $matchingAces) { continue }
                        $acl     = Get-Acl -Path $p -ErrorAction Stop
                        $oldSddl = $acl.Sddl
                        foreach ($ace in $matchingAces) {
                            $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                                $targetPrincipal,
                                $ace.FileSystemRights,
                                $ace.InheritanceFlags,
                                $ace.PropagationFlags,
                                $ace.AccessControlType
                            )
                            $acl.AddAccessRule($rule) | Out-Null
                        }
                        Set-Acl -Path $p -AclObject $acl
                        $newSddl = (Get-Acl -Path $p -ErrorAction Stop).Sddl
                        Write-FsLog -Action "NTFS_CloneAce" -Path $p `
                            -Details "From=$sourcePrincipal; To=$targetPrincipal; Entries=$($matchingAces.Count)" `
                                -OldSddl $oldSddl -NewSddl $newSddl `
                                -GroupId $operationId
                            $totalNtfsCloned++
                    } catch {
                            $cloneErrors += "NTFS '$p' -> $targetPrincipal : $($_.Exception.Message)"
                        }
                    }
                }
                $dlgProgress.Add_FormClosing({ })
                $dlgProgress.Close()
                $dlgProgress.Dispose()
                if ($script:currentPath) {
                    Update-NtfsTab -Path $script:currentPath
                }
                if ($script:currentShareName) {
                    Update-ShareTab -ShareName $script:currentShareName
                }
                $resultMsg = "Permission cloning finished.`r`n"
                $resultMsg += "Source: $sourcePrincipal`r`n"
                $resultMsg += "Targets: $($targetPrincipals.Count)`r`n`r`n"
                $resultMsg += "Share permissions cloned: $totalShareCloned`r`n"
                $resultMsg += "NTFS permissions cloned: $totalNtfsCloned`r`n"
                if ($cloneErrors.Count -gt 0) {
                    $resultMsg += "`r`nErrors ($($cloneErrors.Count)):`r`n"
                    $resultMsg += ($cloneErrors | Select-Object -First 5) -join "`r`n"
                    if ($cloneErrors.Count -gt 5) { $resultMsg += "`r`n... and $($cloneErrors.Count - 5) more" }
                }
                        [System.Windows.Forms.MessageBox]::Show(
                    $resultMsg,
                    "Clone Complete",
                                [System.Windows.Forms.MessageBoxButtons]::OK,
                    $(if ($cloneErrors.Count -gt 0) { [System.Windows.Forms.MessageBoxIcon]::Warning } else { [System.Windows.Forms.MessageBoxIcon]::Information })
                            ) | Out-Null
            })
            $btnRemovePerm.Add_Click({
                if ($script:isViewerVersion) {
                    Show-ViewerProMessage "Remove Permissions"
                    return
                }
                if ($script:readOnlyMode) {
                    [System.Windows.Forms.MessageBox]::Show(
                        "Read-only mode is enabled. Uncheck to remove permissions.",
                        "Read-only",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Information
                    ) | Out-Null
                    return
                }
                $checkedItems = @($lvRes.CheckedItems)
                if ($checkedItems.Count -eq 0) {
                    [System.Windows.Forms.MessageBox]::Show(
                        "No entries checked for removal.`r`nUse checkboxes to select which permissions to remove.",
                        "No Selection",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Warning
                    ) | Out-Null
                    return
                }
                $principalToRemove = $searchText
                $shareItems = @($checkedItems | ? { $_.Tag.PermType -eq "Share" })
                $ntfsItems = @($checkedItems | ? { $_.Tag.PermType -eq "NTFS" })
                $totalOps = $checkedItems.Count
                $msg = "Remove permissions for: $principalToRemove`r`n`r`n"
                $msg += "Selected for removal:`r`n"
                $msg += "  - Share permissions: $($shareItems.Count)`r`n"
                $msg += "  - NTFS permissions: $($ntfsItems.Count)`r`n"
                $msg += "  - Total: $totalOps`r`n`r`n"
                $msg += "Affected locations:`r`n"
                $uniquePaths = $checkedItems | % { $_.Tag.Path } | Select-Object -Unique
                foreach ($p in ($uniquePaths | Select-Object -First 8)) {
                    $shortPath = if ($p.Length -gt 50) { "..." + $p.Substring($p.Length - 47) } else { $p }
                    $msg += "  - $shortPath`r`n"
                }
                if ($uniquePaths.Count -gt 8) { $msg += "  ... and $($uniquePaths.Count - 8) more locations`r`n" }
                if ($totalOps -gt 10) {
                    $msg += "`r`n" + [string][char]9888 + " WARNING: This is a large operation!`r`n"
                    $msg += "The progress window cannot be closed during removal.`r`n"
                }
                $msg += "`r`nThis action CANNOT be undone easily!`r`nAre you sure you want to remove these permissions?"
                $confirm = [System.Windows.Forms.MessageBox]::Show(
                    $msg,
                    "Confirm Permission Removal",
                    [System.Windows.Forms.MessageBoxButtons]::YesNo,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                )
                if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                $operationId = [guid]::NewGuid().ToString()
                $dlgProgress = New-Object System.Windows.Forms.Form
                $dlgProgress.Text = "Removing Permissions..."
                $dlgProgress.Size = New-Object System.Drawing.Size(450, 180)
                $dlgProgress.StartPosition = "CenterScreen"
                $dlgProgress.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
                $dlgProgress.ControlBox = $false
                $dlgProgress.TopMost = $true
                $dlgProgress.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
                $lblProgressTitle = New-Object System.Windows.Forms.Label
                $lblProgressTitle.Location = New-Object System.Drawing.Point(15, 15)
                $lblProgressTitle.Size = New-Object System.Drawing.Size(400, 25)
                $lblProgressTitle.Text = "Removing permissions - please wait..."
                $lblProgressTitle.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
                $dlgProgress.Controls.Add($lblProgressTitle)
                $lblProgressStatus = New-Object System.Windows.Forms.Label
                $lblProgressStatus.Location = New-Object System.Drawing.Point(15, 45)
                $lblProgressStatus.Size = New-Object System.Drawing.Size(400, 40)
                $lblProgressStatus.Text = "Initializing..."
                $lblProgressStatus.Font = New-Object System.Drawing.Font("Segoe UI", 9)
                $dlgProgress.Controls.Add($lblProgressStatus)
                $progressBar = New-Object System.Windows.Forms.ProgressBar
                $progressBar.Location = New-Object System.Drawing.Point(15, 95)
                $progressBar.Size = New-Object System.Drawing.Size(400, 25)
                $progressBar.Minimum = 0
                $progressBar.Maximum = $totalOps
                $progressBar.Value = 0
                $dlgProgress.Controls.Add($progressBar)
                $lblProgressCount = New-Object System.Windows.Forms.Label
                $lblProgressCount.Location = New-Object System.Drawing.Point(15, 125)
                $lblProgressCount.Size = New-Object System.Drawing.Size(400, 20)
                $lblProgressCount.Text = "0 / $totalOps"
                $lblProgressCount.Font = New-Object System.Drawing.Font("Segoe UI", 8)
                $dlgProgress.Controls.Add($lblProgressCount)
                $dlgProgress.Add_FormClosing({ param($s,$e) $e.Cancel = $true })
                $dlgProgress.Show()
                $dlgProgress.Refresh()
                $currentOp = 0
                $removeErrors = @()
                $shareRemoved = 0
                $ntfsRemoved = 0
                foreach ($item in $shareItems) {
                    $r = $item.Tag
                    $currentOp++
                    $lblProgressStatus.Text = "Share: $($r.ShareName)`r`nRemoving: $($r.Principal)"
                    $progressBar.Value = [Math]::Min($currentOp, $totalOps)
                    $lblProgressCount.Text = "$currentOp / $totalOps"
                    $dlgProgress.Refresh()
                    [System.Windows.Forms.Application]::DoEvents()
                    try {
                        Revoke-SmbShareAccess -Name $r.ShareName -AccountName $r.Principal -Force -ErrorAction Stop
                        Write-FsLog -Action "SHARE_RemoveAce" -Path $r.ShareName `
                            -Details "Principal=$($r.Principal);Access=$($r.Rights)" `
                            -GroupId $operationId
                        $shareRemoved++
                    } catch {
                        $removeErrors += "Share '$($r.ShareName)' - $($r.Principal): $($_.Exception.Message)"
                    }
                }
                foreach ($item in $ntfsItems) {
                    $r = $item.Tag
                    $currentOp++
                    $lblProgressStatus.Text = "NTFS: $($r.Path)`r`nRemoving: $($r.Principal)"
                    $progressBar.Value = [Math]::Min($currentOp, $totalOps)
                    $lblProgressCount.Text = "$currentOp / $totalOps"
                    $dlgProgress.Refresh()
                    [System.Windows.Forms.Application]::DoEvents()
                    try {
                        $acl = Get-Acl -Path $r.Path -ErrorAction Stop
                        $oldSddl = $acl.Sddl
                        $rulesToRemove = @($acl.Access | ? { 
                            $_.IdentityReference.ToString() -eq $r.Principal
                        })
                        foreach ($rule in $rulesToRemove) {
                            $acl.RemoveAccessRule($rule) | Out-Null
                        }
                        Set-Acl -Path $r.Path -AclObject $acl
                        $newSddl = (Get-Acl -Path $r.Path -ErrorAction Stop).Sddl
                        Write-FsLog -Action "NTFS_RemoveAce" -Path $r.Path `
                            -Details "Principal=$($r.Principal); Rights=$($r.Rights)" `
                            -OldSddl $oldSddl -NewSddl $newSddl `
                            -GroupId $operationId
                        $ntfsRemoved++
                    } catch {
                        $removeErrors += "NTFS '$($r.Path)' - $($r.Principal): $($_.Exception.Message)"
                    }
                }
                $dlgProgress.Add_FormClosing({ })
                $dlgProgress.Close()
                $dlgProgress.Dispose()
                if ($script:currentPath) {
                    Update-NtfsTab -Path $script:currentPath
                }
                if ($script:currentShareName) {
                    Update-ShareTab -ShareName $script:currentShareName
                }
                foreach ($item in $checkedItems) {
                    $lvRes.Items.Remove($item)
                }
                & $updateCheckedCount
                $remainingShare = @($lvRes.Items | ? { $_.Tag.PermType -eq "Share" }).Count
                $remainingNtfs = @($lvRes.Items | ? { $_.Tag.PermType -eq "NTFS" }).Count
                $lblCount.Text = "Found: $($lvRes.Items.Count) (Share: $remainingShare, NTFS: $remainingNtfs)"
                $resultMsg = "Permission removal completed.`r`n`r`n"
                $resultMsg += "Share permissions removed: $shareRemoved`r`n"
                $resultMsg += "NTFS permissions removed: $ntfsRemoved`r`n"
                if ($removeErrors.Count -gt 0) {
                    $resultMsg += "`r`nErrors ($($removeErrors.Count)):`r`n"
                    $resultMsg += ($removeErrors | Select-Object -First 5) -join "`r`n"
                    if ($removeErrors.Count -gt 5) { $resultMsg += "`r`n... and $($removeErrors.Count - 5) more" }
                }
                [System.Windows.Forms.MessageBox]::Show(
                    $resultMsg,
                    "Removal Complete",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    $(if ($removeErrors.Count -gt 0) { [System.Windows.Forms.MessageBoxIcon]::Warning } else { [System.Windows.Forms.MessageBoxIcon]::Information })
                ) | Out-Null
            })
            [void]$dlgRes.ShowDialog()
        } catch {
            [System.Windows.Forms.MessageBox]::Show(
                "Error searching user/group:`r`n$($_.Exception.Message)",
                "Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
}
if ($script:btnSearchUser) {
    $script:btnSearchUser.Add_Click({
        Show-UserPermissionsSearch
    })
}
# Note: btnSaveTemplate, btnApplyTemplate, btnAddAce, btnRemoveAce handlers are in FSManager.UI.Handlers.Core.ps1
# They show Pro upgrade message for Viewer version
function btnCalcSize_Click {
    if (-not $script:currentPath) {
        [System.Windows.Forms.MessageBox]::Show("Please select a folder/share in the tree first.", "Info",
            [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        return
    }
    $res = [System.Windows.Forms.MessageBox]::Show("Calculating size may take time depending on number of files.`r`nContinue for:`r`n$script:currentPath ?",
        "Confirm", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($res -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    try {
        $script:lblFolderSize.Text = "Current size: calculating..."
        $script:form.Refresh()
        $bytes = Get-FolderSizeBytes -Path $script:currentPath
        if ($bytes -eq $null) {
            $script:lblFolderSize.Text = "Current size: error reading."
        } else {
            $gb = [math]::Round(($bytes / 1GB), 2)
            $script:lblFolderSize.Text = "Current size: $gb GB"
        }
    } catch {
        $script:lblFolderSize.Text = "Current size: error."
    }
}
function tree_AfterSelect {
    param($sender, $e)
    $node = $e.Node
    if (-not $node -or -not $node.Tag) {
        $script:currentPath = $null
        $script:currentShareName = $null
        Update-NtfsTab -Path $null
        Update-ShareTab -ShareName $null
        Update-QuotaTab -Path $null
        return
    }
    $script:currentPath = $node.Tag.Path
    $script:currentShareName = $node.Tag.ShareName
    Update-NtfsTab -Path $script:currentPath
    Update-ShareTab -ShareName $script:currentShareName
    Update-QuotaTab -Path $script:currentPath
}
function tree_BeforeExpand {
    param($sender, $e)
    $node = $e.Node
    if (-not $node) { return }
    if ($node.Nodes.Count -eq 1 -and $node.Nodes[0].Text -eq "...") {
        $node.Nodes.Clear()
        if ($node.Tag -and $node.Tag.Path) {
            Add-ChildNodes -ParentNode $node -Path $node.Tag.Path
        }
    }
}
function btnGlobalHistory_Click {
    try {
        $logRoot = "C:\Scripts\FSManager\Logs"
        if (-not (Test-Path $logRoot)) {
            [System.Windows.Forms.MessageBox]::Show(
                "Log folder does not exist:`r`n$logRoot",
                "No logs",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }
        $logFiles = Get-ChildItem -Path $logRoot -Filter "FSManager-log_*.log" -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        if (-not $logFiles -or $logFiles.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "No log files found in:`r`n$logRoot",
                "No logs",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }
        $allEntries = New-Object System.Collections.Generic.List[object]
        foreach ($logFile in $logFiles) {
            $lines = gc -Path $logFile.FullName -ErrorAction SilentlyContinue
            foreach ($line in $lines) {
                if ([string]::IsNullOrWhiteSpace($line)) { continue }
                try {
                    $entry = $line | ConvertFrom-Json
                    if (-not $entry.Action -or $entry.Level) { continue }
                    $allEntries.Add([PSCustomObject]@{
                        Time     = if ($entry.Time) { $entry.Time } else { "" }
                        User     = if ($entry.User) { $entry.User } else { "" }
                        Action   = $entry.Action
                        Path     = if ($entry.Path) { $entry.Path } else { "" }
                        Details  = if ($entry.Details) { $entry.Details } else { "" }
                        OldSddl  = if ($entry.OldSddl) { $entry.OldSddl } else { "" }
                        NewSddl  = if ($entry.NewSddl) { $entry.NewSddl } else { "" }
                        GroupId  = if ($entry.GroupId) { $entry.GroupId } else { "" }
                        LogFile  = $logFile.Name
                    })
                } catch {
                }
            }
        }
        if ($allEntries.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "No log entries found.",
                "No history",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }
        $sortedEntries = $allEntries | Sort-Object Time -Descending
        $groupCounts = @{}
        foreach ($e in $allEntries) {
            if ($e.GroupId) {
                if (-not $groupCounts.ContainsKey($e.GroupId)) { $groupCounts[$e.GroupId] = 0 }
                $groupCounts[$e.GroupId]++
            }
        }
        $dlgHist = New-Object System.Windows.Forms.Form
        $dlgHist.Text = "Change History"
        $dlgHist.Size = New-Object System.Drawing.Size(1150, 650)
        $dlgHist.StartPosition = "CenterParent"
        $dlgHist.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
        $pnlHeader = New-Object System.Windows.Forms.Panel
        $pnlHeader.Location = New-Object System.Drawing.Point(0, 0)
        $pnlHeader.Size = New-Object System.Drawing.Size(1150, 65)
        $pnlHeader.BackColor = [System.Drawing.Color]::FromArgb(60, 70, 90)
        $lblTitle = New-Object System.Windows.Forms.Label
        $lblTitle.Location = New-Object System.Drawing.Point(15, 10)
        $lblTitle.Size = New-Object System.Drawing.Size(400, 28)
        $lblTitle.Text = "Change History"
        $lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
        $lblTitle.ForeColor = [System.Drawing.Color]::White
        $pnlHeader.Controls.Add($lblTitle)
        $lblHistInfo = New-Object System.Windows.Forms.Label
        $lblHistInfo.Location = New-Object System.Drawing.Point(15, 40)
        $lblHistInfo.Size = New-Object System.Drawing.Size(700, 18)
        $lblHistInfo.Text = if ($script:isViewerVersion) { 
            "Total: $($allEntries.Count) entries | $($groupCounts.Count) unique operations | Rollback available in Pro version" 
        } else { 
            "Total: $($allEntries.Count) entries | $($groupCounts.Count) unique operations | Select a row and use Rollback to undo changes" 
        }
        $lblHistInfo.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $lblHistInfo.ForeColor = [System.Drawing.Color]::FromArgb(180, 200, 220)
        $pnlHeader.Controls.Add($lblHistInfo)
        $dlgHist.Controls.Add($pnlHeader)
        $pnlLegend = New-Object System.Windows.Forms.Panel
        $pnlLegend.Location = New-Object System.Drawing.Point(15, 68)
        $pnlLegend.Size = New-Object System.Drawing.Size(1100, 22)
        $pnlLegend.BackColor = [System.Drawing.Color]::FromArgb(252, 252, 255)
        $legendX = 5
        $lblLegNtfs = New-Object System.Windows.Forms.Label
        $lblLegNtfs.Location = New-Object System.Drawing.Point($legendX, 3)
        $lblLegNtfs.AutoSize = $true
        $lblLegNtfs.Text = "NTFS"
        $lblLegNtfs.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblLegNtfs.ForeColor = [System.Drawing.Color]::FromArgb(40, 100, 50)
        $pnlLegend.Controls.Add($lblLegNtfs)
        $legendX += 50
        $lblLegShare = New-Object System.Windows.Forms.Label
        $lblLegShare.Location = New-Object System.Drawing.Point($legendX, 3)
        $lblLegShare.AutoSize = $true
        $lblLegShare.Text = "SHARE"
        $lblLegShare.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblLegShare.ForeColor = [System.Drawing.Color]::FromArgb(30, 80, 150)
        $pnlLegend.Controls.Add($lblLegShare)
        $legendX += 60
        $lblLegRemove = New-Object System.Windows.Forms.Label
        $lblLegRemove.Location = New-Object System.Drawing.Point($legendX, 3)
        $lblLegRemove.AutoSize = $true
        $lblLegRemove.Text = "Remove"
        $lblLegRemove.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblLegRemove.ForeColor = [System.Drawing.Color]::FromArgb(180, 50, 50)
        $pnlLegend.Controls.Add($lblLegRemove)
        $legendX += 65
        $lblLegRollback = New-Object System.Windows.Forms.Label
        $lblLegRollback.Location = New-Object System.Drawing.Point($legendX, 3)
        $lblLegRollback.AutoSize = $true
        $lblLegRollback.Text = "Rollback"
        $lblLegRollback.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblLegRollback.ForeColor = [System.Drawing.Color]::FromArgb(200, 120, 50)
        $pnlLegend.Controls.Add($lblLegRollback)
        $legendX += 70
        $lblLegUndone = New-Object System.Windows.Forms.Label
        $lblLegUndone.Location = New-Object System.Drawing.Point($legendX, 3)
        $lblLegUndone.AutoSize = $true
        $lblLegUndone.Text = "[UNDONE] = Already rolled back"
        $lblLegUndone.Font = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Strikeout)
        $lblLegUndone.ForeColor = [System.Drawing.Color]::FromArgb(160, 160, 160)
        $pnlLegend.Controls.Add($lblLegUndone)
        $dlgHist.Controls.Add($pnlLegend)
        $pnlFilter = New-Object System.Windows.Forms.Panel
        $pnlFilter.Location = New-Object System.Drawing.Point(15, 92)
        $pnlFilter.Size = New-Object System.Drawing.Size(1100, 35)
        $pnlFilter.BackColor = [System.Drawing.Color]::FromArgb(248, 250, 252)
        $pnlFilter.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $lblFilterAdmin = New-Object System.Windows.Forms.Label
        $lblFilterAdmin.Location = New-Object System.Drawing.Point(8, 8)
        $lblFilterAdmin.Size = New-Object System.Drawing.Size(80, 18)
        $lblFilterAdmin.Text = "Admin user:"
        $lblFilterAdmin.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $pnlFilter.Controls.Add($lblFilterAdmin)
        $txtFilterAdmin = New-Object System.Windows.Forms.TextBox
        $txtFilterAdmin.Location = New-Object System.Drawing.Point(90, 5)
        $txtFilterAdmin.Size = New-Object System.Drawing.Size(120, 22)
        $txtFilterAdmin.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $pnlFilter.Controls.Add($txtFilterAdmin)
        $lblFilterTarget = New-Object System.Windows.Forms.Label
        $lblFilterTarget.Location = New-Object System.Drawing.Point(225, 8)
        $lblFilterTarget.Size = New-Object System.Drawing.Size(100, 18)
        $lblFilterTarget.Text = "Affected user:"
        $lblFilterTarget.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $pnlFilter.Controls.Add($lblFilterTarget)
        $txtFilterTarget = New-Object System.Windows.Forms.TextBox
        $txtFilterTarget.Location = New-Object System.Drawing.Point(325, 5)
        $txtFilterTarget.Size = New-Object System.Drawing.Size(120, 22)
        $txtFilterTarget.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $pnlFilter.Controls.Add($txtFilterTarget)
        $lblFilterPath = New-Object System.Windows.Forms.Label
        $lblFilterPath.Location = New-Object System.Drawing.Point(460, 8)
        $lblFilterPath.Size = New-Object System.Drawing.Size(40, 18)
        $lblFilterPath.Text = "Path:"
        $lblFilterPath.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $pnlFilter.Controls.Add($lblFilterPath)
        $txtFilterPath = New-Object System.Windows.Forms.TextBox
        $txtFilterPath.Location = New-Object System.Drawing.Point(500, 5)
        $txtFilterPath.Size = New-Object System.Drawing.Size(150, 22)
        $txtFilterPath.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $pnlFilter.Controls.Add($txtFilterPath)
        $btnApplyFilter = New-Object System.Windows.Forms.Button
        $btnApplyFilter.Location = New-Object System.Drawing.Point(665, 4)
        $btnApplyFilter.Size = New-Object System.Drawing.Size(70, 24)
        $btnApplyFilter.Text = "Filter"
        $btnApplyFilter.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnApplyFilter.BackColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
        $btnApplyFilter.ForeColor = [System.Drawing.Color]::White
        $btnApplyFilter.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $pnlFilter.Controls.Add($btnApplyFilter)
        $btnClearFilter = New-Object System.Windows.Forms.Button
        $btnClearFilter.Location = New-Object System.Drawing.Point(740, 4)
        $btnClearFilter.Size = New-Object System.Drawing.Size(70, 24)
        $btnClearFilter.Text = "Clear"
        $btnClearFilter.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnClearFilter.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $pnlFilter.Controls.Add($btnClearFilter)
        $btnExportFiltered = New-Object System.Windows.Forms.Button
        $btnExportFiltered.Location = New-Object System.Drawing.Point(820, 4)
        $btnExportFiltered.Size = New-Object System.Drawing.Size(100, 24)
        $btnExportFiltered.Text = "Export CSV"
        $btnExportFiltered.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnExportFiltered.BackColor = [System.Drawing.Color]::FromArgb(40, 100, 60)
        $btnExportFiltered.ForeColor = [System.Drawing.Color]::White
        $btnExportFiltered.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $pnlFilter.Controls.Add($btnExportFiltered)
        $lblFilterCount = New-Object System.Windows.Forms.Label
        $lblFilterCount.Location = New-Object System.Drawing.Point(930, 8)
        $lblFilterCount.Size = New-Object System.Drawing.Size(160, 18)
        $lblFilterCount.Text = "Showing: $($sortedEntries.Count)"
        $lblFilterCount.Font = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Bold)
        $lblFilterCount.ForeColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
        $pnlFilter.Controls.Add($lblFilterCount)
        $dlgHist.Controls.Add($pnlFilter)
        $lvHist = New-Object System.Windows.Forms.ListView
        $lvHist.Location = New-Object System.Drawing.Point(15, 132)
        $lvHist.Size     = New-Object System.Drawing.Size(1100, 400)
        $lvHist.View     = [System.Windows.Forms.View]::Details
        $lvHist.FullRowSelect = $true
        $lvHist.GridLines = $true
        $lvHist.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $lvHist.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $null = $lvHist.Columns.Add("Time", 140)
        $null = $lvHist.Columns.Add("User", 100)
        $null = $lvHist.Columns.Add("Action", 140)
        $null = $lvHist.Columns.Add("Path", 280)
        $null = $lvHist.Columns.Add("Details", 200)
        $null = $lvHist.Columns.Add("GroupId", 100)
        $null = $lvHist.Columns.Add("Ops", 45)
        $fontNormal = New-Object System.Drawing.Font("Segoe UI", 9)
        $fontStrikethrough = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Strikeout)
        $populateHistoryList = {
            $logFilesRefresh = Get-ChildItem -Path $logRoot -Filter "FSManager-log_*.log" -ErrorAction SilentlyContinue | Sort-Object Name -Descending
            $allEntries.Clear()
            foreach ($lf in $logFilesRefresh) {
                $lines = gc -Path $lf.FullName -ErrorAction SilentlyContinue
                foreach ($line in $lines) {
                    if ([string]::IsNullOrWhiteSpace($line)) { continue }
                    try {
                        $ent = $line | ConvertFrom-Json
                        if (-not $ent.Action -or $ent.Level) { continue }
                        $allEntries.Add([PSCustomObject]@{
                            Time     = if ($ent.Time) { $ent.Time } else { "" }
                            User     = if ($ent.User) { $ent.User } else { "" }
                            Action   = $ent.Action
                            Path     = if ($ent.Path) { $ent.Path } else { "" }
                            Details  = if ($ent.Details) { $ent.Details } else { "" }
                            OldSddl  = if ($ent.OldSddl) { $ent.OldSddl } else { "" }
                            NewSddl  = if ($ent.NewSddl) { $ent.NewSddl } else { "" }
                            GroupId  = if ($ent.GroupId) { $ent.GroupId } else { "" }
                            LogFile  = $lf.Name
                        })
                    } catch {}
                }
            }
            $groupCounts.Clear()
            foreach ($e in $allEntries) {
                if ($e.GroupId) {
                    if (-not $groupCounts.ContainsKey($e.GroupId)) { $groupCounts[$e.GroupId] = 0 }
                    $groupCounts[$e.GroupId]++
                }
            }
            $rolledBackEntries = @{}  # Key = "Path|Action|Time" -> true
            foreach ($rb in ($allEntries | ? { $_.Action -like "*Rollback*" })) {
                $rbPath = $rb.Path
                $rbDetails = $rb.Details
                if ($rbPath -and $rbDetails) {
                    $origAction = $null
                    $origTime = $null
                    if ($rbDetails -match 'rollback from: (\w+) at (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})') {
                        $origAction = $matches[1]
                        $origTime = $matches[2]
                    }
                    elseif ($rbDetails -match 'rollback of (\w+) at (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})') {
                        $origAction = $matches[1]
                        $origTime = $matches[2]
                    }
                    elseif ($rbDetails -match ' at (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})') {
                        $origTime = $matches[1]
                    }
                    if ($origTime) {
                        if ($origAction) {
                            $key = "$rbPath|$origAction|$origTime"
                        } else {
                            $key = "$rbPath||$origTime"
                        }
                        $rolledBackEntries[$key] = $true
                    }
                }
            }
            $sorted = $allEntries | Sort-Object Time -Descending
            $lvHist.Items.Clear()
            foreach ($entry in $sorted) {
                $item = New-Object System.Windows.Forms.ListViewItem
                $item.Text = if ($entry.Time) { $entry.Time } else { "" }
                $null = $item.SubItems.Add($(if ($entry.User) { $entry.User } else { "" }))
                $isRolledBack = $false
                $actionStr = if ($entry.Action) { $entry.Action } else { "" }
                if ($actionStr -notlike "*Rollback*" -and $entry.Path -and $entry.Time) {
                    $fullKey = "$($entry.Path)|$actionStr|$($entry.Time)"
                    $fallbackKey = "$($entry.Path)||$($entry.Time)"
                    if ($rolledBackEntries.ContainsKey($fullKey) -or $rolledBackEntries.ContainsKey($fallbackKey)) {
                        $isRolledBack = $true
                    }
                }
                if ($isRolledBack) {
                    $null = $item.SubItems.Add("$actionStr [UNDONE]")
                    $item.Font = $fontStrikethrough
                    $item.ForeColor = [System.Drawing.Color]::FromArgb(160, 160, 160)
                    $item.BackColor = [System.Drawing.Color]::FromArgb(248, 248, 248)
                } else {
                    $null = $item.SubItems.Add($actionStr)
                    $item.Font = $fontNormal
                    if ($actionStr -like "*Rollback*") {
                        $item.ForeColor = [System.Drawing.Color]::FromArgb(200, 120, 50)
                        $item.BackColor = [System.Drawing.Color]::FromArgb(255, 248, 240)
                    } elseif ($actionStr -like "*Remove*") {
                        $item.ForeColor = [System.Drawing.Color]::FromArgb(180, 50, 50)
                        $item.BackColor = [System.Drawing.Color]::FromArgb(255, 245, 245)
                    } elseif ($actionStr -like "NTFS_*") {
                        $item.ForeColor = [System.Drawing.Color]::FromArgb(40, 100, 50)
                    } elseif ($actionStr -like "SHARE_*") {
                        $item.ForeColor = [System.Drawing.Color]::FromArgb(30, 80, 150)
                    }
                }
                $null = $item.SubItems.Add($(if ($entry.Path) { $entry.Path } else { "" }))
                $null = $item.SubItems.Add($(if ($entry.Details) { $entry.Details } else { "" }))
                $gid = if ($entry.GroupId) { $entry.GroupId } else { "" }
                $groupIdShort = if ($gid.Length -gt 8) { $gid.Substring(0,8) + "..." } else { $gid }
                $null = $item.SubItems.Add($groupIdShort)
                $opsCount = if ($gid -and $groupCounts.ContainsKey($gid)) { $groupCounts[$gid] } else { 1 }
                $null = $item.SubItems.Add($opsCount.ToString())
                $item.Tag = $entry
                $lvHist.Items.Add($item) | Out-Null
            }
            $lblHistInfo.Text = "Total: $($allEntries.Count) entries | $($groupCounts.Count) unique operations"
        }
        & $populateHistoryList
        $applyHistoryFilter = {
            $adminFilter = $txtFilterAdmin.Text.Trim()
            $targetFilter = $txtFilterTarget.Text.Trim()
            $pathFilter = $txtFilterPath.Text.Trim()
            if (-not $adminFilter -and -not $targetFilter -and -not $pathFilter) {
                & $populateHistoryList
                $lblFilterCount.Text = ""
                return
            }
            & $populateHistoryList
            $toRemove = @()
            foreach ($item in $lvHist.Items) {
                $entry = $item.Tag
                $matchAdmin = (-not $adminFilter) -or ($entry.User -like "*$adminFilter*")
                $matchTarget = (-not $targetFilter) -or ($entry.Details -like "*$targetFilter*") -or ($entry.Path -like "*$targetFilter*")
                $matchPath = (-not $pathFilter) -or ($entry.Path -like "*$pathFilter*")
                if (-not ($matchAdmin -and $matchTarget -and $matchPath)) {
                    $toRemove += $item
                }
            }
            foreach ($item in $toRemove) {
                $lvHist.Items.Remove($item)
            }
            $lblFilterCount.Text = "Filtered: $($lvHist.Items.Count) / $($allEntries.Count)"
        }
        $btnApplyFilter.Add_Click({ & $applyHistoryFilter })
        $btnClearFilter.Add_Click({
            $txtFilterAdmin.Text = ""
            $txtFilterTarget.Text = ""
            $txtFilterPath.Text = ""
            & $applyHistoryFilter
        })
        $filterKeyHandler = {
            param($sender, $e)
            if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
                $e.SuppressKeyPress = $true
                & $applyHistoryFilter
            }
        }
        $txtFilterAdmin.Add_KeyDown($filterKeyHandler)
        $txtFilterTarget.Add_KeyDown($filterKeyHandler)
        $txtFilterPath.Add_KeyDown($filterKeyHandler)
        $btnExportFiltered.Add_Click({
            if ($lvHist.Items.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show("No entries to export.", "Info",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                return
            }
            $sfd = New-Object System.Windows.Forms.SaveFileDialog
            $sfd.Title = "Export Change History to CSV"
            $sfd.Filter = "CSV Files|*.csv"
            $sfd.FileName = "ChangeHistory_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
            if ($sfd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
            try {
                $exportLines = @()
                $exportLines += "Timestamp;Status;Type;Operation;Admin;Path;Details"
                foreach ($item in $lvHist.Items) {
                    $entry = $item.Tag
                    $status = if ($item.Font.Strikeout) { "UNDONE" } else { "" }
                    $type = "OTHER"
                    if ($entry.Action -like "NTFS_*") { $type = "NTFS" }
                    elseif ($entry.Action -like "SHARE_*") { $type = "SHARE" }
                    $cleanAction = $entry.Action -replace "^NTFS_|^SHARE_", ""
                    $details = ($entry.Details -replace ";", ",") -replace '"', "'"
                    $path = $entry.Path -replace ";", ","
                    $line = "$($entry.Time);$status;$type;$cleanAction;$($entry.User);$path;$details"
                    $exportLines += $line
                }
                $exportLines | Out-File -FilePath $sfd.FileName -Encoding UTF8
                [System.Windows.Forms.MessageBox]::Show(
                    "Exported $($exportLines.Count - 1) entries to:`r`n$($sfd.FileName)",
                    "Export Complete",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information
                ) | Out-Null
            } catch {
                [System.Windows.Forms.MessageBox]::Show(
                    "Export error:`r`n$($_.Exception.Message)",
                    "Error",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Error
                ) | Out-Null
            }
        })
        $ctxHist = New-Object System.Windows.Forms.ContextMenuStrip
        $ctxHist.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $mnuHistGoTo = New-Object System.Windows.Forms.ToolStripMenuItem
        $mnuHistGoTo.Text = "Go to folder in tree"
        $mnuHistGoTo.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
        $ctxHist.Items.Add($mnuHistGoTo) | Out-Null
        $mnuHistRollbackSingle = New-Object System.Windows.Forms.ToolStripMenuItem
        $mnuHistRollbackSingle.Text = if ($script:isViewerVersion) { "Rollback this entry only (Pro only)" } else { "Rollback this entry only" }
        $mnuHistRollbackSingle.Enabled = -not $script:isViewerVersion
        $ctxHist.Items.Add($mnuHistRollbackSingle) | Out-Null
        $mnuHistRollbackGroup = New-Object System.Windows.Forms.ToolStripMenuItem
        $mnuHistRollbackGroup.Text = if ($script:isViewerVersion) { "Rollback entire operation group (Pro only)" } else { "Rollback entire operation group" }
        $mnuHistRollbackGroup.ForeColor = if ($script:isViewerVersion) { [System.Drawing.Color]::Gray } else { [System.Drawing.Color]::FromArgb(180, 80, 50) }
        $mnuHistRollbackGroup.Enabled = -not $script:isViewerVersion
        $ctxHist.Items.Add($mnuHistRollbackGroup) | Out-Null
        $ctxHist.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
        $mnuHistShowSddl = New-Object System.Windows.Forms.ToolStripMenuItem
        $mnuHistShowSddl.Text = "Show SDDL details"
        $ctxHist.Items.Add($mnuHistShowSddl) | Out-Null
        $mnuHistCopyPath = New-Object System.Windows.Forms.ToolStripMenuItem
        $mnuHistCopyPath.Text = "Copy path to clipboard"
        $ctxHist.Items.Add($mnuHistCopyPath) | Out-Null
        $lvHist.ContextMenuStrip = $ctxHist
        $pnlButtons = New-Object System.Windows.Forms.Panel
        $pnlButtons.Location = New-Object System.Drawing.Point(15, 535)
        $pnlButtons.Size = New-Object System.Drawing.Size(1100, 70)
        $pnlButtons.BackColor = [System.Drawing.Color]::FromArgb(248, 250, 252)
        $pnlButtons.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $lblCount = New-Object System.Windows.Forms.Label
        $lblCount.Location = New-Object System.Drawing.Point(10, 5)
        $lblCount.Size     = New-Object System.Drawing.Size(700, 18)
        $lblCount.Text     = "Legend:  Green = NTFS  |  Blue = Share  |  Red = Remove  |  Orange = Rollback  |  Right-click for options"
        $lblCount.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblCount.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
        $pnlButtons.Controls.Add($lblCount)
        $btnShowSddl = New-Object System.Windows.Forms.Button
        $btnShowSddl.Location = New-Object System.Drawing.Point(10, 28)
        $btnShowSddl.Size     = New-Object System.Drawing.Size(120, 32)
        $btnShowSddl.Text     = "SDDL Details"
        $btnShowSddl.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnShowSddl.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnShowSddl.Cursor = [System.Windows.Forms.Cursors]::Hand
        $btnShowSddl.Add_Click({
            if ($lvHist.SelectedItems.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show("Select a row first.", "Info",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                return
            }
            $sel = $lvHist.SelectedItems[0].Tag
            $msg = "Time: $($sel.Time)`r`nAction: $($sel.Action)`r`nPath: $($sel.Path)`r`nGroupId: $($sel.GroupId)`r`n`r`n"
            $msg += "OLD SDDL:`r`n$($sel.OldSddl)`r`n`r`n"
            $msg += "NEW SDDL:`r`n$($sel.NewSddl)"
            $dlgSddl = New-Object System.Windows.Forms.Form
            $dlgSddl.Text = "SDDL Details"
            $dlgSddl.Size = New-Object System.Drawing.Size(700, 400)
            $dlgSddl.StartPosition = "CenterParent"
            $txtSddl = New-Object System.Windows.Forms.TextBox
            $txtSddl.Multiline = $true
            $txtSddl.ScrollBars = "Both"
            $txtSddl.Location = New-Object System.Drawing.Point(10, 10)
            $txtSddl.Size = New-Object System.Drawing.Size(665, 340)
            $txtSddl.Font = New-Object System.Drawing.Font("Consolas", 9)
            $txtSddl.Text = $msg
            $txtSddl.ReadOnly = $true
            $dlgSddl.Controls.Add($txtSddl)
            [void]$dlgSddl.ShowDialog()
        })
        $pnlButtons.Controls.Add($btnShowSddl)
        $btnRollback = New-Object System.Windows.Forms.Button
        $btnRollback.Location = New-Object System.Drawing.Point(140, 28)
        $btnRollback.Size     = New-Object System.Drawing.Size(180, 32)
        $btnRollback.Text     = "Rollback Group"
        $btnRollback.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnRollback.BackColor = [System.Drawing.Color]::FromArgb(180, 80, 50)
        $btnRollback.ForeColor = [System.Drawing.Color]::White
        $btnRollback.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnRollback.Cursor = [System.Windows.Forms.Cursors]::Hand
        # Viewer version - style as disabled but keep enabled for tooltips
        $btnRollback.Enabled = $true
        if ($script:isViewerVersion) {
            $btnRollback.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
            $btnRollback.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
            $script:toolTip.SetToolTip($btnRollback, "Available in FS-Manager Pro - Rollback permission changes")
        }
        $pnlButtons.Controls.Add($btnRollback)
        $btnRollback.Add_Click({
            if ($script:isViewerVersion) {
                Show-ViewerProMessage "Rollback Permission Changes"
                return
            }
            if ($script:readOnlyMode) {
                [System.Windows.Forms.MessageBox]::Show("Read-only mode is enabled.", "Read-only",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                return
            }
            if ($lvHist.SelectedItems.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show("Select a row to rollback.", "Info",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                return
            }
            $sel = $lvHist.SelectedItems[0].Tag
            $groupId = $sel.GroupId
            Write-FsDebug -Category "Rollback" -Message "Selected entry details" -Details "Action=$($sel.Action); GroupId=$($sel.GroupId); HasOldSddl=$(-not [string]::IsNullOrWhiteSpace($sel.OldSddl))"
            if ([string]::IsNullOrWhiteSpace($groupId)) {
                [System.Windows.Forms.MessageBox]::Show(
                    "This entry has no GroupId - cannot perform group rollback.`r`n(Older log entries may not have GroupId)",
                    "Cannot rollback",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                ) | Out-Null
                return
            }
            $localAllEntries = $allEntries
            Write-FsDebug -Category "Rollback" -Message "Group rollback starting" -Details "GroupId=$groupId; TotalAllEntries=$($localAllEntries.Count)"
            $groupEntries = @($localAllEntries | ? { $_.GroupId -eq $groupId } | Sort-Object Time -Descending)
            Write-FsDebug -Category "Rollback" -Message "Found group entries" -Details "GroupId=$groupId; MatchingEntries=$($groupEntries.Count)"
            if ($groupEntries.Count -eq 0) {
                Write-FsDebug -Category "Rollback" -Message "GroupId not found in allEntries, using selected entry as fallback" -Details "GroupId=$groupId"
                $groupEntries = @($sel)
            }
            if ($groupEntries.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show(
                    "No entries found for GroupId: $groupId`r`n`r`nTotal entries in log: $($localAllEntries.Count)`r`n`r`nThis may happen if the log file was modified.",
                    "GroupId Not Found",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Error
                ) | Out-Null
                return
            }
            foreach ($ge in $groupEntries) {
                $sddlLen = if ($ge.OldSddl) { $ge.OldSddl.Length } else { 0 }
                $hasOldSddl = -not [string]::IsNullOrWhiteSpace($ge.OldSddl)
                Write-FsDebug -Category "Rollback" -Message "Entry check" -Details "Action=$($ge.Action); HasOldSddl=$hasOldSddl; OldSddlLen=$sddlLen"
            }
            $ntfsEntries = @($groupEntries | ? { $_.Action -like "NTFS_*" -and -not [string]::IsNullOrWhiteSpace($_.OldSddl) })
            Write-FsDebug -Category "Rollback" -Message "Categorized entries" -Details "NTFS=$($ntfsEntries.Count); Total=$($groupEntries.Count)"
            $ntfsActions = $groupEntries | ? { $_.Action -like "NTFS_*" }
            if ($ntfsActions.Count -gt 0 -and $ntfsEntries.Count -eq 0) {
                $firstNtfs = $ntfsActions | Select-Object -First 1
                [System.Windows.Forms.MessageBox]::Show(
                    "DEBUG: NTFS entry found but OldSddl check failed.`r`n`r`n" +
                    "Action: $($firstNtfs.Action)`r`n" +
                    "OldSddl is null: $($null -eq $firstNtfs.OldSddl)`r`n" +
                    "OldSddl is empty: $([string]::IsNullOrWhiteSpace($firstNtfs.OldSddl))`r`n" +
                    "OldSddl length: $(if ($firstNtfs.OldSddl) { $firstNtfs.OldSddl.Length } else { 'null' })`r`n" +
                    "OldSddl type: $($firstNtfs.OldSddl.GetType().Name)",
                    "Debug Info",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information
                ) | Out-Null
            }
            $shareAddEntries = $groupEntries | ? { $_.Action -eq "SHARE_AddAce" }
            $shareRemoveEntries = $groupEntries | ? { $_.Action -eq "SHARE_RemoveAce" }
            $shareCloneEntries = $groupEntries | ? { $_.Action -eq "SHARE_CloneAce" }
            $otherEntries = $groupEntries | ? { 
                $_.Action -notlike "NTFS_*" -and 
                $_.Action -ne "SHARE_AddAce" -and 
                $_.Action -ne "SHARE_RemoveAce" -and 
                $_.Action -ne "SHARE_CloneAce"
            }
            $totalShareEntries = $shareAddEntries.Count + $shareRemoveEntries.Count + $shareCloneEntries.Count
            $totalRollbackable = $ntfsEntries.Count + $totalShareEntries
            $msg = "Rollback operation group:`r`n"
            $msg += "GroupId: $groupId`r`n"
            $msg += "Total entries: $($groupEntries.Count)`r`n`r`n"
            $msg += "Rollbackable:`r`n"
            $msg += "  NTFS entries: $($ntfsEntries.Count)`r`n"
            $msg += "  SHARE_AddAce (will revoke): $($shareAddEntries.Count)`r`n"
            $msg += "  SHARE_RemoveAce (will re-grant): $($shareRemoveEntries.Count)`r`n"
            $msg += "  SHARE_CloneAce (will revoke): $($shareCloneEntries.Count)`r`n"
            $msg += "  Other (will skip): $($otherEntries.Count)`r`n`r`n"
            if ($totalRollbackable -eq 0) {
                [System.Windows.Forms.MessageBox]::Show(
                    "No rollbackable entries found in this group.`r`nRollback is supported for NTFS and Share actions.",
                    "Cannot rollback",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                ) | Out-Null
                return
            }
            $msg += "Continue with rollback?"
            $confirm = [System.Windows.Forms.MessageBox]::Show(
                $msg,
                "Confirm Group Rollback",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return }
            $rollbackGroupId = [guid]::NewGuid().ToString()
            $ntfsSuccess = 0
            $shareSuccess = 0
            $failCount = 0
            $skippedCount = $otherEntries.Count
            $errors = @()
            foreach ($entry in $ntfsEntries) {
                try {
                    if (-not (Test-Path $entry.Path)) {
                        $errors += "NTFS Path not found: $($entry.Path)"
                        $failCount++
                        continue
                    }
                    $acl = Get-Acl -Path $entry.Path -ErrorAction Stop
                    $currentSddl = $acl.Sddl
                    $acl.SetSecurityDescriptorSddlForm($entry.OldSddl)
                    Set-Acl -Path $entry.Path -AclObject $acl -ErrorAction Stop
                    Write-FsLog -Action "NTFS_Rollback" -Path $entry.Path `
                        -Details "Group rollback from: $($entry.Action) at $($entry.Time)" `
                        -OldSddl $currentSddl -NewSddl $entry.OldSddl `
                        -GroupId $rollbackGroupId
                    $ntfsSuccess++
                } catch {
                    $errors += "NTFS $($entry.Path): $($_.Exception.Message)"
                    $failCount++
                }
            }
            foreach ($entry in $shareAddEntries) {
                try {
                    $principal = $null
                    if ($entry.Details -match "Principal=([^;]+)") { 
                        $principal = $Matches[1].Trim()
                    }
                    if (-not $principal) {
                        $errors += "SHARE_AddAce on $($entry.Path): Cannot parse Principal from Details"
                        $failCount++
                        continue
                    }
                    Revoke-SmbShareAccess -Name $entry.Path -AccountName $principal -Force -ErrorAction Stop
                    Write-FsLog -Action "SHARE_Rollback" -Path $entry.Path `
                        -Details "Revoked $principal (rollback of SHARE_AddAce at $($entry.Time))" `
                        -GroupId $rollbackGroupId
                    $shareSuccess++
                } catch {
                    $errors += "SHARE_AddAce rollback $($entry.Path): $($_.Exception.Message)"
                    $failCount++
                }
            }
            foreach ($entry in $shareRemoveEntries) {
                try {
                    $principal = $null
                    $accessRight = $null
                    if ($entry.Details -match "Principal=([^;]+)") { 
                        $principal = $Matches[1].Trim()
                    }
                    if ($entry.Details -match "Access=([^;]+)") { 
                        $accessRight = $Matches[1].Trim()
                    } elseif ($entry.Details -match "Rights=([^;]+)") {
                        $accessRight = $Matches[1].Trim()
                    }
                    if (-not $principal -or -not $accessRight) {
                        $errors += "SHARE_RemoveAce on $($entry.Path): Cannot parse Principal or Access from Details: $($entry.Details)"
                        $failCount++
                        continue
                    }
                    $shareName = $entry.Path
                    if ($entry.Details -match "Share=([^;]+)") {
                        $shareName = $Matches[1].Trim()
                    }
                    Grant-SmbShareAccess -Name $shareName -AccountName $principal -AccessRight $accessRight -Force -ErrorAction Stop
                    Write-FsLog -Action "SHARE_Rollback" -Path $entry.Path `
                        -Details "Re-granted $accessRight to $principal (rollback of SHARE_RemoveAce at $($entry.Time))" `
                        -GroupId $rollbackGroupId
                    $shareSuccess++
                } catch {
                    $errors += "SHARE_RemoveAce rollback $($entry.Path): $($_.Exception.Message)"
                    $failCount++
                }
            }
            foreach ($entry in $shareCloneEntries) {
                try {
                    $targetPrincipal = $null
                    if ($entry.Details -match "To=([^;]+)") { 
                        $targetPrincipal = $Matches[1].Trim()
                    }
                    if (-not $targetPrincipal) {
                        $errors += "SHARE_CloneAce on $($entry.Path): Cannot parse target Principal from Details"
                        $failCount++
                        continue
                    }
                    Revoke-SmbShareAccess -Name $entry.Path -AccountName $targetPrincipal -Force -ErrorAction Stop
                    Write-FsLog -Action "SHARE_Rollback" -Path $entry.Path `
                        -Details "Revoked $targetPrincipal (rollback of SHARE_CloneAce at $($entry.Time))" `
                        -GroupId $rollbackGroupId
                    $shareSuccess++
                } catch {
                    $errors += "SHARE_CloneAce rollback $($entry.Path): $($_.Exception.Message)"
                    $failCount++
                }
            }
            if ($script:currentPath) {
                Update-NtfsTab -Path $script:currentPath
            }
            if ($script:currentShareName) {
                Update-ShareTab -ShareName $script:currentShareName
            }
            $resultMsg = "Group Rollback Complete`r`n`r`n"
            $resultMsg += "NTFS rollbacks: $ntfsSuccess`r`n"
            $resultMsg += "Share rollbacks: $shareSuccess`r`n"
            $resultMsg += "Failed: $failCount`r`n"
            $resultMsg += "Skipped (other): $skippedCount`r`n"
            if ($errors.Count -gt 0) {
                $resultMsg += "`r`nErrors:`r`n"
                $resultMsg += ($errors | Select-Object -First 5) -join "`r`n"
                if ($errors.Count -gt 5) { $resultMsg += "`r`n... and more" }
            }
            [System.Windows.Forms.MessageBox]::Show(
                $resultMsg,
                "Rollback Result",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                $(if ($failCount -gt 0) { [System.Windows.Forms.MessageBoxIcon]::Warning } else { [System.Windows.Forms.MessageBoxIcon]::Information })
            ) | Out-Null
            & $populateHistoryList
        })
        $btnExportHist = New-Object System.Windows.Forms.Button
        $btnExportHist.Location = New-Object System.Drawing.Point(330, 28)
        $btnExportHist.Size     = New-Object System.Drawing.Size(120, 32)
        $btnExportHist.Text     = "Export All CSV"
        $btnExportHist.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnExportHist.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnExportHist.Cursor = [System.Windows.Forms.Cursors]::Hand
        $btnExportHist.Add_Click({
            & $populateHistoryList
            if ($lvHist.Items.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show("No entries to export.", "Info",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                return
            }
            $sfd = New-Object System.Windows.Forms.SaveFileDialog
            $sfd.Title    = "Export history to CSV"
            $sfd.Filter   = "CSV Files|*.csv"
            $sfd.FileName = "FSManager_History_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".csv"
            if ($sfd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
            try {
                $exportLines = @()
                $exportLines += "Timestamp;Status;Type;Operation;Admin;Path;Details"
                foreach ($item in $lvHist.Items) {
                    $entry = $item.Tag
                    $status = if ($item.Font.Strikeout) { "UNDONE" } else { "" }
                    $type = "OTHER"
                    if ($entry.Action -like "NTFS_*") { $type = "NTFS" }
                    elseif ($entry.Action -like "SHARE_*") { $type = "SHARE" }
                    $cleanAction = $entry.Action -replace "^NTFS_|^SHARE_", ""
                    $details = ($entry.Details -replace ";", ",") -replace '"', "'"
                    $path = $entry.Path -replace ";", ","
                    $line = "$($entry.Time);$status;$type;$cleanAction;$($entry.User);$path;$details"
                    $exportLines += $line
                }
                $exportLines | Out-File -FilePath $sfd.FileName -Encoding UTF8
                [System.Windows.Forms.MessageBox]::Show(
                    "Exported $($exportLines.Count - 1) entries to:`r`n$($sfd.FileName)",
                    "Export done",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information
                ) | Out-Null
            } catch {
                [System.Windows.Forms.MessageBox]::Show(
                    "Export error:`r`n$($_.Exception.Message)",
                    "Error",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Error
                ) | Out-Null
            }
        })
        $pnlButtons.Controls.Add($btnExportHist)
        $btnClose = New-Object System.Windows.Forms.Button
        $btnClose.Location = New-Object System.Drawing.Point(980, 28)
        $btnClose.Size     = New-Object System.Drawing.Size(100, 32)
        $btnClose.Text     = "Close"
        $btnClose.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $btnClose.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnClose.BackColor = [System.Drawing.Color]::FromArgb(100, 100, 110)
        $btnClose.ForeColor = [System.Drawing.Color]::White
        $btnClose.Cursor = [System.Windows.Forms.Cursors]::Hand
        $btnClose.Add_Click({ $dlgHist.Close() })
        $pnlButtons.Controls.Add($btnClose)
        $mnuHistGoTo.Add_Click({
            if ($lvHist.SelectedItems.Count -eq 0) { return }
            $sel = $lvHist.SelectedItems[0].Tag
            $path = $sel.Path
            if (-not $path) { return }
            try {
                $foundNode = $null
                foreach ($rootNode in $script:tree.Nodes) {
                    if ($rootNode.Tag -and $rootNode.Tag.Path -eq $path) {
                        $foundNode = $rootNode
                        break
                    }
                    try { $rootNode.Expand() } catch { }
                    foreach ($childNode in $rootNode.Nodes) {
                        if ($childNode.Tag -and $childNode.Tag.Path -eq $path) {
                            $foundNode = $childNode
                            break
                        }
                        try { $childNode.Expand() } catch { }
                        foreach ($grandChild in $childNode.Nodes) {
                            if ($grandChild.Tag -and $grandChild.Tag.Path -eq $path) {
                                $foundNode = $grandChild
                                break
                            }
                        }
                        if ($foundNode) { break }
                    }
                    if ($foundNode) { break }
                }
                if ($foundNode) {
                    $foundNode.EnsureVisible()
                    $script:tree.SelectedNode = $foundNode
                    $script:currentPath = $path
                    $dlgHist.Close()
                    $script:form.Activate()
                } else {
                    [System.Windows.Forms.MessageBox]::Show("Folder not found in tree: $path", "Not Found", 
                        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
                }
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Error: $($_.Exception.Message)", "Error", 
                    [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
            }
        })
        $mnuHistRollbackSingle.Add_Click({
            if ($lvHist.SelectedItems.Count -eq 0) { return }
            if ($script:isViewerVersion) {
                Show-ViewerProMessage "Rollback Single Entry"
                return
            }
            if ($script:readOnlyMode) {
                [System.Windows.Forms.MessageBox]::Show("Read-only mode is enabled.", "Read-only",
                    [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                return
            }
            $sel = $lvHist.SelectedItems[0].Tag
            $action = $sel.Action
            $path = $sel.Path
            $confirm = [System.Windows.Forms.MessageBox]::Show(
                "Rollback ONLY this single entry?`r`n`r`nAction: $action`r`nPath: $path",
                "Confirm Single Rollback",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return }
            try {
                Write-FsDebug -Category "Rollback" -Message "Single rollback attempt" -Details "Action=$action; Path=$path; HasOldSddl=$(-not [string]::IsNullOrWhiteSpace($sel.OldSddl))"
                if ($action -like "NTFS_*") {
                    if ([string]::IsNullOrWhiteSpace($sel.OldSddl)) {
                        [System.Windows.Forms.MessageBox]::Show(
                            "Cannot rollback: No SDDL backup found for this entry.`r`n`r`nAction: $action`r`nPath: $path`r`n`r`nThis may be an older log entry without SDDL data.",
                            "No SDDL Backup",
                            [System.Windows.Forms.MessageBoxButtons]::OK,
                            [System.Windows.Forms.MessageBoxIcon]::Warning
                        ) | Out-Null
                        return
                    }
                    if (-not (Test-Path $path)) {
                        [System.Windows.Forms.MessageBox]::Show("Path does not exist: $path", "Path Not Found",
                            [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
                        return
                    }
                    $acl = Get-Acl -Path $path
                    $acl.SetSecurityDescriptorSddlForm($sel.OldSddl)
                    Set-Acl -Path $path -AclObject $acl
                    Write-FsLog -Action "NTFS_Rollback" -Path $path -Details "Single entry rollback from $action" -OldSddl $sel.NewSddl -NewSddl $sel.OldSddl
                    [System.Windows.Forms.MessageBox]::Show("NTFS rollback successful.", "Success",
                        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                }
                elseif ($action -eq "SHARE_AddAce" -or $action -eq "SHARE_CloneAce") {
                    $details = $sel.Details
                    if ($details -match "Principal=([^;]+)") {
                        $principal = $Matches[1]
                        $shareName = if ($details -match "Share=([^;]+)") { $Matches[1] } else { $null }
                        if ($shareName) {
                            Revoke-SmbShareAccess -Name $shareName -AccountName $principal -Force
                            Write-FsLog -Action "SHARE_Rollback" -Path $path -Details "Revoked $principal from $shareName"
                            [System.Windows.Forms.MessageBox]::Show("Share rollback successful.", "Success",
                                [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                        }
                    }
                }
                elseif ($action -eq "SHARE_RemoveAce") {
                    $details = $sel.Details
                    if ($details -match "Principal=([^;]+)") {
                        $principal = $Matches[1]
                        $shareName = if ($details -match "Share=([^;]+)") { $Matches[1] } else { $null }
                        $rights = if ($details -match "Rights=([^;]+)") { $Matches[1] } else { "Read" }
                        if ($shareName) {
                            Grant-SmbShareAccess -Name $shareName -AccountName $principal -AccessRight $rights -Force
                            Write-FsLog -Action "SHARE_Rollback" -Path $path -Details "Re-granted $principal to $shareName with $rights"
                            [System.Windows.Forms.MessageBox]::Show("Share rollback successful.", "Success",
                                [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                        }
                    }
                }
                else {
                    [System.Windows.Forms.MessageBox]::Show("Cannot rollback this action type: $action", "Not Supported",
                        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
                }
                if ($script:currentPath) { Update-NtfsTab -Path $script:currentPath }
                if ($script:currentShareName) { Update-ShareTab -ShareName $script:currentShareName }
                & $populateHistoryList
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Rollback error:`r`n$($_.Exception.Message)", "Error",
                    [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
            }
        })
        $mnuHistRollbackGroup.Add_Click({
            $btnRollback.PerformClick()
        })
        $mnuHistShowSddl.Add_Click({
            $btnShowSddl.PerformClick()
        })
        $mnuHistCopyPath.Add_Click({
            if ($lvHist.SelectedItems.Count -eq 0) { return }
            $path = $lvHist.SelectedItems[0].Tag.Path
            if ($path) {
                [System.Windows.Forms.Clipboard]::SetText($path)
                [System.Windows.Forms.MessageBox]::Show("Copied: $path", "Copied",
                    [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
            }
        })
        $dlgHist.Controls.Add($lvHist)
        $dlgHist.Controls.Add($pnlButtons)
        [void]$dlgHist.ShowDialog()
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Error loading history:`r`n$($_.Exception.Message)",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}
# Note: Wire-UIHandlers function is defined in FSManager.UI.Handlers.Core.ps1
# This file only defines helper functions and scriptblocks used by the handlers

$script:SearchUserPermissions = {
        param([string]$principal)
        $results = New-Object System.Collections.Generic.List[object]
        $shares = Get-ShareData
        foreach ($sh in $shares) {
            try {
                $shareAcl = Get-ShareAcl -ShareName $sh.Name
                if ($shareAcl) {
                    foreach ($ace in $shareAcl) {
                        if ($ace.AccountName -like "*$principal*") {
                            $results.Add([PSCustomObject]@{
                                PermType  = "Share"
                                Path      = $sh.Path
                                ShareName = $sh.Name
                                Principal = $ace.AccountName
                                Rights    = $ace.AccessRight.ToString()
                                AclType   = $ace.AccessControlType.ToString()
                            })
                        }
                    }
                }
            } catch {}
        }
        function Search-LoadedNodesForUserLocal {
            param([System.Windows.Forms.TreeNode]$Node, [string]$SearchPattern)
            if ($Node.Text -eq "...") { return }
            if ($Node.Tag -and $Node.Tag.Path) {
                $folderPath = $Node.Tag.Path
                $shareName = $Node.Tag.ShareName
                $isRedNode = ($Node.ForeColor.Name -eq "DarkRed")
                if ($isRedNode) {
                    try {
                        $acl = Get-Acl -Path $folderPath -ErrorAction Stop
                        foreach ($ace in $acl.Access) {
                            if ($ace.IdentityReference.ToString() -like "*$SearchPattern*") {
                                $results.Add([PSCustomObject]@{
                                    PermType  = "NTFS"
                                    Path      = $folderPath
                                    ShareName = $shareName
                                    Principal = $ace.IdentityReference.ToString()
                                    Rights    = $ace.FileSystemRights.ToString()
                                    AclType   = $ace.AccessControlType.ToString()
                                })
                            }
                        }
                    } catch {}
                }
            }
            foreach ($child in $Node.Nodes) {
                Search-LoadedNodesForUserLocal -Node $child -SearchPattern $SearchPattern
            }
        }
        foreach ($rootNode in $script:tree.Nodes) {
            Search-LoadedNodesForUserLocal -Node $rootNode -SearchPattern $principal
        }
        return $results
    }
