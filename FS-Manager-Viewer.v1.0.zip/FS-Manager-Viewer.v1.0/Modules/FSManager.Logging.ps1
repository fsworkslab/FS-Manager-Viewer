<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.Logging.ps1
# Build: 20251126-142332

$script:FsLogRoot = "C:\Scripts\FSManager\Logs"
if (-not (Test-Path $script:FsLogRoot)) {
    try {
        New-Item -Path $script:FsLogRoot -ItemType Directory -Force | Out-Null
    } catch {}
}
$script:FsLogFile = Join-Path $script:FsLogRoot ("FSManager-log_{0:yyyyMMdd}.log" -f (Get-Date))
$script:FsErrorLog = Join-Path $script:FsLogRoot ("FSManager-errors_{0:yyyyMMdd}.log" -f (Get-Date))
$script:FsDebugLog = Join-Path $script:FsLogRoot ("FSManager-debug_{0:yyyyMMdd}.log" -f (Get-Date))
$script:LogLevel = @{
    DEBUG   = 0
    INFO    = 1
    WARNING = 2
    ERROR   = 3
    ACTION  = 4  # For permission changes
}
$script:MinLogLevel = $script:LogLevel.DEBUG
$script:DebugMode = $true
function Write-FsLogEntry {
    param(
        [ValidateSet("DEBUG", "INFO", "WARNING", "ERROR", "ACTION")]
        [string]$Level = "INFO",
        [string]$Category,
        [string]$Message,
        [string]$Details = "",
        [hashtable]$Data = @{},
        [string]$Exception = ""
    )
    try {
        $levelNum = $script:LogLevel[$Level]
        if ($Level -ne "DEBUG" -and $levelNum -lt $script:MinLogLevel) { return }
        $entry = [PSCustomObject]@{
            Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
            Level     = $Level
            User      = "$env:USERDOMAIN\$env:USERNAME"
            Machine   = $env:COMPUTERNAME
            Category  = $Category
            Message   = $Message
            Details   = $Details
            Data      = if ($Data.Count -gt 0) { $Data | ConvertTo-Json -Compress } else { "" }
            Exception = $Exception
        }
        $line = ($entry | ConvertTo-Json -Compress)
        switch ($Level) {
            "ERROR" {
                Add-Content -Path $script:FsErrorLog -Value $line -ErrorAction SilentlyContinue
                Add-Content -Path $script:FsLogFile -Value $line -ErrorAction SilentlyContinue
            }
            "DEBUG" {
                if ($script:DebugMode) {
                    Add-Content -Path $script:FsDebugLog -Value $line -ErrorAction SilentlyContinue
                }
            }
            default {
                Add-Content -Path $script:FsLogFile -Value $line -ErrorAction SilentlyContinue
            }
        }
    } catch {
    }
}
function Write-FsDebug {
    param([string]$Category, [string]$Message, [string]$Details = "")
    Write-FsLogEntry -Level "DEBUG" -Category $Category -Message $Message -Details $Details
}
function Write-FsInfo {
    param([string]$Category, [string]$Message, [string]$Details = "")
    Write-FsLogEntry -Level "INFO" -Category $Category -Message $Message -Details $Details
}
function Write-FsWarning {
    param([string]$Category, [string]$Message, [string]$Details = "")
    Write-FsLogEntry -Level "WARNING" -Category $Category -Message $Message -Details $Details
}
function Write-FsError {
    param([string]$Category, [string]$Message, [string]$Details = "", [System.Exception]$Exception = $null)
    $exMsg = if ($Exception) { $Exception.ToString() } else { "" }
    Write-FsLogEntry -Level "ERROR" -Category $Category -Message $Message -Details $Details -Exception $exMsg
}
function Write-FsLog {
    param(
        [string]$Action,
        [string]$Path,
        [string]$Details,
        [string]$OldSddl = "",
        [string]$NewSddl = "",
        [string]$GroupId = ""
    )
    try {
        if ([string]::IsNullOrWhiteSpace($GroupId)) {
            $GroupId = [guid]::NewGuid().ToString()
        }
        $entry = [PSCustomObject]@{
            Time    = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
            User    = "$env:USERDOMAIN\$env:USERNAME"
            Action  = $Action
            Path    = $Path
            Details = $Details
            OldSddl = $OldSddl
            NewSddl = $NewSddl
            GroupId = $GroupId
        }
        $line = ($entry | ConvertTo-Json -Compress)
        Add-Content -Path $script:FsLogFile -Value $line
        Write-FsLogEntry -Level "ACTION" -Category "Permission" -Message $Action -Details $Details -Data @{
            Path = $Path
            GroupId = $GroupId
            HasSddl = (-not [string]::IsNullOrWhiteSpace($OldSddl))
        }
    } catch {
    }
}
function Write-FsUIEvent {
    param(
        [string]$Event,
        [string]$Control,
        [string]$Details = ""
    )
    Write-FsLogEntry -Level "DEBUG" -Category "UI" -Message $Event -Details "Control=$Control; $Details"
}
function Write-FsAppStart {
    Write-FsLogEntry -Level "INFO" -Category "App" -Message "FS-Manager Viewer v1.0 started" -Data @{
        Version = "Viewer v1.0"
        PSVersion = $PSVersionTable.PSVersion.ToString()
        IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        IsViewerVersion = $true
    }
}
function Write-FsAppStop {
    Write-FsLogEntry -Level "INFO" -Category "App" -Message "FS-Manager Viewer v1.0 stopped"
}
function Write-FsAdSearch {
    param(
        [string]$SearchTerm,
        [int]$ResultCount,
        [string]$Details = ""
    )
    Write-FsLogEntry -Level "INFO" -Category "AD" -Message "AD Search performed" -Data @{
        SearchTerm = $SearchTerm
        ResultCount = $ResultCount
    } -Details $Details
}
function Write-FsPermissionChange {
    param(
        [ValidateSet("NTFS", "Share")]
        [string]$Type,
        [ValidateSet("Add", "Remove", "Clone", "Rollback")]
        [string]$Operation,
        [string]$Path,
        [string]$Principal,
        [string]$Rights = "",
        [string]$GroupId = ""
    )
    $action = "${Type}_${Operation}Ace"
    $details = "Principal=$Principal"
    if ($Rights) { $details += "; Rights=$Rights" }
    Write-FsLogEntry -Level "ACTION" -Category "Permission" -Message $action -Details $details -Data @{
        Type = $Type
        Operation = $Operation
        Path = $Path
        Principal = $Principal
        Rights = $Rights
        GroupId = $GroupId
    }
}
function Enable-FsDebugMode {
    $script:DebugMode = $true
    Write-FsInfo -Category "App" -Message "Debug mode enabled"
}
function Disable-FsDebugMode {
    Write-FsInfo -Category "App" -Message "Debug mode disabled"
    $script:DebugMode = $false
}
function Get-FsLogPath {
    return $script:FsLogRoot
}
function Get-FsLogFiles {
    Get-ChildItem -Path $script:FsLogRoot -Filter "*.log" | Sort-Object LastWriteTime -Descending
}
Write-FsLogEntry -Level "INFO" -Category "System" -Message "Logging module loaded"

