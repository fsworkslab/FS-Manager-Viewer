<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Handlers.Ntfs.ps1
# Build: 20251126-142332

function btnExportNtfs_Click {
    if (-not $script:currentPath) {
        [System.Windows.Forms.MessageBox]::Show(
            "Select a folder in the tree first.",
            "Info",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }
    $entries = Get-NtfsAclEntries -Path $script:currentPath
    if (-not $entries) {
        [System.Windows.Forms.MessageBox]::Show(
            "Unable to load NTFS permissions for selected folder.",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }
    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Title    = "Save NTFS permissions to CSV"
    $sfd.Filter   = "CSV Files|*.csv"
    $safeName = $script:currentPath.Replace(":","").Replace("\\","_")
    if ($safeName.Length -gt 40) { $safeName = $safeName.Substring(0,40) }
    $sfd.FileName = "ACL_" + $safeName + ".csv"
    if ($sfd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return
    }
    $outFile = $sfd.FileName
    try {
        $data = $entries | % {
            $pi = Get-PrincipalInfo -Identity ($_.IdentityReference.ToString())
            [PSCustomObject]@{
                Path        = $script:currentPath
                Principal   = $_.IdentityReference.ToString()
                DisplayName = $pi.DisplayName
                Entity      = $pi.Entity
                Rights      = $_.FileSystemRights.ToString()
                Type        = $_.AccessControlType.ToString()
                Inherited   = $(if ($_.IsInherited) { "Yes" } else { "No" })
            }
        }
        $data | Export-Csv -Path $outFile -NoTypeInformation -Encoding UTF8
        [System.Windows.Forms.MessageBox]::Show(
            "NTFS permissions exported to:`r`n$outFile",
            "Done",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Export error:`r`n$($_.Exception.Message)",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

