<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Tabs.ps1
# Build: 20251126-142332

function Update-NtfsTab {
    param([string]$Path)
    if (-not $Path) {
        $script:lblNtfsPath.Text = "Selected folder:"
        $script:lvNtfs.Items.Clear()
        $script:lblNtfsInfo.Text = ""
        return
    }
    $script:lblNtfsPath.Text = "Selected folder:`r`n$Path"
    $script:lvNtfs.Items.Clear()
    $script:lblNtfsInfo.Text = ""
    $entries = Get-NtfsAclEntries -Path $Path
    if (-not $entries) {
        $script:lblNtfsInfo.Text = "Unable to load NTFS permissions (insufficient rights or path doesn't exist)."
        return
    }
    foreach ($ace in $entries) {
        $item = New-Object System.Windows.Forms.ListViewItem
        $principal = $ace.IdentityReference.ToString()
        $item.Text = $principal
        $pi = Get-PrincipalInfo -Identity $principal
        $null = $item.SubItems.Add($pi.DisplayName)
        $null = $item.SubItems.Add($pi.Entity)
        $null = $item.SubItems.Add($ace.FileSystemRights.ToString())
        $null = $item.SubItems.Add($ace.AccessControlType.ToString())
        $null = $item.SubItems.Add($(if ($ace.IsInherited) { "Yes" } else { "No" }))
        $item.Tag = $ace
        $script:lvNtfs.Items.Add($item) | Out-Null
    }
    if (Get-UniqueAclFlag -Path $Path) {
        $script:lblNtfsInfo.Text = "This folder has UNIQUE permissions (inheritance disabled/modified). [Viewer Mode - Read Only]"
    } else {
        $script:lblNtfsInfo.Text = "This folder inherits permissions from the parent. [Viewer Mode - Read Only]"
    }
}
function Update-ShareTab {
    param([string]$ShareName)
    if ($script:lvShare -eq $null) { return }
    $script:lvShare.Items.Clear()
    if (-not $ShareName) {
        $script:lblShareName.Text = "Selected share:"
        return
    }
    $script:lblShareName.Text = "Selected share: $ShareName [Viewer Mode - Read Only]"
    $acc = Get-ShareAcl -ShareName $ShareName
    if (-not $acc) {
        $script:lblShareInfo.Text = "Unable to load share permissions."
        return
    }
    foreach ($a in $acc) {
        $item = New-Object System.Windows.Forms.ListViewItem
        $principal = $a.AccountName
        $item.Text = $principal
        $pi = Get-PrincipalInfo -Identity $principal
        $null = $item.SubItems.Add($pi.DisplayName)
        $null = $item.SubItems.Add($pi.Entity)
        $null = $item.SubItems.Add($a.AccessRight.ToString())
        $null = $item.SubItems.Add($a.AccessControlType.ToString())
        $null = $item.SubItems.Add("Share")
        $script:lvShare.Items.Add($item) | Out-Null
    }
}
function Update-QuotaTab {
    param([string]$Path)
    if ($script:lblQuotaPath -eq $null) { return }
    if (-not $Path) {
        $script:lblQuotaPath.Text    = "Selected path for quota:"
        $script:lblCurrentQuota.Text = "Current quota: -"
        $script:lblFolderSize.Text   = "Current size: -"
        $script:txtNewQuota.Text     = ""
        return
    }
    $script:lblQuotaPath.Text = "Selected path for quota:`r`n$Path [Viewer Mode - Read Only]"
    $script:lblFolderSize.Text = "Current size: -"
    if (-not $script:fsrmAvailable) {
        $script:lblCurrentQuota.Text = "Current quota: (FSRM unavailable)"
        return
    }
    $quota = Get-QuotaInfo -Path $Path
    if ($quota) {
        $sizeGB = [math]::Round(($quota.Size / 1GB), 2)
        $script:lblCurrentQuota.Text = "Current quota: $sizeGB GB " + ($(if ($quota.SoftLimit) { "(Soft)" } else { "(Hard)" }))
        $script:txtNewQuota.Text = "$sizeGB"
        if ($quota.SoftLimit) { $script:rbSoft.Checked = $true } else { $script:rbHard.Checked = $true }
    } else {
        $script:lblCurrentQuota.Text = "Current quota: (no quota set)"
        $script:txtNewQuota.Text = ""
        $script:rbHard.Checked = $true
        $script:rbSoft.Checked = $false
    }
    $script:lblQuotaInfo.Text = "Quota management available in FS-Manager Pro"
}
function Update-ReadOnlyControls {
    <#
    .SYNOPSIS
    Viewer version - all modification controls are permanently disabled.
    This function exists for compatibility but enforces Viewer mode restrictions.
    #>
    param([bool]$ro)
    
    # In Viewer version, always enforce read-only mode
    $script:readOnlyMode = $true
    $script:isViewerVersion = $true
    
    if ($script:btnAddNtfs) { 
        $script:btnAddNtfs.Enabled = $true
        $script:btnAddNtfs.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnAddNtfs.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnAddNtfs, "Available in FS-Manager Pro - Add NTFS permissions")
    }
    if ($script:btnRemoveNtfs) { 
        $script:btnRemoveNtfs.Enabled = $true
        $script:btnRemoveNtfs.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnRemoveNtfs.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnRemoveNtfs, "Available in FS-Manager Pro - Remove NTFS permissions")
    }
    if ($script:btnSaveTemplate) { 
        $script:btnSaveTemplate.Enabled = $true
        $script:btnSaveTemplate.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnSaveTemplate.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnSaveTemplate, "Available in FS-Manager Pro - Save ACL templates")
    }
    if ($script:btnApplyTemplate) { 
        $script:btnApplyTemplate.Enabled = $true
        $script:btnApplyTemplate.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnApplyTemplate.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnApplyTemplate, "Available in FS-Manager Pro - Apply ACL templates")
    }
    if ($script:btnAddAce) { 
        $script:btnAddAce.Enabled = $true
        $script:btnAddAce.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnAddAce.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnAddAce, "Available in FS-Manager Pro - Add NTFS permission entries")
    }
    if ($script:btnRemoveAce) { 
        $script:btnRemoveAce.Enabled = $true
        $script:btnRemoveAce.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnRemoveAce.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnRemoveAce, "Available in FS-Manager Pro - Remove NTFS permission entries")
    }
    if ($script:btnAddShare) { 
        $script:btnAddShare.Enabled = $true
        $script:btnAddShare.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnAddShare.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnAddShare, "Available in FS-Manager Pro - Add shares")
    }
    if ($script:btnRemoveShare) { 
        $script:btnRemoveShare.Enabled = $true
        $script:btnRemoveShare.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnRemoveShare.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnRemoveShare, "Available in FS-Manager Pro - Remove shares")
    }
    if ($script:btnAddShareAce) { 
        $script:btnAddShareAce.Enabled = $true
        $script:btnAddShareAce.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnAddShareAce.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnAddShareAce, "Available in FS-Manager Pro - Add share permissions")
    }
    if ($script:btnRemoveShareAce) { 
        $script:btnRemoveShareAce.Enabled = $true
        $script:btnRemoveShareAce.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnRemoveShareAce.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnRemoveShareAce, "Available in FS-Manager Pro - Remove share permissions")
    }
    if ($script:btnSaveQuota) { 
        $script:btnSaveQuota.Enabled = $true
        $script:btnSaveQuota.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnSaveQuota.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnSaveQuota, "Available in FS-Manager Pro - Apply quota limits")
    }
    if ($script:btnRemoveQuota) { 
        $script:btnRemoveQuota.Enabled = $true
        $script:btnRemoveQuota.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
        $script:btnRemoveQuota.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:btnRemoveQuota, "Available in FS-Manager Pro - Remove quota limits")
    }
    
    # Also style related controls as disabled but keep enabled for tooltips
    if ($script:cbNtfsRights) { 
        $script:cbNtfsRights.Enabled = $true
        $script:cbNtfsRights.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)
        $script:cbNtfsRights.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:cbNtfsRights, "Available in FS-Manager Pro")
    }
    if ($script:txtNewQuota) { 
        $script:txtNewQuota.Enabled = $true
        $script:txtNewQuota.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)
        $script:txtNewQuota.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:txtNewQuota, "Available in FS-Manager Pro")
    }
    if ($script:rbHard) { 
        $script:rbHard.Enabled = $true
        $script:rbHard.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:rbHard, "Available in FS-Manager Pro")
    }
    if ($script:rbSoft) { 
        $script:rbSoft.Enabled = $true
        $script:rbSoft.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
        $script:toolTip.SetToolTip($script:rbSoft, "Available in FS-Manager Pro")
    }
}

