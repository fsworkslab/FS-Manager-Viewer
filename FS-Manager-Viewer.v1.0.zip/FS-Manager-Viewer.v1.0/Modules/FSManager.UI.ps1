<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.ps1
# Build: 20251126-142332

function Start-FSManagerUI {
    try {
        if (Get-Command Wire-UIHandlers -ErrorAction SilentlyContinue) {
            Wire-UIHandlers
        }
        if (Get-Command Build-UniqueAclIndex -ErrorAction SilentlyContinue) {
            Start-BackgroundIndexBuild
        }
        Start-PeriodicCacheValidation
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to wire UI handlers: $($_.Exception.Message)",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        throw
    }
}
function Start-BackgroundIndexBuild {
    if ($script:uniqueAclIndex -and $script:uniqueAclIndex.Count -gt 0) {
        return
    }
    if ($script:lblTreeHint) {
        $script:lblTreeHint.Text = "Checking index cache..."
    }
    $startTimer = New-Object System.Windows.Forms.Timer
    $startTimer.Interval = 2000  # Wait 2 seconds after UI loads
    $startTimer.Add_Tick({
        try {
            if ($startTimer) {
                $startTimer.Stop()
                $startTimer.Dispose()
            }
        } catch {
        }
        try {
            Build-UniqueAclIndex
            if ($script:form -and $script:lblTreeHint) {
                $script:form.Refresh()
                [System.Windows.Forms.Application]::DoEvents()
            }
            Write-FsInfo -Category "Index" -Message "Background index completed" -Details "Folders=$($script:uniqueAclIndex.Count)"
        } catch {
            Write-FsWarning -Category "Index" -Message "Background index failed" -Details $_.Exception.Message
            if ($script:lblTreeHint) {
                $script:lblTreeHint.Text = "Index will build when needed"
            }
        }
    })
    $startTimer.Start()
}
function Start-PeriodicCacheValidation {
    $script:cacheValidationTimer = New-Object System.Windows.Forms.Timer
    $script:cacheValidationTimer.Interval = 1800000  # 30 minutes in milliseconds
    $script:cacheValidationTimer.Add_Tick({
        try {
            if ($script:uniqueAclIndex -and $script:uniqueAclIndex.Count -gt 0 -and 
                (Get-Command Test-IndexCacheValid -ErrorAction SilentlyContinue) -and
                (Get-Command Build-UniqueAclIndex -ErrorAction SilentlyContinue)) {
                if (-not (Test-IndexCacheValid)) {
                    Write-FsInfo -Category "Cache" -Message "Periodic validation detected changes" -Details "Starting background rebuild"
                    if ($script:lblTreeHint) {
                        $script:lblTreeHint.Text = "Detected changes - rebuilding index..."
                    }
                    $script:uniqueAclIndex = $null
                    Build-UniqueAclIndex
                    Write-FsInfo -Category "Cache" -Message "Background rebuild completed" -Details "Folders=$($script:uniqueAclIndex.Count)"
                }
            }
        } catch {
            Write-FsWarning -Category "Cache" -Message "Periodic validation failed" -Details $_.Exception.Message
        }
    })
    $script:cacheValidationTimer.Start()
    Write-FsInfo -Category "Cache" -Message "Periodic validation started" -Details "Interval=30min"
}

