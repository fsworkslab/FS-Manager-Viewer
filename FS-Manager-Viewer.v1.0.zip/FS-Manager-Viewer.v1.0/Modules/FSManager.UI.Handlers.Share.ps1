<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Handlers.Share.ps1
# Build: 20251126-142332

function btnExportShare_Click {
    if (-not $script:currentShareName) {
        [System.Windows.Forms.MessageBox]::Show(
            "No share selected. Please select a share first.",
            "No Share Selected",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }
    if ($script:lvShare.Items.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "No share permissions to export.",
            "No Data",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }
    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Title    = "Save Share permissions to CSV"
    $sfd.Filter   = "CSV Files|*.csv"
    $safeName = $script:currentShareName.Replace(":","").Replace("\\","_").Replace("/","_")
    if ($safeName.Length -gt 40) { $safeName = $safeName.Substring(0,40) }
    $sfd.FileName = "ShareACL_" + $safeName + ".csv"
    $sfd.InitialDirectory = [Environment]::GetFolderPath("MyDocuments")
    if ($sfd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return
    }
    $outFile = $sfd.FileName
    try {
        $csvData = @()
        foreach ($item in $script:lvShare.Items) {
            $csvData += [PSCustomObject]@{
                ShareName     = $script:currentShareName
                Principal     = $item.SubItems[0].Text
                DisplayName   = $item.SubItems[1].Text
                Entity        = $item.SubItems[2].Text
                Access        = $item.SubItems[3].Text
                Type          = $item.SubItems[4].Text
                Scope         = $item.SubItems[5].Text
                ExportDate    = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                ExportedBy    = [Environment]::UserName
            }
        }
        $csvData | Export-Csv -Path $outFile -NoTypeInformation -Encoding UTF8
        Write-FsLog -Action "SHARE_Export" -Path $script:currentShareName -Details "File=$outFile; Records=$($csvData.Count)"
        [System.Windows.Forms.MessageBox]::Show(
            "Share permissions exported successfully!`r`n`r`nFile: $outFile`r`nRecords: $($csvData.Count)",
            "Export Complete",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    } catch {
        Write-FsError -Category "Export" -Message "Share export failed" -Details "Share=$($script:currentShareName); File=$outFile" -Exception $_.Exception
        [System.Windows.Forms.MessageBox]::Show(
            "Error exporting share permissions:`r`n$($_.Exception.Message)",
            "Export Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

