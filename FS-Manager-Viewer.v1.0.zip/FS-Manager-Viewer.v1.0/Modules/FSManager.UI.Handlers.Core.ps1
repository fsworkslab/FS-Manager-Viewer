<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Handlers.Core.ps1
# Build: 20251126-142332

function tree_AfterSelect {
    param($sender, $e)
    $node = $e.Node
    if (-not $node -or -not $node.Tag) {
        $script:currentPath = $null
        $script:currentShareName = $null
        $script:lblNtfsInfo.Text = ""
        return
    }
    $script:currentPath = $node.Tag.Path
    $script:currentShareName = $node.Tag.ShareName
    if ($script:currentPath) {
        Update-NtfsTab -Path $script:currentPath
        Update-QuotaTab -Path $script:currentPath
    }
    if ($script:currentShareName) {
        Update-ShareTab -ShareName $script:currentShareName
    }
}
function tree_BeforeExpand {
    param($sender, $e)
    $node = $e.Node
    if ($node.Nodes.Count -eq 1 -and $node.Nodes[0].Text -eq "...") {
        $node.Nodes.Clear()
        if ($node.Tag -and $node.Tag.Path) {
            Add-ChildNodes -ParentNode $node -Path $node.Tag.Path -ShareName $node.Tag.ShareName
        }
    }
}
# Show Pro upgrade message for Viewer version
function Show-ViewerProMessage {
    param([string]$Feature = "This feature")
    
    [System.Windows.Forms.MessageBox]::Show(
        "$Feature is available in FS-Manager Pro.`r`n`r`nThe Viewer version provides read-only access to permissions.`r`nUpgrade to FS-Manager Pro for full modification capabilities.`r`n`r`nPurchase: https://fsworks2.gumroad.com/l/fsmanager-pro`r`nSupport: fworks-support@proton.me",
        "Feature Available in Pro Version",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Wire-UIHandlers {
    # Viewer version - show Pro upgrade message on modification button clicks
    if ($script:btnAddAce)        { $script:btnAddAce.Add_Click({ Show-ViewerProMessage "Add NTFS Permission" }) }
    if ($script:btnRemoveAce)     { $script:btnRemoveAce.Add_Click({ Show-ViewerProMessage "Remove NTFS Permission" }) }
    if ($script:btnSaveTemplate)  { $script:btnSaveTemplate.Add_Click({ Show-ViewerProMessage "Save ACL Template" }) }
    if ($script:btnApplyTemplate) { $script:btnApplyTemplate.Add_Click({ Show-ViewerProMessage "Apply ACL Template" }) }
    if ($script:btnExportNtfs)    { $script:btnExportNtfs.Add_Click({ btnExportNtfs_Click }) }
    # Viewer version - show Pro upgrade message on share modification button clicks
    if ($script:btnRemoveShareAce) { $script:btnRemoveShareAce.Add_Click({ Show-ViewerProMessage "Remove Share Permission" }) }
    if ($script:btnAddShareAce)    { $script:btnAddShareAce.Add_Click({ Show-ViewerProMessage "Add Share Permission" }) }
    if ($script:btnExportShare)    { $script:btnExportShare.Add_Click({ btnExportShare_Click }) }
    # Viewer version - show Pro upgrade message on quota modification button clicks
    if ($script:btnSaveQuota)   { $script:btnSaveQuota.Add_Click({ Show-ViewerProMessage "Save Quota" }) }
    if ($script:btnRemoveQuota) { $script:btnRemoveQuota.Add_Click({ Show-ViewerProMessage "Remove Quota" }) }
    if ($script:btnCalcSize)    { $script:btnCalcSize.Add_Click({ btnCalcSize_Click }) }
    if ($script:tree) {
        $script:tree.Add_AfterSelect({ param($s,$e); tree_AfterSelect $s $e })
        $script:tree.Add_BeforeExpand({ param($s,$e); tree_BeforeExpand $s $e })
    }
    if ($script:btnGlobalHistory) {
        $script:btnGlobalHistory.Add_Click({ btnGlobalHistory_Click })
    }
    # Viewer version - always in read-only mode
    Update-ReadOnlyControls -ro $true
    if ($script:lvNtfs) {
        $script:lvNtfs.Add_DoubleClick({
            if ($script:lvNtfs.SelectedItems.Count -eq 0) { return }
            # Viewer version - show Pro message instead of edit dialog
            Show-ViewerProMessage "Edit NTFS Permission"
            return
            # Pro version code below (not executed in Viewer)
            $sel = $script:lvNtfs.SelectedItems[0]
            $ace = $sel.Tag
            if (-not $ace) { return }
            $principal = $ace.IdentityReference.ToString()
            $currentRights = $ace.FileSystemRights.ToString()
            $dlgEdit = New-Object System.Windows.Forms.Form
            $dlgEdit.Text = "Edit NTFS Permission"
            $dlgEdit.Size = New-Object System.Drawing.Size(400, 200)
            $dlgEdit.StartPosition = "CenterParent"
            $dlgEdit.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
            $dlgEdit.MaximizeBox = $false
            $dlgEdit.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
            $lblPrincipal = New-Object System.Windows.Forms.Label
            $lblPrincipal.Location = New-Object System.Drawing.Point(15, 15)
            $lblPrincipal.Size = New-Object System.Drawing.Size(360, 20)
            $lblPrincipal.Text = "Principal: $principal"
            $lblPrincipal.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
            $lblCurrent = New-Object System.Windows.Forms.Label
            $lblCurrent.Location = New-Object System.Drawing.Point(15, 40)
            $lblCurrent.Size = New-Object System.Drawing.Size(360, 20)
            $lblCurrent.Text = "Current: $currentRights"
            $lblCurrent.Font = New-Object System.Drawing.Font("Segoe UI", 8)
            $lblCurrent.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
            $lblNew = New-Object System.Windows.Forms.Label
            $lblNew.Location = New-Object System.Drawing.Point(15, 70)
            $lblNew.Size = New-Object System.Drawing.Size(100, 20)
            $lblNew.Text = "New rights:"
            $lblNew.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            $cbNewRights = New-Object System.Windows.Forms.ComboBox
            $cbNewRights.Location = New-Object System.Drawing.Point(120, 67)
            $cbNewRights.Size = New-Object System.Drawing.Size(250, 25)
            $cbNewRights.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
            $cbNewRights.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            [void]$cbNewRights.Items.AddRange(@("FullControl","Modify","ReadAndExecute","Read","Write"))
            $cbNewRights.SelectedIndex = 0
            $btnSave = New-Object System.Windows.Forms.Button
            $btnSave.Location = New-Object System.Drawing.Point(180, 115)
            $btnSave.Size = New-Object System.Drawing.Size(90, 30)
            $btnSave.Text = "Save"
            $btnSave.BackColor = [System.Drawing.Color]::FromArgb(40, 120, 80)
            $btnSave.ForeColor = [System.Drawing.Color]::White
            $btnSave.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnSave.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $btnCancel = New-Object System.Windows.Forms.Button
            $btnCancel.Location = New-Object System.Drawing.Point(280, 115)
            $btnCancel.Size = New-Object System.Drawing.Size(90, 30)
            $btnCancel.Text = "Cancel"
            $btnCancel.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
            $dlgEdit.Controls.AddRange(@($lblPrincipal, $lblCurrent, $lblNew, $cbNewRights, $btnSave, $btnCancel))
            $dlgEdit.AcceptButton = $btnSave
            $dlgEdit.CancelButton = $btnCancel
            if ($dlgEdit.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                $newRights = $cbNewRights.SelectedItem
                try {
                    $operationId = [guid]::NewGuid().ToString()
                    $acl = Get-AclSafe -Path $script:currentPath
                    $oldSddl = $acl.Sddl
                    $oldRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                        $ace.IdentityReference.ToString(), $ace.FileSystemRights,
                        $ace.InheritanceFlags, $ace.PropagationFlags, $ace.AccessControlType)
                    $acl.RemoveAccessRule($oldRule) | Out-Null
                    $fsRights = [System.Enum]::Parse([System.Security.AccessControl.FileSystemRights], $newRights)
                    $inherit = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
                    $propag = [System.Security.AccessControl.PropagationFlags]::None
                    $newRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                        $principal, $fsRights, $inherit, $propag, [System.Security.AccessControl.AccessControlType]::Allow)
                    $acl.AddAccessRule($newRule) | Out-Null
                    Set-AclSafe -Path $script:currentPath -AclObject $acl
                    $newSddl = (Get-AclSafe -Path $script:currentPath).Sddl
                    Write-FsLog -Action "NTFS_ModifyAce" -Path $script:currentPath -Details "Principal=$principal; OldRights=$currentRights; NewRights=$newRights" -OldSddl $oldSddl -NewSddl $newSddl -GroupId $operationId
                    Update-NtfsTab -Path $script:currentPath
                } catch {
                    [System.Windows.Forms.MessageBox]::Show("Error modifying permission:`r`n$($_.Exception.Message)", "Error",
                        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
                }
            }
        })
        if ($script:ctxNtfs -and $script:ctxNtfs.Items.Count -ge 5) {
            $script:ctxNtfs.Items[0].Add_Click({  # Edit Permission
                if ($script:lvNtfs.SelectedItems.Count -gt 0) {
                    $script:lvNtfs.GetType().GetMethod("OnDoubleClick", [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic).Invoke($script:lvNtfs, @([System.EventArgs]::Empty))
                }
            })
            $script:ctxNtfs.Items[1].Add_Click({  # Show ALL permissions
                if ($script:lvNtfs.SelectedItems.Count -eq 0) { return }
                $sel = $script:lvNtfs.SelectedItems[0]
                $principal = $sel.SubItems[0].Text
                if (Get-Command Show-UserPermissionsSearch -ErrorAction SilentlyContinue) {
                    Show-UserPermissionsSearch -SearchUser $principal
                } else {
                    $script:__prefilledSearchUser = $principal
                    $script:btnSearchUser.PerformClick()
                }
            })
            $script:ctxNtfs.Items[2].Add_Click({  # Remove permission
                if ($script:lvNtfs.SelectedItems.Count -eq 0) { return }
                # Viewer version - show Pro message
                Show-ViewerProMessage "Remove NTFS Permission"
            })
            $script:ctxNtfs.Items[4].Add_Click({  # Copy username
                if ($script:lvNtfs.SelectedItems.Count -eq 0) { return }
                $principal = $script:lvNtfs.SelectedItems[0].SubItems[0].Text
                [System.Windows.Forms.Clipboard]::SetText($principal)
                [System.Windows.Forms.MessageBox]::Show("Copied: $principal", "Copied",
                    [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
            })
        }
    }
    if ($script:lvShare) {
        $script:lvShare.Add_DoubleClick({
            if ($script:lvShare.SelectedItems.Count -eq 0) { return }
            # Viewer version - show Pro message instead of edit dialog
            Show-ViewerProMessage "Edit Share Permission"
            return
            # Pro version code below (not executed in Viewer)
            $sel = $script:lvShare.SelectedItems[0]
            $principal = $sel.SubItems[0].Text
            $currentAccess = $sel.SubItems[3].Text
            $dlgEdit = New-Object System.Windows.Forms.Form
            $dlgEdit.Text = "Edit Share Permission"
            $dlgEdit.Size = New-Object System.Drawing.Size(400, 200)
            $dlgEdit.StartPosition = "CenterParent"
            $dlgEdit.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
            $dlgEdit.MaximizeBox = $false
            $dlgEdit.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 250)
            $lblPrincipal = New-Object System.Windows.Forms.Label
            $lblPrincipal.Location = New-Object System.Drawing.Point(15, 15)
            $lblPrincipal.Size = New-Object System.Drawing.Size(360, 20)
            $lblPrincipal.Text = "Principal: $principal"
            $lblPrincipal.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
            $lblCurrent = New-Object System.Windows.Forms.Label
            $lblCurrent.Location = New-Object System.Drawing.Point(15, 40)
            $lblCurrent.Size = New-Object System.Drawing.Size(360, 20)
            $lblCurrent.Text = "Current: $currentAccess"
            $lblCurrent.Font = New-Object System.Drawing.Font("Segoe UI", 8)
            $lblCurrent.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
            $lblNew = New-Object System.Windows.Forms.Label
            $lblNew.Location = New-Object System.Drawing.Point(15, 70)
            $lblNew.Size = New-Object System.Drawing.Size(100, 20)
            $lblNew.Text = "New access:"
            $lblNew.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            $cbNewAccess = New-Object System.Windows.Forms.ComboBox
            $cbNewAccess.Location = New-Object System.Drawing.Point(120, 67)
            $cbNewAccess.Size = New-Object System.Drawing.Size(250, 25)
            $cbNewAccess.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
            $cbNewAccess.Font = New-Object System.Drawing.Font("Segoe UI", 9)
            [void]$cbNewAccess.Items.AddRange(@("Full","Change","Read"))
            $cbNewAccess.SelectedIndex = 0
            $btnSave = New-Object System.Windows.Forms.Button
            $btnSave.Location = New-Object System.Drawing.Point(180, 115)
            $btnSave.Size = New-Object System.Drawing.Size(90, 30)
            $btnSave.Text = "Save"
            $btnSave.BackColor = [System.Drawing.Color]::FromArgb(30, 80, 120)
            $btnSave.ForeColor = [System.Drawing.Color]::White
            $btnSave.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnSave.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $btnCancel = New-Object System.Windows.Forms.Button
            $btnCancel.Location = New-Object System.Drawing.Point(280, 115)
            $btnCancel.Size = New-Object System.Drawing.Size(90, 30)
            $btnCancel.Text = "Cancel"
            $btnCancel.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
            $dlgEdit.Controls.AddRange(@($lblPrincipal, $lblCurrent, $lblNew, $cbNewAccess, $btnSave, $btnCancel))
            $dlgEdit.AcceptButton = $btnSave
            $dlgEdit.CancelButton = $btnCancel
            if ($dlgEdit.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                $newAccess = $cbNewAccess.SelectedItem
                try {
                    $operationId = [guid]::NewGuid().ToString()
                    Revoke-SmbShareAccess -Name $script:currentShareName -AccountName $principal -Force -ErrorAction Stop
                    Grant-SmbShareAccess -Name $script:currentShareName -AccountName $principal -AccessRight $newAccess -Force -ErrorAction Stop
                    Write-FsLog -Action "SHARE_ModifyAce" -Path $script:currentShareName -Details "Principal=$principal; OldAccess=$currentAccess; NewAccess=$newAccess" -GroupId $operationId
                    Update-ShareTab -ShareName $script:currentShareName
                } catch {
                    [System.Windows.Forms.MessageBox]::Show("Error modifying share access:`r`n$($_.Exception.Message)", "Error",
                        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
                }
            }
        })
        if ($script:ctxShare -and $script:ctxShare.Items.Count -ge 5) {
            $script:ctxShare.Items[0].Add_Click({  # Change Access Level
                if ($script:lvShare.SelectedItems.Count -gt 0) {
                    $script:lvShare.GetType().GetMethod("OnDoubleClick", [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic).Invoke($script:lvShare, @([System.EventArgs]::Empty))
                }
            })
            $script:ctxShare.Items[1].Add_Click({  # Show ALL permissions
                if ($script:lvShare.SelectedItems.Count -eq 0) { return }
                $sel = $script:lvShare.SelectedItems[0]
                $principal = $sel.SubItems[0].Text
                if (Get-Command Show-UserPermissionsSearch -ErrorAction SilentlyContinue) {
                    Show-UserPermissionsSearch -SearchUser $principal
                } else {
                    $script:__prefilledSearchUser = $principal
                    $script:btnSearchUser.PerformClick()
                }
            })
            $script:ctxShare.Items[2].Add_Click({  # Remove permission
                if ($script:lvShare.SelectedItems.Count -eq 0) { return }
                # Viewer version - show Pro message
                Show-ViewerProMessage "Remove Share Permission"
            })
            $script:ctxShare.Items[4].Add_Click({  # Copy username
                if ($script:lvShare.SelectedItems.Count -eq 0) { return }
                $principal = $script:lvShare.SelectedItems[0].SubItems[0].Text
                [System.Windows.Forms.Clipboard]::SetText($principal)
                [System.Windows.Forms.MessageBox]::Show("Copied: $principal", "Copied",
                    [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
            })
        }
    }
    Populate-Tree
}

