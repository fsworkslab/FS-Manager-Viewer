<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.UI.Core.ps1
# Build: 20251126-142332

function Start-FSManagerUI_Core {
    if ($script:form) { return }
    if (-not ([AppDomain]::CurrentDomain.GetAssemblies() | ? { $_.GetName().Name -in @('System.Windows.Forms','System.Drawing') })) {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
    }
    try {
        $baseDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Definition }
        if (-not (Get-Command Get-ShareData -ErrorAction SilentlyContinue)) {
            $p = Join-Path $baseDir 'FSManager.Share.ps1'
            if (Test-Path $p) { . $p }
        }
        if (-not (Get-Command Resolve-PrincipalName -ErrorAction SilentlyContinue)) {
            $p = Join-Path $baseDir 'FSManager.Ad.ps1'
            if (Test-Path $p) { . $p }
        }
        if (-not (Get-Command Get-NtfsAclEntries -ErrorAction SilentlyContinue)) {
            $p = Join-Path $baseDir 'FSManager.Acl.ps1'
            if (Test-Path $p) { . $p }
        }
        if (-not (Get-Command Write-FsLog -ErrorAction SilentlyContinue)) {
            $p = Join-Path $baseDir 'FSManager.Logging.ps1'
            if (Test-Path $p) { . $p }
        }
        if (-not (Get-Command Get-QuotaInfo -ErrorAction SilentlyContinue)) {
            $p = Join-Path $baseDir 'FSManager.Fsrm.ps1'
            if (Test-Path $p) { . $p }
        }
    } catch {
    }
    $script:clrHeaderBg = [System.Drawing.Color]::FromArgb(45, 65, 95)
    $script:clrHeaderFg = [System.Drawing.Color]::White
    $script:clrSubtitle = [System.Drawing.Color]::FromArgb(180, 200, 220)
    $script:clrFormBg = [System.Drawing.Color]::FromArgb(240, 242, 245)
    $script:clrPanelBg = [System.Drawing.Color]::White
    $script:clrAccent = [System.Drawing.Color]::FromArgb(45, 65, 95)
    $script:clrSuccess = [System.Drawing.Color]::FromArgb(40, 120, 80)
    $script:clrDanger = [System.Drawing.Color]::FromArgb(180, 60, 60)
    $script:fontTitle = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
    $script:fontSubtitle = New-Object System.Drawing.Font("Segoe UI", 9)
    $script:fontNormal = New-Object System.Drawing.Font("Segoe UI", 9)
    $script:fontBold = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $script:form = New-Object System.Windows.Forms.Form
    $script:form.Text = "FS-Manager Viewer v1.0 (c) 2025 FSWorks Labs"
    $script:form.Size = New-Object System.Drawing.Size(1250, 750)
    $script:form.MinimumSize = New-Object System.Drawing.Size(1100, 600)
    $script:form.StartPosition = "CenterScreen"
    $script:form.BackColor = $script:clrFormBg
    $script:form.Font = $script:fontNormal
    $script:toolTip = New-Object System.Windows.Forms.ToolTip
    $script:toolTip.AutoPopDelay = 10000
    $script:toolTip.InitialDelay = 500
    $script:toolTip.ReshowDelay = 200
    $script:toolTip.ShowAlways = $true
    $script:toolTip.Active = $true
    $pnlHeader = New-Object System.Windows.Forms.Panel
    $pnlHeader.Dock = [System.Windows.Forms.DockStyle]::Top
    $pnlHeader.Height = 70
    $pnlHeader.BackColor = $script:clrHeaderBg
    $lblAppTitle = New-Object System.Windows.Forms.Label
    $lblAppTitle.Location = New-Object System.Drawing.Point(20, 8)
    $lblAppTitle.Size = New-Object System.Drawing.Size(500, 35)
    $lblAppTitle.Text = "FS-Manager Viewer v1.0"
    $lblAppTitle.Font = $script:fontTitle
    $lblAppTitle.ForeColor = $script:clrHeaderFg
    $pnlHeader.Controls.Add($lblAppTitle)
    $lblAppCopyright = New-Object System.Windows.Forms.Label
    $lblAppCopyright.Location = New-Object System.Drawing.Point(20, 45)
    $lblAppCopyright.Size = New-Object System.Drawing.Size(600, 20)
    $lblAppCopyright.Text = "Read-Only Version - Upgrade to FS-Manager Pro for full functionality"
    $lblAppCopyright.Font = $script:fontSubtitle
    $lblAppCopyright.ForeColor = $script:clrSubtitle
    $pnlHeader.Controls.Add($lblAppCopyright)
    $script:btnSearchUser = New-Object System.Windows.Forms.Button
    $script:btnSearchUser.Size = New-Object System.Drawing.Size(160, 32)
    $script:btnSearchUser.Text = "Search User/Group"
    $script:btnSearchUser.Font = $script:fontNormal
    $script:btnSearchUser.BackColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
    $script:btnSearchUser.ForeColor = [System.Drawing.Color]::White
    $script:btnSearchUser.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnSearchUser.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:toolTip.SetToolTip($script:btnSearchUser, "Search for all permissions assigned to a specific user or group across all shares")
    $pnlHeader.Controls.Add($script:btnSearchUser)
    $script:btnGlobalHistory = New-Object System.Windows.Forms.Button
    $script:btnGlobalHistory.Size = New-Object System.Drawing.Size(140, 32)
    $script:btnGlobalHistory.Text = "Change History"
    $script:btnGlobalHistory.Font = $script:fontNormal
    $script:btnGlobalHistory.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnGlobalHistory.FlatAppearance.BorderColor = [System.Drawing.Color]::White
    $script:btnGlobalHistory.ForeColor = [System.Drawing.Color]::White
    $script:btnGlobalHistory.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:toolTip.SetToolTip($script:btnGlobalHistory, "View all permission changes (rollback available in Pro version)")
    $pnlHeader.Controls.Add($script:btnGlobalHistory)
    $script:btnCacheManage = New-Object System.Windows.Forms.Button
    $script:btnCacheManage.Size = New-Object System.Drawing.Size(120, 32)
    $script:btnCacheManage.Text = "Cache Manager"
    $script:btnCacheManage.Font = $script:fontNormal
    $script:btnCacheManage.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnCacheManage.FlatAppearance.BorderColor = [System.Drawing.Color]::White
    $script:btnCacheManage.ForeColor = [System.Drawing.Color]::White
    $script:btnCacheManage.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:toolTip.SetToolTip($script:btnCacheManage, "Index cache management and performance status")
    $pnlHeader.Controls.Add($script:btnCacheManage)
    $script:resizeLayout = {
        $formWidth = $script:form.ClientSize.Width
        $formHeight = $script:form.ClientSize.Height
        if ($script:btnSearchUser) {
            $script:btnSearchUser.Location = New-Object System.Drawing.Point(($formWidth - 190), 20)
        }
        if ($script:btnGlobalHistory) {
            $script:btnGlobalHistory.Location = New-Object System.Drawing.Point(($formWidth - 345), 20)
        }
        if ($script:btnCacheManage) {
            $script:btnCacheManage.Location = New-Object System.Drawing.Point(($formWidth - 480), 20)
        }
        $leftWidth = [Math]::Max(400, [Math]::Min(600, [int]($formWidth * 0.38)))
        $leftHeight = $formHeight - 100
        if ($script:pnlLeft) {
            $script:pnlLeft.Size = New-Object System.Drawing.Size($leftWidth, $leftHeight)
        }
        $rightX = $leftWidth + 30
        $rightWidth = $formWidth - $rightX - 15
        if ($script:panel) {
            $script:panel.Location = New-Object System.Drawing.Point($rightX, 85)
            $script:panel.Size = New-Object System.Drawing.Size($rightWidth, $leftHeight)
        }
        if ($script:tabs -and $script:tabNtfs) {
            $tabHeight = $script:tabs.ClientSize.Height - 30  # Account for tab headers
            $tabWidth = $script:tabs.ClientSize.Width - 10
            if ($script:pnlNtfsActions -and $script:lvNtfs -and $script:lblNtfsInfo) {
                $actionPanelY = $tabHeight - 160  # 85 for panel + 60 for info + 15 margin
                $script:pnlNtfsActions.Location = New-Object System.Drawing.Point(15, $actionPanelY)
                $script:pnlNtfsActions.Size = New-Object System.Drawing.Size(($tabWidth - 30), 85)
                try {
                    if ($script:btnExportNtfs -and $script:pnlNtfsActions) {
                        $panelWidth = $script:pnlNtfsActions.Width
                        $exportX = $panelWidth - 140  # 130 button width + 10 margin
                        if ($exportX -lt 550) { $exportX = 550 }  # Minimum position to avoid overlap
                        $script:btnExportNtfs.Location = New-Object System.Drawing.Point($exportX, 8)
                    }
                } catch {
                }
                $script:lblNtfsInfo.Location = New-Object System.Drawing.Point(15, ($actionPanelY + 90))
                $script:lblNtfsInfo.Size = New-Object System.Drawing.Size(($tabWidth - 30), 60)
                $lvHeight = $actionPanelY - 60  # 55 top + 5 margin
                $script:lvNtfs.Size = New-Object System.Drawing.Size(($tabWidth - 30), $lvHeight)
            }
            if ($script:pnlShareActions -and $script:lvShare -and $script:lblShareInfo) {
                $actionPanelY = $tabHeight - 145  # 50 for panel + 80 for info + 15 margin
                $script:pnlShareActions.Location = New-Object System.Drawing.Point(15, $actionPanelY)
                $script:pnlShareActions.Size = New-Object System.Drawing.Size(($tabWidth - 30), 50)
                $script:lblShareInfo.Location = New-Object System.Drawing.Point(15, ($actionPanelY + 55))
                $script:lblShareInfo.Size = New-Object System.Drawing.Size(($tabWidth - 30), 80)
                $lvHeight = $actionPanelY - 60
                $script:lvShare.Size = New-Object System.Drawing.Size(($tabWidth - 30), $lvHeight)
            }
        }
    }
    $script:form.Controls.Add($pnlHeader)
    $script:pnlLeft = New-Object System.Windows.Forms.Panel
    $script:pnlLeft.Location = New-Object System.Drawing.Point(15, 85)
    $script:pnlLeft.Size = New-Object System.Drawing.Size(450, 610)
    $script:pnlLeft.BackColor = $script:clrPanelBg
    $script:pnlLeft.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:lblTreeInfo = New-Object System.Windows.Forms.Label
    $script:lblTreeInfo.Location = New-Object System.Drawing.Point(10, 10)
    $script:lblTreeInfo.Size = New-Object System.Drawing.Size(430, 20)
    $script:lblTreeInfo.Text = "Shares and Folders"
    $script:lblTreeInfo.Font = $script:fontBold
    $script:lblTreeInfo.ForeColor = $script:clrAccent
    $script:lblTreeInfo.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $script:pnlLeft.Controls.Add($script:lblTreeInfo)
    $script:lblTreeHint = New-Object System.Windows.Forms.Label
    $script:lblTreeHint.Location = New-Object System.Drawing.Point(10, 30)
    $script:lblTreeHint.Size = New-Object System.Drawing.Size(430, 20)
    $script:lblTreeHint.Text = "Red = unique ACL | Blue = shared folder"
    $script:lblTreeHint.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $script:lblTreeHint.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
    $script:lblTreeHint.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $script:lblTreeHint.AutoSize = $true  # Let it size to text content
    $script:lblTreeHint.Cursor = [System.Windows.Forms.Cursors]::Help
    $script:lblTreeHint.Add_MouseEnter({
        if ($script:isIndexBuilding -and $script:totalFoldersProcessed -gt 0) {
            $elapsed = if ($script:indexingStartTime) { (Get-Date) - $script:indexingStartTime } else { New-TimeSpan }
            $rate = if ($elapsed.TotalSeconds -gt 0) { [math]::Round($script:totalFoldersProcessed / $elapsed.TotalSeconds, 1) } else { 0 }
            $tooltipText = "INDEX BUILDING IN PROGRESS`r`n"
            $tooltipText += "================================`r`n"
            $tooltipText += "Folders processed: $($script:totalFoldersProcessed)`r`n"
            $tooltipText += "Processing rate: $rate folders/sec`r`n"
            $tooltipText += "Elapsed time: $([math]::Round($elapsed.TotalMinutes, 1)) minutes`r`n"
            if ($script:uniqueAclIndex -and $script:uniqueAclIndex.Count -gt 0) {
                $tooltipText += "Unique ACL folders found: $($script:uniqueAclIndex.Count)`r`n"
            }
            $tooltipText += "`r`nHover again for updated progress..."
            $script:toolTip.SetToolTip($script:lblTreeHint, $tooltipText)
        } elseif ($script:uniqueAclIndex -and $script:uniqueAclIndex.Count -gt 0) {
            $tooltipText = "INDEX STATUS`r`n"
            $tooltipText += "=============`r`n"
            $tooltipText += "Index ready: $($script:uniqueAclIndex.Count) folders with unique ACL`r`n"
            $tooltipText += "Status: Ready for search operations"
            $script:toolTip.SetToolTip($script:lblTreeHint, $tooltipText)
        } else {
            $script:toolTip.SetToolTip($script:lblTreeHint, "Index not yet built - will build automatically when needed")
        }
    })
    $script:lblTreeHint.Add_MouseLeave({
        $script:toolTip.SetToolTip($script:lblTreeHint, "Red = unique ACL | Blue = shared folder")
    })
    $script:pnlLeft.Controls.Add($script:lblTreeHint)
    $script:txtTreeFilter = New-Object System.Windows.Forms.TextBox
    $script:txtTreeFilter.Location = New-Object System.Drawing.Point(10, 50)
    $script:txtTreeFilter.Size = New-Object System.Drawing.Size(350, 24)
    $script:txtTreeFilter.Font = $script:fontNormal
    $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Gray
    $script:txtTreeFilter.Text = "Filter shares/folders..."
    $script:txtTreeFilter.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $script:toolTip.SetToolTip($script:txtTreeFilter, "Type to filter shares and folders by name (partial match). Press Enter to apply.")
    $script:pnlLeft.Controls.Add($script:txtTreeFilter)
    $script:btnTreeFilterClear = New-Object System.Windows.Forms.Button
    $script:btnTreeFilterClear.Location = New-Object System.Drawing.Point(335, 51)
    $script:btnTreeFilterClear.Size = New-Object System.Drawing.Size(22, 22)
    $script:btnTreeFilterClear.Text = [char]0x2715  # Unicode X
    $script:btnTreeFilterClear.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnTreeFilterClear.FlatAppearance.BorderSize = 0
    $script:btnTreeFilterClear.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $script:btnTreeFilterClear.ForeColor = [System.Drawing.Color]::FromArgb(180, 80, 80)
    $script:btnTreeFilterClear.BackColor = [System.Drawing.Color]::White
    $script:btnTreeFilterClear.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:btnTreeFilterClear.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $script:btnTreeFilterClear.Visible = $false
    $script:toolTip.SetToolTip($script:btnTreeFilterClear, "Clear filter")
    $script:pnlLeft.Controls.Add($script:btnTreeFilterClear)
    $script:btnTreeFilterClear.BringToFront()
    $script:btnTreeFilter = New-Object System.Windows.Forms.Button
    $script:btnTreeFilter.Location = New-Object System.Drawing.Point(365, 49)
    $script:btnTreeFilter.Size = New-Object System.Drawing.Size(70, 26)
    $script:btnTreeFilter.Text = "Filter"
    $script:btnTreeFilter.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnTreeFilter.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(180, 180, 180)
    $script:btnTreeFilter.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $script:btnTreeFilter.ForeColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
    $script:btnTreeFilter.BackColor = [System.Drawing.Color]::FromArgb(250, 250, 250)
    $script:btnTreeFilter.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:btnTreeFilter.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $script:toolTip.SetToolTip($script:btnTreeFilter, "Apply filter to tree")
    $script:pnlLeft.Controls.Add($script:btnTreeFilter)
    $script:pnlLegend = New-Object System.Windows.Forms.Panel
    $script:pnlLegend.Location = New-Object System.Drawing.Point(10, 75)
    $script:pnlLegend.Size = New-Object System.Drawing.Size(428, 22)
    $script:pnlLegend.BackColor = [System.Drawing.Color]::FromArgb(250, 250, 255)
    $script:pnlLegend.Visible = $false
    $script:pnlLegend.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $lblLegRed = New-Object System.Windows.Forms.Label
    $lblLegRed.Location = New-Object System.Drawing.Point(5, 3)
    $lblLegRed.Size = New-Object System.Drawing.Size(100, 16)
    $lblLegRed.Text = [char]9632 + " NTFS"
    $lblLegRed.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $lblLegRed.ForeColor = [System.Drawing.Color]::DarkRed
    $script:pnlLegend.Controls.Add($lblLegRed)
    $lblLegBlue = New-Object System.Windows.Forms.Label
    $lblLegBlue.Location = New-Object System.Drawing.Point(100, 3)
    $lblLegBlue.Size = New-Object System.Drawing.Size(100, 16)
    $lblLegBlue.Text = [char]9632 + " Share"
    $lblLegBlue.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $lblLegBlue.ForeColor = [System.Drawing.Color]::DarkBlue
    $script:pnlLegend.Controls.Add($lblLegBlue)
    $lblLegPurple = New-Object System.Windows.Forms.Label
    $lblLegPurple.Location = New-Object System.Drawing.Point(195, 3)
    $lblLegPurple.Size = New-Object System.Drawing.Size(130, 16)
    $lblLegPurple.Text = [char]9632 + " Both (NTFS+Share)"
    $lblLegPurple.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $lblLegPurple.ForeColor = [System.Drawing.Color]::Purple
    $script:pnlLegend.Controls.Add($lblLegPurple)
    $script:pnlLeft.Controls.Add($script:pnlLegend)
    $script:tree = New-Object System.Windows.Forms.TreeView
    $script:tree.Location = New-Object System.Drawing.Point(10, 80)
    $script:tree.Size = New-Object System.Drawing.Size(428, 435)
    $script:tree.HideSelection = $false
    $script:tree.Font = $script:fontNormal
    $script:tree.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:tree.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right -bor [System.Windows.Forms.AnchorStyles]::Bottom
    $script:pnlLeft.Controls.Add($script:tree)
    $script:pnlOptions = New-Object System.Windows.Forms.Panel
    $script:pnlOptions.Location = New-Object System.Drawing.Point(10, 520)
    $script:pnlOptions.Size = New-Object System.Drawing.Size(428, 80)
    $script:pnlOptions.BackColor = [System.Drawing.Color]::FromArgb(248, 249, 252)
    $script:pnlOptions.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:pnlOptions.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right -bor [System.Windows.Forms.AnchorStyles]::Bottom
    # Get Pro link label (replaces Viewer Mode label)
    $script:lnkGetPro = New-Object System.Windows.Forms.LinkLabel
    $script:lnkGetPro.Location = New-Object System.Drawing.Point(10, 8)
    $script:lnkGetPro.Size = New-Object System.Drawing.Size(180, 22)
    $script:lnkGetPro.Text = "Upgrade to FS-Manager Pro"
    $script:lnkGetPro.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $script:lnkGetPro.LinkColor = [System.Drawing.Color]::FromArgb(40, 167, 69)
    $script:lnkGetPro.ActiveLinkColor = [System.Drawing.Color]::FromArgb(30, 130, 50)
    $script:lnkGetPro.VisitedLinkColor = [System.Drawing.Color]::FromArgb(40, 167, 69)
    $script:lnkGetPro.LinkBehavior = [System.Windows.Forms.LinkBehavior]::HoverUnderline
    $script:toolTip.SetToolTip($script:lnkGetPro, "Click to purchase FS-Manager Pro for full modification capabilities")
    $script:lnkGetPro.Add_LinkClicked({
        Start-Process "https://fsworks2.gumroad.com/l/fsmanager-pro"
    })
    $script:pnlOptions.Controls.Add($script:lnkGetPro)
    $script:chkShowSharesOnly = New-Object System.Windows.Forms.CheckBox
    $script:chkShowSharesOnly.Location = New-Object System.Drawing.Point(210, 8)
    $script:chkShowSharesOnly.Size = New-Object System.Drawing.Size(210, 22)
    $script:chkShowSharesOnly.Text = "Show only Shares"
    $script:chkShowSharesOnly.Checked = $false
    $script:chkShowSharesOnly.Font = $script:fontNormal
    $script:toolTip.SetToolTip($script:chkShowSharesOnly, "Show only shared folders and their subfolders (hides non-shared drive content)")
    $script:pnlOptions.Controls.Add($script:chkShowSharesOnly)
    $script:btnRefresh = New-Object System.Windows.Forms.Button
    $script:btnRefresh.Location = New-Object System.Drawing.Point(10, 40)
    $script:btnRefresh.Size = New-Object System.Drawing.Size(120, 30)
    $script:btnRefresh.Text = "Refresh"
    $script:btnRefresh.Font = $script:fontNormal
    $script:btnRefresh.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnRefresh.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:toolTip.SetToolTip($script:btnRefresh, "Reload the share and folder tree from the server")
    $script:pnlOptions.Controls.Add($script:btnRefresh)
    $script:btnExitSearch = New-Object System.Windows.Forms.Button
    $script:btnExitSearch.Location = New-Object System.Drawing.Point(170, 40)
    $script:btnExitSearch.Size = New-Object System.Drawing.Size(140, 30)
    $script:btnExitSearch.Text = "Exit Search Mode"
    $script:btnExitSearch.Font = $script:fontNormal
    $script:btnExitSearch.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnExitSearch.BackColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
    $script:btnExitSearch.ForeColor = [System.Drawing.Color]::White
    $script:btnExitSearch.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:btnExitSearch.Visible = $false
    $script:toolTip.SetToolTip($script:btnExitSearch, "Return to normal browse mode showing all shares and folders")
    $script:pnlOptions.Controls.Add($script:btnExitSearch)
    $script:treeMode = "Browse"  # "Browse" or "Search"
    $script:searchPrincipal = $null
    $script:searchPaths = @()
    $script:pnlLeft.Controls.Add($script:pnlOptions)
    $script:form.Controls.Add($script:pnlLeft)
    $script:panel = New-Object System.Windows.Forms.Panel
    $script:panel.Location = New-Object System.Drawing.Point(480, 85)
    $script:panel.Size = New-Object System.Drawing.Size(745, 610)
    $script:panel.BackColor = $script:clrPanelBg
    $script:panel.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:form.Controls.Add($script:panel)
    $script:tabs = New-Object System.Windows.Forms.TabControl
    $script:tabs.Dock = [System.Windows.Forms.DockStyle]::Fill
    $script:tabs.Font = $script:fontNormal
    $script:panel.Controls.Add($script:tabs)
    $script:tabNtfs = New-Object System.Windows.Forms.TabPage
    $script:tabNtfs.Text = "  NTFS Permissions  "
    $script:tabNtfs.BackColor = $script:clrPanelBg
    $script:tabNtfs.Padding = New-Object System.Windows.Forms.Padding(10)
    $script:lblNtfsPath = New-Object System.Windows.Forms.Label
    $script:lblNtfsPath.Location = New-Object System.Drawing.Point(15, 15)
    $script:lblNtfsPath.Size = New-Object System.Drawing.Size(700, 35)
    $script:lblNtfsPath.Text = "Selected folder:"
    $script:lblNtfsPath.Font = $script:fontNormal
    $script:lblNtfsPath.AutoSize = $false
    $script:lvNtfs = New-Object System.Windows.Forms.ListView
    $script:lvNtfs.Location = New-Object System.Drawing.Point(15, 55)
    $script:lvNtfs.Size = New-Object System.Drawing.Size(700, 340)
    $script:lvNtfs.View = [System.Windows.Forms.View]::Details
    $script:lvNtfs.FullRowSelect = $true
    $script:lvNtfs.GridLines = $true
    $script:lvNtfs.Font = $script:fontNormal
    $script:lvNtfs.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:lvNtfs.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $null = $script:lvNtfs.Columns.Add("Principal", 170)
    $null = $script:lvNtfs.Columns.Add("Display Name", 150)
    $null = $script:lvNtfs.Columns.Add("Entity", 55)
    $null = $script:lvNtfs.Columns.Add("Rights", 170)
    $null = $script:lvNtfs.Columns.Add("Type", 55)
    $null = $script:lvNtfs.Columns.Add("Inherited", 65)
    $script:pnlNtfsActions = New-Object System.Windows.Forms.Panel
    $script:pnlNtfsActions.Location = New-Object System.Drawing.Point(15, 400)
    $script:pnlNtfsActions.Size = New-Object System.Drawing.Size(700, 85)
    $script:pnlNtfsActions.BackColor = [System.Drawing.Color]::FromArgb(248, 249, 252)
    $script:pnlNtfsActions.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:lblRights = New-Object System.Windows.Forms.Label
    $script:lblRights.Location = New-Object System.Drawing.Point(10, 12)
    $script:lblRights.Size = New-Object System.Drawing.Size(80, 20)
    $script:lblRights.Text = "Rights:"
    $script:lblRights.Font = $script:fontNormal
    $script:cbNtfsRights = New-Object System.Windows.Forms.ComboBox
    $script:cbNtfsRights.Location = New-Object System.Drawing.Point(95, 10)
    $script:cbNtfsRights.Size = New-Object System.Drawing.Size(140, 25)
    $script:cbNtfsRights.Font = $script:fontNormal
    $script:cbNtfsRights.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    [void]$script:cbNtfsRights.Items.AddRange(@("FullControl","Modify","ReadAndExecute","Read","Write"))
    $script:cbNtfsRights.SelectedIndex = 0
    $script:toolTip.SetToolTip($script:cbNtfsRights, "FullControl=All rights | Modify=Edit/Delete | ReadAndExecute=Open/Run | Read=View only | Write=Create files")
    $script:btnAddAce = New-Object System.Windows.Forms.Button
    $script:btnAddAce.Location = New-Object System.Drawing.Point(250, 8)
    $script:btnAddAce.Size = New-Object System.Drawing.Size(140, 28)
    $script:btnAddAce.Text = "Add User/Group"
    $script:btnAddAce.Font = $script:fontNormal
    $script:btnAddAce.BackColor = $script:clrSuccess
    $script:btnAddAce.ForeColor = [System.Drawing.Color]::White
    $script:btnAddAce.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnAddAce.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $script:btnRemoveAce = New-Object System.Windows.Forms.Button
    $script:btnRemoveAce.Location = New-Object System.Drawing.Point(400, 8)
    $script:btnRemoveAce.Size = New-Object System.Drawing.Size(140, 28)
    $script:btnRemoveAce.Text = "Remove Selected"
    $script:btnRemoveAce.Font = $script:fontNormal
    $script:btnRemoveAce.ForeColor = $script:clrDanger
    $script:btnRemoveAce.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnRemoveAce.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $script:btnExportNtfs = New-Object System.Windows.Forms.Button
    $script:btnExportNtfs.Location = New-Object System.Drawing.Point(550, 8)
    $script:btnExportNtfs.Size = New-Object System.Drawing.Size(130, 28)
    $script:btnExportNtfs.Text = "Export CSV"
    $script:btnExportNtfs.Font = $script:fontNormal
    $script:btnExportNtfs.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnExportNtfs.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:toolTip.SetToolTip($script:btnExportNtfs, "Export all NTFS permissions for this folder to a CSV file")
    $script:btnSaveTemplate = New-Object System.Windows.Forms.Button
    $script:btnSaveTemplate.Location = New-Object System.Drawing.Point(10, 45)
    $script:btnSaveTemplate.Size = New-Object System.Drawing.Size(160, 28)
    $script:btnSaveTemplate.Text = "Save ACL as Template"
    $script:btnSaveTemplate.Font = $script:fontNormal
    $script:btnSaveTemplate.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnSaveTemplate.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $script:btnApplyTemplate = New-Object System.Windows.Forms.Button
    $script:btnApplyTemplate.Location = New-Object System.Drawing.Point(180, 45)
    $script:btnApplyTemplate.Size = New-Object System.Drawing.Size(160, 28)
    $script:btnApplyTemplate.Text = "Apply Template"
    $script:btnApplyTemplate.Font = $script:fontNormal
    $script:btnApplyTemplate.BackColor = $script:clrAccent
    $script:btnApplyTemplate.ForeColor = [System.Drawing.Color]::White
    $script:btnApplyTemplate.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnApplyTemplate.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $script:lblTemplateStatus = New-Object System.Windows.Forms.Label
    $script:lblTemplateStatus.Location = New-Object System.Drawing.Point(350, 48)
    $script:lblTemplateStatus.Size = New-Object System.Drawing.Size(360, 22)
    $script:lblTemplateStatus.Text = "Template: (none saved)"
    $script:lblTemplateStatus.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $script:lblTemplateStatus.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
    $script:pnlNtfsActions.Controls.AddRange(@($script:lblRights, $script:cbNtfsRights, $script:btnAddAce, $script:btnRemoveAce, $script:btnExportNtfs, $script:btnSaveTemplate, $script:btnApplyTemplate, $script:lblTemplateStatus))
    $script:ctxNtfs = New-Object System.Windows.Forms.ContextMenuStrip
    $script:ctxNtfs.Font = $script:fontNormal
    $mnuNtfsEdit = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuNtfsEdit.Text = "Edit Permission..."
    $mnuNtfsEdit.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $script:ctxNtfs.Items.Add($mnuNtfsEdit) | Out-Null
    $mnuNtfsSearch = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuNtfsSearch.Text = "Show ALL permissions for this user..."
    $script:ctxNtfs.Items.Add($mnuNtfsSearch) | Out-Null
    $mnuNtfsRemove = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuNtfsRemove.Text = "Remove this permission"
    $mnuNtfsRemove.ForeColor = [System.Drawing.Color]::DarkRed
    $script:ctxNtfs.Items.Add($mnuNtfsRemove) | Out-Null
    $script:ctxNtfs.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
    $mnuNtfsCopyUser = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuNtfsCopyUser.Text = "Copy username to clipboard"
    $script:ctxNtfs.Items.Add($mnuNtfsCopyUser) | Out-Null
    $script:lvNtfs.ContextMenuStrip = $script:ctxNtfs
    $script:lblNtfsInfo = New-Object System.Windows.Forms.Label
    $script:lblNtfsInfo.Location = New-Object System.Drawing.Point(15, 495)
    $script:lblNtfsInfo.Size = New-Object System.Drawing.Size(700, 60)
    $script:lblNtfsInfo.Text = ""
    $script:lblNtfsInfo.Font = $script:fontNormal
    $script:lblNtfsInfo.ForeColor = [System.Drawing.Color]::FromArgb(80, 80, 80)
    $script:lblNtfsInfo.AutoSize = $false
    $script:tabNtfs.Controls.AddRange(@($script:lblNtfsPath, $script:lvNtfs, $script:pnlNtfsActions, $script:lblNtfsInfo))
    $script:tabShare = New-Object System.Windows.Forms.TabPage
    $script:tabShare.Text = "  Share Permissions  "
    $script:tabShare.BackColor = $script:clrPanelBg
    $script:tabShare.Padding = New-Object System.Windows.Forms.Padding(10)
    $script:lblShareName = New-Object System.Windows.Forms.Label
    $script:lblShareName.Location = New-Object System.Drawing.Point(15, 15)
    $script:lblShareName.Size = New-Object System.Drawing.Size(700, 35)
    $script:lblShareName.Text = "Selected share:"
    $script:lblShareName.Font = $script:fontNormal
    $script:lblShareName.AutoSize = $false
    $script:lvShare = New-Object System.Windows.Forms.ListView
    $script:lvShare.Location = New-Object System.Drawing.Point(15, 55)
    $script:lvShare.Size = New-Object System.Drawing.Size(700, 340)
    $script:lvShare.View = [System.Windows.Forms.View]::Details
    $script:lvShare.FullRowSelect = $true
    $script:lvShare.GridLines = $true
    $script:lvShare.Font = $script:fontNormal
    $script:lvShare.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:lvShare.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $null = $script:lvShare.Columns.Add("Principal", 170)
    $null = $script:lvShare.Columns.Add("Display Name", 150)
    $null = $script:lvShare.Columns.Add("Entity", 55)
    $null = $script:lvShare.Columns.Add("Access", 90)
    $null = $script:lvShare.Columns.Add("Type", 55)
    $null = $script:lvShare.Columns.Add("Scope", 140)
    $script:ctxShare = New-Object System.Windows.Forms.ContextMenuStrip
    $script:ctxShare.Font = $script:fontNormal
    $mnuShareEdit = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuShareEdit.Text = "Change Access Level..."
    $mnuShareEdit.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $script:ctxShare.Items.Add($mnuShareEdit) | Out-Null
    $mnuShareSearch = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuShareSearch.Text = "Show ALL permissions for this user..."
    $script:ctxShare.Items.Add($mnuShareSearch) | Out-Null
    $mnuShareRemove = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuShareRemove.Text = "Remove this permission"
    $mnuShareRemove.ForeColor = [System.Drawing.Color]::DarkRed
    $script:ctxShare.Items.Add($mnuShareRemove) | Out-Null
    $script:ctxShare.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
    $mnuShareCopyUser = New-Object System.Windows.Forms.ToolStripMenuItem
    $mnuShareCopyUser.Text = "Copy username to clipboard"
    $script:ctxShare.Items.Add($mnuShareCopyUser) | Out-Null
    $script:lvShare.ContextMenuStrip = $script:ctxShare
    $script:pnlShareActions = New-Object System.Windows.Forms.Panel
    $script:pnlShareActions.Location = New-Object System.Drawing.Point(15, 400)
    $script:pnlShareActions.Size = New-Object System.Drawing.Size(700, 50)
    $script:pnlShareActions.BackColor = [System.Drawing.Color]::FromArgb(248, 249, 252)
    $script:pnlShareActions.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:btnAddShareAce = New-Object System.Windows.Forms.Button
    $script:btnAddShareAce.Location = New-Object System.Drawing.Point(10, 10)
    $script:btnAddShareAce.Size = New-Object System.Drawing.Size(180, 28)
    $script:btnAddShareAce.Text = "Add Share Permission"
    $script:btnAddShareAce.Font = $script:fontNormal
    $script:btnAddShareAce.BackColor = [System.Drawing.Color]::FromArgb(30, 100, 140)
    $script:btnAddShareAce.ForeColor = [System.Drawing.Color]::White
    $script:btnAddShareAce.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnAddShareAce.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $script:btnRemoveShareAce = New-Object System.Windows.Forms.Button
    $script:btnRemoveShareAce.Location = New-Object System.Drawing.Point(200, 10)
    $script:btnRemoveShareAce.Size = New-Object System.Drawing.Size(140, 28)
    $script:btnRemoveShareAce.Text = "Remove Selected"
    $script:btnRemoveShareAce.Font = $script:fontNormal
    $script:btnRemoveShareAce.ForeColor = $script:clrDanger
    $script:btnRemoveShareAce.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnRemoveShareAce.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $script:btnExportShare = New-Object System.Windows.Forms.Button
    $script:btnExportShare.Location = New-Object System.Drawing.Point(350, 10)
    $script:btnExportShare.Size = New-Object System.Drawing.Size(120, 28)
    $script:btnExportShare.Text = "Export to CSV"
    $script:btnExportShare.Font = $script:fontNormal
    $script:btnExportShare.BackColor = [System.Drawing.Color]::FromArgb(60, 140, 60)
    $script:btnExportShare.ForeColor = [System.Drawing.Color]::White
    $script:btnExportShare.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnExportShare.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:toolTip.SetToolTip($script:btnExportShare, "Export share permissions to CSV file")
    $script:pnlShareActions.Controls.AddRange(@($script:btnAddShareAce, $script:btnRemoveShareAce, $script:btnExportShare))
    $script:lblShareInfo = New-Object System.Windows.Forms.Label
    $script:lblShareInfo.Location = New-Object System.Drawing.Point(15, 460)
    $script:lblShareInfo.Size = New-Object System.Drawing.Size(700, 80)
    $script:lblShareInfo.Text = "Note: Share permissions apply to network access. NTFS permissions control folder-level access for both local and network users."
    $script:lblShareInfo.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $script:lblShareInfo.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
    $script:lblShareInfo.AutoSize = $false
    $script:tabShare.Controls.AddRange(@($script:lblShareName, $script:lvShare, $script:pnlShareActions, $script:lblShareInfo))
    $script:tabQuota = New-Object System.Windows.Forms.TabPage
    $script:tabQuota.Text = "  Quota (FSRM)  "
    $script:tabQuota.BackColor = $script:clrPanelBg
    $script:tabQuota.Padding = New-Object System.Windows.Forms.Padding(10)
    $script:lblQuotaPath = New-Object System.Windows.Forms.Label
    $script:lblQuotaPath.Location = New-Object System.Drawing.Point(15, 15)
    $script:lblQuotaPath.Size = New-Object System.Drawing.Size(700, 35)
    $script:lblQuotaPath.Text = "Selected path for quota:"
    $script:lblQuotaPath.Font = $script:fontNormal
    $script:lblQuotaPath.AutoSize = $false
    $pnlQuotaInfo = New-Object System.Windows.Forms.Panel
    $pnlQuotaInfo.Location = New-Object System.Drawing.Point(15, 55)
    $pnlQuotaInfo.Size = New-Object System.Drawing.Size(700, 100)
    $pnlQuotaInfo.BackColor = [System.Drawing.Color]::FromArgb(248, 249, 252)
    $pnlQuotaInfo.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:lblCurrentQuota = New-Object System.Windows.Forms.Label
    $script:lblCurrentQuota.Location = New-Object System.Drawing.Point(15, 15)
    $script:lblCurrentQuota.Size = New-Object System.Drawing.Size(400, 22)
    $script:lblCurrentQuota.Text = "Current quota: -"
    $script:lblCurrentQuota.Font = $script:fontBold
    $script:lblCurrentQuota.AutoSize = $false
    $script:lblFolderSize = New-Object System.Windows.Forms.Label
    $script:lblFolderSize.Location = New-Object System.Drawing.Point(15, 42)
    $script:lblFolderSize.Size = New-Object System.Drawing.Size(350, 22)
    $script:lblFolderSize.Text = "Current size: -"
    $script:lblFolderSize.Font = $script:fontNormal
    $script:lblFolderSize.AutoSize = $false
    $script:btnCalcSize = New-Object System.Windows.Forms.Button
    $script:btnCalcSize.Location = New-Object System.Drawing.Point(15, 68)
    $script:btnCalcSize.Size = New-Object System.Drawing.Size(140, 25)
    $script:btnCalcSize.Text = "Calculate Size"
    $script:btnCalcSize.Font = $script:fontNormal
    $script:btnCalcSize.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnCalcSize.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:toolTip.SetToolTip($script:btnCalcSize, "Calculate the total disk space used by this folder and its contents")
    $pnlQuotaInfo.Controls.AddRange(@($script:lblCurrentQuota, $script:lblFolderSize, $script:btnCalcSize))
    $pnlNewQuota = New-Object System.Windows.Forms.Panel
    $pnlNewQuota.Location = New-Object System.Drawing.Point(15, 165)
    $pnlNewQuota.Size = New-Object System.Drawing.Size(400, 120)
    $pnlNewQuota.BackColor = [System.Drawing.Color]::FromArgb(248, 249, 252)
    $pnlNewQuota.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $lblNewQuotaTitle = New-Object System.Windows.Forms.Label
    $lblNewQuotaTitle.Location = New-Object System.Drawing.Point(10, 10)
    $lblNewQuotaTitle.Size = New-Object System.Drawing.Size(200, 20)
    $lblNewQuotaTitle.Text = "Set New Quota"
    $lblNewQuotaTitle.Font = $script:fontBold
    $script:lblNewQuota = New-Object System.Windows.Forms.Label
    $script:lblNewQuota.Location = New-Object System.Drawing.Point(10, 38)
    $script:lblNewQuota.Size = New-Object System.Drawing.Size(100, 20)
    $script:lblNewQuota.Text = "Size (GB):"
    $script:lblNewQuota.Font = $script:fontNormal
    $script:txtNewQuota = New-Object System.Windows.Forms.TextBox
    $script:txtNewQuota.Location = New-Object System.Drawing.Point(110, 36)
    $script:txtNewQuota.Size = New-Object System.Drawing.Size(80, 25)
    $script:txtNewQuota.Font = $script:fontNormal
    $script:toolTip.SetToolTip($script:txtNewQuota, "Enter quota size in gigabytes (e.g., 10 for 10 GB, 0.5 for 500 MB)")
    $script:rbHard = New-Object System.Windows.Forms.RadioButton
    $script:rbHard.Location = New-Object System.Drawing.Point(200, 38)
    $script:rbHard.Size = New-Object System.Drawing.Size(90, 20)
    $script:rbHard.Text = "Hard limit"
    $script:rbHard.Checked = $true
    $script:rbHard.Font = $script:fontNormal
    $script:toolTip.SetToolTip($script:rbHard, "HARD LIMIT: Users cannot exceed this limit. Write operations will fail when quota is reached.")
    $script:rbSoft = New-Object System.Windows.Forms.RadioButton
    $script:rbSoft.Location = New-Object System.Drawing.Point(295, 38)
    $script:rbSoft.Size = New-Object System.Drawing.Size(90, 20)
    $script:rbSoft.Text = "Soft limit"
    $script:rbSoft.Font = $script:fontNormal
    $script:toolTip.SetToolTip($script:rbSoft, "SOFT LIMIT: Users can exceed this limit, but warnings/notifications will be generated.")
    $script:btnSaveQuota = New-Object System.Windows.Forms.Button
    $script:btnSaveQuota.Location = New-Object System.Drawing.Point(10, 75)
    $script:btnSaveQuota.Size = New-Object System.Drawing.Size(120, 30)
    $script:btnSaveQuota.Text = "Save Quota"
    $script:btnSaveQuota.Font = $script:fontNormal
    $script:btnSaveQuota.BackColor = $script:clrSuccess
    $script:btnSaveQuota.ForeColor = [System.Drawing.Color]::White
    $script:btnSaveQuota.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnSaveQuota.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $script:btnRemoveQuota = New-Object System.Windows.Forms.Button
    $script:btnRemoveQuota.Location = New-Object System.Drawing.Point(140, 75)
    $script:btnRemoveQuota.Size = New-Object System.Drawing.Size(120, 30)
    $script:btnRemoveQuota.Text = "Remove Quota"
    $script:btnRemoveQuota.Font = $script:fontNormal
    $script:btnRemoveQuota.ForeColor = $script:clrDanger
    $script:btnRemoveQuota.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:btnRemoveQuota.Cursor = [System.Windows.Forms.Cursors]::Hand
    # Tooltip will be set in Update-ReadOnlyControls for Viewer version
    $pnlNewQuota.Controls.AddRange(@($lblNewQuotaTitle, $script:lblNewQuota, $script:txtNewQuota, $script:rbHard, $script:rbSoft, $script:btnSaveQuota, $script:btnRemoveQuota))
    $script:lblQuotaInfo = New-Object System.Windows.Forms.Label
    $script:lblQuotaInfo.Location = New-Object System.Drawing.Point(15, 300)
    $script:lblQuotaInfo.Size = New-Object System.Drawing.Size(700, 150)
    $quotaExplanation = @"
QUOTA TYPES:
• Hard Limit - Prevents users from exceeding the specified size. Files cannot be saved once limit is reached.
• Soft Limit - Allows users to exceed the limit, but generates warnings and event log entries.
USE CASES:
• User home folders - Limit personal storage to prevent abuse
• Department shares - Control storage allocation per team
• Project folders - Budget disk space per project
NOTE: Quotas require FSRM (File Server Resource Manager) role to be installed on the server.
"@
    $script:lblQuotaInfo.Text = $(if ($script:fsrmAvailable) { $quotaExplanation } else { "FSRM module is not available.`n`nTo enable quotas, install the File Server Resource Manager role:`n  1. Open Server Manager`n  2. Add Roles and Features`n  3. Select 'File Server Resource Manager' under File Services" })
    $script:lblQuotaInfo.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $script:lblQuotaInfo.ForeColor = [System.Drawing.Color]::FromArgb(80, 80, 80)
    $script:lblQuotaInfo.AutoSize = $false
    $script:tabQuota.Controls.AddRange(@($script:lblQuotaPath, $pnlQuotaInfo, $pnlNewQuota, $script:lblQuotaInfo))
    $null = $script:tabs.TabPages.Add($script:tabNtfs)
    $null = $script:tabs.TabPages.Add($script:tabShare)
    $null = $script:tabs.TabPages.Add($script:tabQuota)
    $script:readOnlyMode = $true
    $script:btnRefresh.Add_Click({
        Switch-ToBrowseMode
    })
    $script:btnCacheManage.Add_Click({
        Show-IndexCacheDialog
    })
    $script:btnExitSearch.Add_Click({
        Switch-ToBrowseMode
    })
    $script:chkShowSharesOnly.Add_CheckedChanged({
        if ($script:treeMode -eq "Browse") {
            Populate-Tree
        }
    })
    $script:txtTreeFilter.Add_Enter({
        if ($script:txtTreeFilter.Text -eq "Filter shares/folders...") {
            $script:txtTreeFilter.Text = ""
            $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Black
        }
    })
    $script:txtTreeFilter.Add_Leave({
        if ([string]::IsNullOrWhiteSpace($script:txtTreeFilter.Text)) {
            $script:txtTreeFilter.Text = "Filter shares/folders..."
            $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Gray
            $script:btnTreeFilterClear.Visible = $false
        }
    })
    $script:txtTreeFilter.Add_TextChanged({
        $isPlaceholder = ($script:txtTreeFilter.Text -eq "Filter shares/folders...")
        $isEmpty = [string]::IsNullOrWhiteSpace($script:txtTreeFilter.Text)
        $script:btnTreeFilterClear.Visible = (-not $isPlaceholder -and -not $isEmpty)
    })
    $script:txtTreeFilter.Add_KeyDown({
        param($sender, $e)
        if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
            $e.SuppressKeyPress = $true
            $filterText = $script:txtTreeFilter.Text
            if ($filterText -ne "Filter shares/folders..." -and -not [string]::IsNullOrWhiteSpace($filterText)) {
                Filter-Tree -FilterText $filterText
            }
        }
        elseif ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
            $script:txtTreeFilter.Text = "Filter shares/folders..."
            $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Gray
            $script:btnTreeFilterClear.Visible = $false
            Populate-Tree
            $script:lblTreeInfo.Text = "Shares and Folders"
        }
    })
    $script:btnTreeFilter.Add_Click({
        $filterText = $script:txtTreeFilter.Text
        if ($filterText -eq "Filter shares/folders..." -or [string]::IsNullOrWhiteSpace($filterText)) {
        Populate-Tree
            $script:lblTreeInfo.Text = "Shares and Folders"
            $script:btnTreeFilterClear.Visible = $false
        } else {
            Filter-Tree -FilterText $filterText
        }
    })
    $script:btnTreeFilterClear.Add_Click({
        $script:txtTreeFilter.Text = "Filter shares/folders..."
        $script:txtTreeFilter.ForeColor = [System.Drawing.Color]::Gray
        $script:btnTreeFilterClear.Visible = $false
        Populate-Tree
        $script:lblTreeInfo.Text = "Shares and Folders"
    })
    $exportNames = @(
        'form','tree','lblTreeInfo','btnRefresh','btnCacheManage','btnSearchUser','btnGlobalHistory',
        'panel','tabs','tabNtfs','tabShare','tabQuota',
        'lblNtfsPath','lvNtfs','lblRights','cbNtfsRights','btnAddAce','btnRemoveAce','btnSaveTemplate','btnApplyTemplate','btnExportNtfs','lblNtfsInfo',
        'lblShareName','lvShare','btnAddShareAce','btnRemoveShareAce','btnExportShare','lblShareInfo',
        'lblQuotaPath','lblCurrentQuota','lblFolderSize','btnCalcSize','lblNewQuota','txtNewQuota','rbHard','rbSoft','btnSaveQuota','btnRemoveQuota','lblQuotaInfo'
    )
    foreach ($n in $exportNames) {
        try {
            $val = Get-Variable -Scope Script -Name "script:$n" -ErrorAction SilentlyContinue
            if ($val) {
                Set-Variable -Name $n -Value $val.Value -Scope Script -Force
            }
        } catch {
        }
    }
    & $script:resizeLayout
    $script:form.Add_Resize({ & $script:resizeLayout })
}

