<#
.SYNOPSIS
    FS-Manager Viewer - Read-Only File System Permissions Viewer
.DESCRIPTION
    Part of FS-Manager Viewer v1.0 - Free read-only version
    For full functionality, upgrade to FS-Manager Pro
.NOTES
    Copyright (c) 2025 FSWorks Labs. All rights reserved.
    
    This software is provided "as-is" without warranty of any kind.
    Unauthorized modification or redistribution is prohibited.
    
    Purchase FS-Manager Pro: https://fsworks2.gumroad.com/l/fsmanager-pro
    Support: fworks-support@proton.me
#>
# Module: FSManager.Share.ps1
# Build: 20251126-142332

function Get-ShareData {
    Get-SmbShare | ? {
        $_.Path -and
        $_.Name -notin @("ADMIN$","IPC$","C$") -and
        -not ($_.Path -match '^[A-Z]:\\$') -and
        -not ($_.Path -like 'C:\\Windows*') -and
        -not ($_.Path -like 'C:\\ProgramData*')
    }
}
function Get-FolderChildren {
    param([string]$Path)
    try {
        Get-ChildItem -Path $Path -Directory -ErrorAction Stop | Sort-Object Name
    } catch {
        @()
    }
}
function Get-ShareAcl {
    param([string]$ShareName)
    try {
        Get-SmbShareAccess -Name $ShareName -ErrorAction Stop
    } catch {
        $null
    }
}

